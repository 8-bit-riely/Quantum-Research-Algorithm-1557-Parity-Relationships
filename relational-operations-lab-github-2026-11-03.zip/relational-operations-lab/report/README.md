# Research report

The PDF records the completed algorithm research and its limitations. Its reproduction section describes the earlier research bundle, which contained a nested input ZIP. This GitHub package instead includes the source directly: follow the [repository README](../README.md) and pass `--source-dir .` from the repository root. The mathematical and numerical results are unchanged.

The figure source is `research/build_report.py`. To regenerate the report in a new output folder, install the report dependencies and run:

```bash
python -m pip install ".[report]"
python research/build_report.py --output-dir replay/report
```

The builder reads saved JSON in `research/`. Generated timings and rendering bytes can vary by environment.
