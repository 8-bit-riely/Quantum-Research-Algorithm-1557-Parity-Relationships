"""Offline command-line interface for the experimental public snapshot."""
import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path

from .core import JointTable, describe, exact, require
from .dataio import table_record, decode_record, verify_data, strict_json
from .extensions import coverage, feature_masks


def source(args):
    if args.table:
        raw=args.table.read_bytes();value=strict_json(raw)
        return JointTable.from_counts(value['bits'],value['counts']),sum(value['counts']),{
            'kind':'USER_SUPPLIED_TABLE','sha256':hashlib.sha256(raw).hexdigest()}
    item=table_record(args.record)
    bits=item['pairBits'] if args.arity==2 else item['pairBits']+[item['contextBit']]
    counts=item['pairCounts'] if args.arity==2 else item['tripleCounts']
    return JointTable.from_counts(bits,counts),item['shots'],{
        'kind':'RECORDED_PHYSICAL_TABLE','recordId':item['recordId'],'device':item['device'],'provenance':item['provenance']}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation',choices=['inspect','design','condition','compare','audit','decode','verify-data','build'])
    group=parser.add_mutually_exclusive_group();group.add_argument('--record',default='E32:S04');group.add_argument('--table',type=Path)
    parser.add_argument('--arity',type=int,choices=[2,3],default=3)
    parser.add_argument('--d',default='0',help='Exact shift in original count units, e.g.3 or1/2')
    parser.add_argument('--given',action='append',default=[],help='bit=value; repeat for several conditions')
    parser.add_argument('--query',nargs='*',type=int)
    parser.add_argument('--variables',type=int,default=4)
    parser.add_argument('--with-covariance',action='store_true')
    parser.add_argument('--subset',nargs='+',type=int,default=[5,6,10,11])
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    try:
        if args.operation=='verify-data':
            result=verify_data()
        elif args.operation=='audit':
            require(1<=args.variables<=12,'Audit supports1..12 variables')
            result=coverage(args.variables,feature_masks(args.variables,2),args.with_covariance)
        elif args.operation=='decode':
            table,result=decode_record(args.record,args.subset);result['table']=describe(table)
        elif args.operation=='build':
            require(args.output is not None,'Provide a new --output directory')
            from .render import build_site
            result=build_site(args.output)
        else:
            table,N,origin=source(args)
            result={'schema':'relational-operation-result/1','operation':args.operation,'source':origin,
                    'probabilityDenominator':N,'newMeasurements':0,'samplesGenerated':0,'providerCalls':0}
            if args.operation=='inspect':
                result.update(kind='RECORDED_OR_SUPPLIED_TABLE_DESCRIPTION',table=describe(table))
            elif args.operation=='design':
                epsilon=Fraction(args.d)/N;changed=table.move_relationship(epsilon)
                result.update(kind='ANALYTIC_TABLE_SPECIFICATION',epsilon=exact(epsilon),table=describe(changed),
                              allProperMarginalsPreserved=changed.proper_marginals()==table.proper_marginals())
            elif args.operation=='condition':
                epsilon=Fraction(args.d)/N;changed=table.move_relationship(epsilon);given={}
                for token in args.given:
                    bit,value=map(int,token.split('='));require(bit not in given,'Duplicate condition label');given[bit]=value
                query=args.query if args.query is not None else [b for b in table.bits if b not in given]
                lookup=changed.conditional_lookup(given,query)
                result.update(kind='EXACT_CONDITIONAL_LOOKUP',tableRole='RECORDED_OR_SUPPLIED' if epsilon==0 else 'ANALYTIC_DESIGN',
                              given=given,query=query,conditionProbability=exact(lookup['conditionProbability']),
                              answerProbabilities=None if lookup['answerProbabilities'] is None else [exact(p) for p in lookup['answerProbabilities']])
            else:
                low,high=table.movement_interval();a,b=table.move_relationship(low),table.move_relationship(high)
                result.update(kind='DEPENDENCY_ISOLATION_REFERENCE',lowerDesign=describe(a),upperDesign=describe(b),
                              allProperMarginalsIdentical=a.proper_marginals()==b.proper_marginals(),
                              fullTableTotalVariation=exact(sum(abs(x-y) for x,y in zip(a.probabilities,b.probabilities))/2))
    except (ValueError,KeyError,TypeError,FileNotFoundError) as error:
        parser.error(str(error))
    print(json.dumps(result,indent=2,allow_nan=False))
