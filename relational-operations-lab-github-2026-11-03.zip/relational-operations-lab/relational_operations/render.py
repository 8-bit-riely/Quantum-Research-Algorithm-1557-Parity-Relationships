"""Build self-contained research pages from the bundled public fixtures.

This renderer uses finite-table arithmetic and the included recorded statistics.
It performs no circuit dynamics, sampling, training, optimizer or network work.
"""
from __future__ import annotations

from fractions import Fraction
import hashlib
from importlib import resources
from itertools import combinations
import json
from pathlib import Path

from .core import JointTable, describe, exact, require
from .extensions import (
    coverage, direction, direction_interval, feature_masks, fixed_pair_geometry,
    mask_labels, recover_archived_moments, table_from_moments,
)


def _resource_text(name: str) -> str:
    return resources.files(__package__).joinpath("templates", name).read_text(encoding="utf-8")


def _json(value) -> str:
    return json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False)


def _embedded(value) -> str:
    # An embedded data string must not terminate its containing script element.
    return json.dumps(value, ensure_ascii=False, allow_nan=False).replace("</", "<\\/")


def _counts_for(words, bits):
    out = [0] * (1 << len(bits))
    for word, count in words.items():
        category = 0
        for bit in bits:
            category = (category << 1) | ((word >> bit) & 1)
        out[category] += count
    return out


def _provenance(value):
    """Only public, hashes-only custody commitments enter generated pages."""
    require(isinstance(value, dict) and value, "Public provenance commitments required")
    require(all(key.endswith("Sha256") and isinstance(digest, str) and len(digest) == 64
                and all(ch in "0123456789abcdef" for ch in digest)
                for key, digest in value.items()), "Provenance must contain SHA256 commitments only")
    return dict(value)


def _table_data(fixture):
    rows = []
    for record in fixture["records"]:
        item = {key: record[key] for key in (
            "recordId", "device", "shots", "pairBits", "contextBit", "pairCounts", "tripleCounts", "role"
        )}
        item["provenance"] = _provenance(record["provenance"])
        views = []
        for field, bits in (
            ("pairCounts", record["pairBits"]),
            ("tripleCounts", record["pairBits"] + [record["contextBit"]]),
        ):
            table = JointTable.from_counts(bits, record[field])
            low, high = table.movement_interval()
            views.append({
                "arity": len(bits), "recordedCounts": record[field], "observed": describe(table),
                "lowerDesign": describe(table.move_relationship(low)),
                "upperDesign": describe(table.move_relationship(high)),
                "countUnitInterval": [exact(low * record["shots"]), exact(high * record["shots"])],
                "designsArePhysicalMeasurements": False,
            })
        item["views"] = views
        rows.append(item)
    original = next(row for row in rows if row["recordId"] == "E32:S04")
    table = JointTable.from_counts([5, 6, 11], original["tripleCounts"])
    low, high = table.movement_interval()
    conditional = []
    for label, epsilon in (("lower design", low), ("observed table", Fraction(0)), ("upper design", high)):
        query = table.move_relationship(epsilon).conditional_lookup({5: 1, 11: 0}, [6])
        conditional.append({
            "kind": label, "shift": exact(epsilon), "condition": {"bit5": 1, "bit11": 0},
            "conditionProbability": exact(query["conditionProbability"]),
            "probabilityBit6One": exact(query["answerProbabilities"][1]),
        })
    return {
        "schema": "public-relational-table-instrument/1", "snapshotTag": fixture["snapshotTag"],
        "snapshotDate": fixture["snapshotDate"], "dataLicense": fixture["license"],
        "records": rows, "recordsPooled": False, "retainedRecords": len(rows),
        "retainedShots": sum(row["shots"] for row in rows),
        "originalConditionalControlExample": conditional,
        "newPhysicalMeasurements": 0, "quantumSimulations": 0, "samplesGenerated": 0,
        "learnerExecutions": 0, "optimizerUpdates": 0, "providerCalls": 0,
    }


def _covariance_data(fixture):
    expected_masks = [1 << bit for bit in range(12)] + [
        (1 << a) | (1 << b) for a, b in combinations(range(12), 2)
    ]
    require(fixture["physicalMasks"] == expected_masks, "Public observable order differs")
    audits = []
    original = None
    for record in fixture["records"]:
        n = record["shots"]
        require(type(n) is int and n >= 2, "Known physical shot count required")
        require(record["measurementBasis"] == "computational-Z", "Computational-Z fixtures required")
        words = {}
        for word, count in record["logicalCounts"].items():
            require(isinstance(word, str) and len(word) == 12 and set(word) <= {"0", "1"}
                    and type(count) is int and count >= 0, "Invalid logical histogram")
            if count:
                words[int(word, 2)] = count
        require(sum(words.values()) == n, "Logical histogram does not match shot count")
        recovered, error = recover_archived_moments(
            expected_masks, record["means"], record["meanCovariance"], n
        )
        require(len(recovered) == 794, "Expected 793 nonconstant coefficients through degree four")
        for mask, value in recovered.items():
            direct = Fraction(sum(c * (-1 if (w & mask).bit_count() % 2 else 1)
                                  for w, c in words.items()), n)
            require(value == direct, "Covariance decoder differs from bundled logical histogram")
        quad_checks = []
        for bits in ([5, 6, 10, 11], [2, 5, 6, 11]):
            table = table_from_moments(bits, recovered)
            direct = _counts_for(words, bits)
            require([p * n for p in table.probabilities] == direct, "Four-answer reconstruction differs")
            quad_checks.append({"bits": bits, "counts": direct})
        provenance = _provenance(record["provenance"])
        audits.append({
            "recordId": record["recordId"], "shots": n,
            "recoveredNonconstantCoefficients": 793,
            "maximumCountUnitRoundingResidual": error, "quadChecks": quad_checks,
            "provenance": provenance,
        })
        if record["recordId"] == "E32:S04":
            original = (record, words)
    require(original is not None, "Original four-answer example missing")
    record, words = original
    require(record["shots"] == 800, "This frozen page expects the recorded 800-shot example")
    views = []
    physical_index = {mask: i for i, mask in enumerate(expected_masks)}
    for bits, title in (([5, 6, 10, 11], "Context source 10"), ([2, 5, 6, 11], "Shared source 2")):
        counts = _counts_for(words, bits)
        table = JointTable.from_counts(bits, counts)
        local_masks = feature_masks(4, 2)
        profile = coverage(4, local_masks)
        axes = []
        for mask in profile["hiddenMasks"]:
            selected = mask_labels(bits, mask)
            vector = direction(table, selected)
            low, high = direction_interval(table, vector)
            axes.append({
                "localMask": mask, "bits": selected, "vector": [int(v) for v in vector],
                "countUnitInterval": [float(low * 800), float(high * 800)],
            })
        coupled = []
        if bits == [5, 6, 10, 11]:
            for name, selected, context in (("U", [5, 6, 11], {10: 0}), ("V", [5, 10, 11], {6: 0})):
                vector = direction(table, selected, context)
                low, high = direction_interval(table, vector)
                coupled.append({
                    "name": name, "bits": selected, "context": context,
                    "vector": [int(v) for v in vector],
                    "countUnitInterval": [float(low * 800), float(high * 800)],
                })
        indices = [physical_index[sum(1 << bit for bit in mask_labels(bits, local))]
                   for local in local_masks]
        means = [record["means"][i] for i in indices]
        covariance = [[record["meanCovariance"][i][j] for j in indices] for i in indices]
        recovered, _ = recover_archived_moments(local_masks, means, covariance, 800)
        require(len(recovered) == 16, "Four-answer feature profile is incomplete")
        views.append({
            "bits": bits, "title": title, "observedCounts": counts, "shots": 800,
            "meansOnlyProfile": profile, "withCovarianceProfile": coverage(4, local_masks, True),
            "pairFeatures": local_masks, "archivedFeatureMeans": means,
            "archivedMeanCovariance": covariance,
            "recoveredSignedNumerators": [int(recovered[m] * 800) for m in range(16)],
            "geometry": fixed_pair_geometry(table), "pureAxes": axes, "coupledControls": coupled,
            "sourceProvenance": _provenance(record["provenance"]),
        })
    return {
        "schema": "public-relational-extensions/1", "snapshotTag": fixture["snapshotTag"],
        "snapshotDate": fixture["snapshotDate"], "dataLicense": fixture["license"],
        "fourBitViews": views, "fourBitPairMeans": coverage(4, feature_masks(4, 2)),
        "fourBitPairMeansAndCovariance": coverage(4, feature_masks(4, 2), True),
        "twelveBitCoverageCounts": {"total": 4095, "pairMeans": 78, "pairMeansAndFullSameShotCovariance": 793},
        "covarianceConvention": fixture["convention"], "retainedCovarianceAudit": audits,
        "retainedRecords": len(audits), "retainedShots": sum(row["shots"] for row in audits),
        "newMeasurements": 0, "samplesGenerated": 0, "quantumSimulations": 0,
        "learnerExecutions": 0, "providerCalls": 0,
    }


def build_site(outputnew):
    """Build into a new directory using only package resources; return counts."""
    from .dataio import load_fixture

    output = Path(outputnew)
    require(not output.exists(), "Preserve the previous build; select a new output directory")
    # Validate every input and template before publishing the new directory.
    table_data = _table_data(load_fixture("records.json"))
    covariance_data = _covariance_data(load_fixture("covariance_records.json"))
    workbench = _resource_text("workbench.html")
    extension = _resource_text("extensions.html")
    guide = _resource_text("GUIDE.md")
    require(workbench.count("__RELATION_DATA__") == 1 and extension.count("__EXTENSION_DATA__") == 1,
            "Template data marker differs")
    outputs = {
        "TABLE_DATA.json": _json(table_data),
        "EXTENSIONS_DATA.json": _json(covariance_data),
        "triple.html": workbench.replace("__RELATION_DATA__", _embedded(table_data)),
        "index.html": extension.replace("__EXTENSION_DATA__", _embedded(covariance_data)),
        "GUIDE.md": guide,
    }
    output.mkdir(parents=True)
    for name, text in outputs.items():
        (output / name).write_text(text, encoding="utf-8", newline="\n")
    manifest = {
        "schema": "relational-operations-site-manifest/1", "snapshotTag": table_data["snapshotTag"],
        "snapshotDate": table_data["snapshotDate"],
        "files": [{"path": name, "sha256": hashlib.sha256((output / name).read_bytes()).hexdigest()}
                  for name in sorted(outputs)],
        "newMeasurements": 0, "samplesGenerated": 0, "modelExecutions": 0, "providerCalls": 0,
    }
    (output / "SITE_MANIFEST.json").write_text(_json(manifest), encoding="utf-8", newline="\n")
    return {
        "status": "BUILT", "snapshotTag": table_data["snapshotTag"],
        "retainedTableRecords": table_data["retainedRecords"],
        "retainedCovarianceRecords": covariance_data["retainedRecords"],
        "fourBitReconstructionChecks": 2 * covariance_data["retainedRecords"],
        "newMeasurements": 0, "samplesGenerated": 0, "modelExecutions": 0, "providerCalls": 0,
    }
