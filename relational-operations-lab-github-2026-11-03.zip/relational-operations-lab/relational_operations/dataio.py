"""Portable, checksummed public fixtures. No service or private-file access."""
import hashlib
from importlib.resources import files
from itertools import combinations
from fractions import Fraction
import json

from .core import JointTable, require
from .extensions import recover_archived_moments, table_from_moments


def strict_json(raw):
    def unique(pairs):
        result={}
        for key,value in pairs:
            require(key not in result,'Duplicate JSON key')
            result[key]=value
        return result
    return json.loads(raw,object_pairs_hook=unique,
                      parse_constant=lambda value:(_ for _ in ()).throw(ValueError('Nonfinite JSON')))


def load_fixture(name):
    require(name in ('records.json','covariance_records.json'),'Unknown public fixture')
    root=files('relational_operations').joinpath('data')
    manifest=strict_json(root.joinpath('MANIFEST.json').read_bytes())
    pins=[pin for pin in manifest['files'] if pin['path']==name]
    require(len(pins)==1,'Fixture pin missing')
    raw=root.joinpath(name).read_bytes()
    require(hashlib.sha256(raw).hexdigest()==pins[0]['sha256'],'Public fixture checksum differs')
    return strict_json(raw)


def table_record(record_id):
    item=next((r for r in load_fixture('records.json')['records'] if r['recordId']==record_id),None)
    require(item is not None,'Unknown public record')
    return item


def covariance_record(record_id):
    data=load_fixture('covariance_records.json')
    item=next((r for r in data['records'] if r['recordId']==record_id),None)
    require(item is not None,'Unknown covariance record')
    return data,item


def counts_for(histogram,bits):
    out=[0]*(1<<len(bits))
    for word,count in histogram.items():
        value=int(word,2);category=0
        for bit in bits:
            category=(category<<1)|((value>>bit)&1)
        out[category]+=count
    return out


def decode_record(record_id,bits):
    require(len(set(bits))==len(bits) and 1<=len(bits)<=4
            and all(type(b) is int and 0<=b<12 for b in bits),'Select one to four distinct logical bits')
    data,item=covariance_record(record_id)
    moments,error=recover_archived_moments(data['physicalMasks'],item['means'],item['meanCovariance'],item['shots'])
    table=table_from_moments(bits,moments)
    direct=counts_for(item['logicalCounts'],bits)
    require([p*item['shots'] for p in table.probabilities]==direct,'Covariance reconstruction differs from public histogram')
    return table,{'recordId':record_id,'bits':bits,'recoveredCounts':direct,
                  'recoveredNonconstantCoefficients':len(moments)-1,
                  'maximumCountUnitRoundingResidual':error,'exactHistogramAgreement':True,
                  'provenance':item['provenance']}


def verify_data():
    simple=load_fixture('records.json')
    require(len(simple['records'])==12,'Expected12 table records')
    for item in simple['records']:
        for key,bits in (('pairCounts',item['pairBits']),('tripleCounts',item['pairBits']+[item['contextBit']])):
            JointTable.from_counts(bits,item[key])
            require(sum(item[key])==item['shots'],'Record normalization differs')
    data=load_fixture('covariance_records.json')
    masks=[1<<b for b in range(12)]+[(1<<a)|(1<<b) for a,b in combinations(range(12),2)]
    require(data['physicalMasks']==masks and data['sameShotCrossCovariance'] is True,'Observable/convention contract differs')
    require(len(data['records'])==32,'Expected32 covariance records')
    maximum_error=0.;reconstructions=0
    for item in data['records']:
        N=item['shots'];hist=item['logicalCounts']
        require(type(N) is int and N>=2 and sum(hist.values())==N,'Histogram total differs')
        require(all(len(word)==12 and set(word)<=set('01') and type(c) is int and c>=0 for word,c in hist.items()),'Invalid logical histogram')
        moments,error=recover_archived_moments(masks,item['means'],item['meanCovariance'],N)
        require(len(moments)==794,'Expected793 nonconstant coefficients')
        maximum_error=max(maximum_error,error)
        words={int(word,2):count for word,count in hist.items()}
        for mask,value in moments.items():
            direct=Fraction(sum(count*(-1 if (word&mask).bit_count()%2 else 1) for word,count in words.items()),N)
            require(value==direct,'Recovered coefficient disagrees with published histogram')
        for bits in ([5,6,10,11],[2,5,6,11]):
            table=table_from_moments(bits,moments)
            require([p*N for p in table.probabilities]==counts_for(hist,bits),'Four-bit inverse differs')
            reconstructions+=1
    covariance_by_id={r['recordId']:r for r in data['records']}
    overlap=[]
    for item in simple['records']:
        if item['recordId'] not in covariance_by_id:
            continue
        other=covariance_by_id[item['recordId']]
        require(item['shots']==other['shots'] and item['provenance']['originalRawResultSha256']==other['provenance']['originalRawResultSha256'],
                'Overlapping catalogs identify different observations')
        require(counts_for(other['logicalCounts'],item['pairBits'])==item['pairCounts']
                and counts_for(other['logicalCounts'],item['pairBits']+[item['contextBit']])==item['tripleCounts'],
                'Overlapping catalogs have inconsistent named counts')
        overlap.append(item)
    require(len(overlap)==4,'Expected four shared records across the catalogs')
    return {'status':'PASS','tableRecords':12,'tableCatalogShots':sum(r['shots'] for r in simple['records']),
            'covarianceRecords':32,'covarianceCatalogShots':sum(r['shots'] for r in data['records']),
            'catalogsOverlap':True,'overlappingRecords':len(overlap),
            'uniqueRecordsAcrossCatalogs':len(simple['records'])+len(data['records'])-len(overlap),
            'uniqueShotsAcrossCatalogs':sum(r['shots'] for r in simple['records'])+sum(r['shots'] for r in data['records'])-sum(r['shots'] for r in overlap),
            'fourBitReconstructions':reconstructions,
            'recoveredCoefficientsPerCovarianceRecord':793,
            'maximumCountUnitRoundingResidual':maximum_error,
            'newMeasurements':0,'generatedSamples':0,'providerCalls':0}
