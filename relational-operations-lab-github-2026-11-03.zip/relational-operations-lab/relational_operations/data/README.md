# Public measurement tables

The JSON files are reusable under **CC BY 4.0**. Attribution:
**Relational Operations Lab contributors, snapshot v0.1.0-experimental,
as of 2026-11-03**. See `LICENSE.txt` for the canonical license links.

## Contents

- `records.json`: 12 selected recorded pair/triple examples, 12,000 shots.
- `covariance_records.json`: 32 recorded computational-Z histograms, all 78
  individual/pair feature means and their full 78×78 same-shot covariance,
  25,600 shots.
- `MANIFEST.json`: checksums of the JSON inputs and license notice.

The catalogs overlap in four EMERALD32 records totaling 3,200 shots. Taken
together they describe **40 unique historical records /34,400 shots**. Do not
add the catalog shot totals as if every row were independent new evidence.

Each record keeps its public ID, device label, shot total, logical category
convention and hashes committing to the original source/result artifacts.
Original provider payloads and operational identifiers are not bundled. Their
hashes are custody commitments, not a substitute for the unavailable bytes.

Histograms are already expressed in restored logical classical-bit categories.
Do not apply terminal XOR or measurement mapping again. A 12-character word is
`c[11]...c[0]`, with logical bit0 at the right.

The covariance file declares its feature-mask order and convention:

```text
CovMean(A,B) = (empiricalMean(A*B) - empiricalMean(A)*empiricalMean(B)) / (N-1)
```

All features and covariance entries for a record come from the same measured
rows. Distinct records stay separate. Recovery does not create additional shots.

The public tables are aggregate recorded evidence. Endpoint designs produced
by the tools are explicitly marked as analytical probability specifications.
See `SCIENTIFIC_SCOPE.md` at the repository root for the exploratory selection
context and the original association's later follow-up.
