"""Exact operations checked on the bundled recorded tables, with no sampling."""
from fractions import Fraction
import unittest

from relational_operations.core import JointTable
from relational_operations.dataio import load_fixture, table_record, decode_record, verify_data
from relational_operations.extensions import (coverage,feature_masks,direction,direction_interval,
                                               move,moment,fixed_pair_geometry)


class RecordedOperationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.records=load_fixture('records.json')['records']
        cls.original=table_record('E32:S04')

    def test_every_recorded_endpoint_preserves_lower_views_and_reverses(self):
        for record in self.records:
            for key,bits in [('pairCounts',record['pairBits']),('tripleCounts',record['pairBits']+[record['contextBit']])]:
                table=JointTable.from_counts(bits,record[key])
                for epsilon in (*table.movement_interval(),Fraction(0)):
                    with self.subTest(record=record['recordId'],bits=bits,epsilon=epsilon):
                        changed=table.move_relationship(epsilon)
                        self.assertEqual(changed.proper_marginals(),table.proper_marginals())
                        self.assertEqual(changed.move_relationship(-epsilon),table)
                        self.assertEqual(table.move_relationship(epsilon/2).move_relationship(epsilon/2),changed)

    def test_original_conditional_response_and_support(self):
        table=JointTable.from_counts([5,6,11],self.original['tripleCounts'])
        for d,expected in [(-8,Fraction(0)),(0,Fraction(8,13)),(3,Fraction(11,13))]:
            answer=table.move_relationship(Fraction(d,800)).conditional_lookup({5:1,11:0},[6])
            self.assertEqual(answer['conditionProbability'],Fraction(13,800))
            self.assertEqual(answer['answerProbabilities'][1],expected)

    def test_invalid_tables_conditions_and_movements(self):
        with self.assertRaises(ValueError):JointTable.from_counts([5,5],[1,2,3,4])
        with self.assertRaises(ValueError):JointTable.from_counts([5],[True,3])
        table=JointTable.from_counts([5,6,11],self.original['tripleCounts'])
        for shift in (Fraction(-9,800),Fraction(4,800)):
            with self.assertRaises(ValueError):table.move_relationship(shift)
        with self.assertRaises(ValueError):table.conditional_lookup({5:2},[6])
        with self.assertRaises(ValueError):table.conditional_lookup({5:1},[5])

    def test_covariance_coverage_does_not_invent_higher_orders(self):
        self.assertEqual(coverage(4,feature_masks(4,2))['recoverableNonconstantCoordinates'],10)
        self.assertEqual(coverage(4,feature_masks(4,2),True)['recoverableNonconstantCoordinates'],15)
        self.assertEqual(coverage(12,feature_masks(12,2))['recoverableNonconstantCoordinates'],78)
        self.assertEqual(coverage(12,feature_masks(12,2),True)['recoverableNonconstantCoordinates'],793)

    def test_full_public_covariance_archive_reconstructs(self):
        result=verify_data()
        self.assertEqual(result['status'],'PASS')
        self.assertEqual(result['fourBitReconstructions'],64)
        self.assertEqual(result['covarianceRecords'],32)
        self.assertEqual(result['uniqueRecordsAcrossCatalogs'],40)
        self.assertEqual(result['uniqueShotsAcrossCatalogs'],34400)
        self.assertEqual(result['providerCalls'],0)

    def test_complete_coupled_rectangle_preserves_all_pairs(self):
        table,result=decode_record('E32:S04',[5,6,10,11])
        self.assertEqual(result['recoveredCounts'],[450,252,7,3,28,34,0,0,4,10,1,0,8,3,0,0])
        self.assertEqual(fixed_pair_geometry(table)['affineDimensionOnForcedZeroFace'],2)
        U=direction(table,[5,6,11],{10:0});V=direction(table,[5,10,11],{6:0})
        self.assertEqual(tuple(v*800 for v in direction_interval(table,U)),(-8,3))
        self.assertEqual(tuple(v*800 for v in direction_interval(table,V)),(-1,0))
        pairs=[(a,b) for i,a in enumerate(table.bits) for b in table.bits[i+1:]]
        for u in range(-8,4):
            for v in (-1,0):
                changed=move(move(table,U,Fraction(u,800)),V,Fraction(v,800))
                for pair in pairs:self.assertEqual(changed.marginal(pair),table.marginal(pair))
                self.assertEqual(moment(changed,13)-moment(table,13),Fraction(u,100))
                self.assertEqual(moment(changed,11)-moment(table,11),Fraction(v,100))
                self.assertEqual(moment(changed,15)-moment(table,15),Fraction(u+v,100))


if __name__=='__main__':
    unittest.main()
