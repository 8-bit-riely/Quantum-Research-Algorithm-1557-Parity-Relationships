'use strict';
// Offline JavaScript/DOM-output checks. No QPU, learner or browser service.
const fs = require('fs'), vm = require('vm'), assert = require('assert');
assert(process.argv[2], 'Usage: node tests/check_extensions.cjs PATH/index.html');
const html = fs.readFileSync(process.argv[2], 'utf8');
const embedded = html.match(/<script id="extension-data" type="application\/json">([\s\S]*?)<\/script>/)[1];
const scripts = [...html.matchAll(/<script(?: [^>]*)?>([\s\S]*?)<\/script>/g)];
const elements = new Map();
function get(id) {
  if (!elements.has(id)) elements.set(id, {value: '', textContent: '', innerHTML: '', min: '', max: '', hidden: false});
  return elements.get(id);
}
get('extension-data').textContent = embedded;
const sandbox = {window: {}, document: {getElementById: get}, console};
vm.createContext(sandbox); vm.runInContext(scripts.at(-1)[1], sandbox);
const api = sandbox.window.RelationExtensions; let viewsChecked = 0;
function publicData(value) {
  if (typeof value === 'string') {
    assert(!/[A-Za-z]:[\\/]|file:\/\/|https?:\/\/|X-Amz-|downloadUrl/i.test(value), 'Nonpublic data path or URL');
    assert(!/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i.test(value), 'Operational identifier in data');
  } else if (Array.isArray(value)) value.forEach(publicData);
  else if (value && typeof value === 'object') for (const [key, item] of Object.entries(value)) {
    assert(!/^(path|sessionId|jobId|modelId|projectId|accountId|checkpointSha256|downloadUrl|token|secret)$/i.test(key), 'Nonpublic data field');
    publicData(item);
  }
}
publicData(api.data); assert(!html.includes('__EXTENSION_DATA__'));
for (const profile of ['singles', 'pairs', 'covariance', 'full']) {
  for (let u = -8; u <= 3; u++) for (let v = -1; v <= 0; v++) {
    get('view').value = '0'; get('u').value = String(u); get('v').value = String(v);
    get('axis').value = '0'; get('d').value = '0'; get('profile').value = profile;
    const result = api.refresh(); assert(result.valid && result.pairsFixed && result.decoder.exact);
    assert(get('invariant').textContent.startsWith('PASS'));
    if (profile === 'pairs' || profile === 'singles') assert.strictEqual(result.reportDistinguishes, false);
    if ((profile === 'covariance' || profile === 'full') && (u !== 0 || v !== 0)) assert.strictEqual(result.reportDistinguishes, true);
    assert(api.exportDesign().allPairTablesUnchanged); viewsChecked++;
  }
  const view = api.data.fourBitViews[1];
  for (let axis = 0; axis < view.pureAxes.length; axis++) {
    const limits = view.pureAxes[axis].countUnitInterval;
    for (let d = limits[0]; d <= limits[1]; d++) {
      get('view').value = '1'; get('axis').value = String(axis); get('d').value = String(d); get('profile').value = profile;
      const result = api.refresh(); assert(result.valid && result.pairsFixed && result.decoder.exact); viewsChecked++;
    }
  }
}
assert.throws(() => api.calculate(0, 4, 0, 0, 0, 'pairs'));
assert.throws(() => api.calculate(0, 0, 1, 0, 0, 'pairs'));
for (const view of api.data.fourBitViews) {
  const decoded = api.decode(view); assert.strictEqual(Object.keys(decoded.moments).length, 16); assert(decoded.exact);
}
get('view').value = '0'; get('u').value = '3'; get('v').value = '-1'; get('profile').value = 'covariance'; api.refresh();
const exported = api.exportDesign(); assert.strictEqual(exported.role, 'ANALYTIC_PROBABILITY_SPECIFICATION');
assert.strictEqual(exported.newMeasurements, 0);
assert(exported.sourceProvenance && Object.keys(exported.sourceProvenance).every(key => key.endsWith('Sha256')));
assert(!('sourceEnvelope' in exported)); publicData(exported);
console.log(JSON.stringify({status: 'PASS', viewsChecked, exactFourBitDecoderViews: 2,
  allPairTablesPreserved: true, hashesOnlyExportProvenance: true, newMeasurements: 0, generatedSamples: 0}));
