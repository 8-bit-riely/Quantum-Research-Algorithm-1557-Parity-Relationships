import json
from pathlib import Path
import subprocess
import sys
import unittest


class CliTests(unittest.TestCase):
    def call(self,*args,success=True):
        result=subprocess.run([sys.executable,'-m','relational_operations',*args],capture_output=True,text=True,timeout=30)
        if success:
            self.assertEqual(result.returncode,0,result.stderr)
            return json.loads(result.stdout)
        self.assertNotEqual(result.returncode,0)
        return result

    def test_recorded_conditional_query(self):
        value=self.call('condition','--given','5=1','--given','11=0','--query','6')
        self.assertEqual(value['answerProbabilities'][1]['numerator'],8)
        self.assertEqual(value['answerProbabilities'][1]['denominator'],13)

    def test_compare_is_an_analytical_reference(self):
        value=self.call('compare')
        self.assertEqual(value['kind'],'DEPENDENCY_ISOLATION_REFERENCE')
        self.assertTrue(value['allProperMarginalsIdentical'])

    def test_covariance_decode_and_audit(self):
        value=self.call('decode','--subset','5','6','10','11')
        self.assertTrue(value['exactHistogramAgreement'])
        self.assertEqual(self.call('audit','--variables','4','--with-covariance')['recoverableNonconstantCoordinates'],15)

    def test_invalid_requests_reject_without_a_traceback(self):
        for args in [('condition','--given','5=2'),('decode','--subset','5','5'),('design','--d','1000')]:
            result=self.call(*args,success=False)
            self.assertNotIn('Traceback',result.stderr)


if __name__=='__main__':
    unittest.main()
