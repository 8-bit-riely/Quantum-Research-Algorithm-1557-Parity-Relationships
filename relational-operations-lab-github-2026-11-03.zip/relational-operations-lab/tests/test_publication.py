"""Check public contents and offline operation; no external connections."""
import json
from pathlib import Path
import re
import socket
import unittest
from unittest.mock import patch

from relational_operations.dataio import load_fixture, verify_data


ROOT=Path(__file__).resolve().parents[1]


class PublicationTests(unittest.TestCase):
    def test_data_roles_and_no_operational_identifiers(self):
        forbidden={'sessionId','jobId','modelId','projectId','checkpointSha256','sourcePins','catalogPin','envelopePin'}
        def visit(value):
            if isinstance(value,dict):
                self.assertFalse(set(value)&forbidden)
                for child in value.values():visit(child)
            elif isinstance(value,list):
                for child in value:visit(child)
        for name in ('records.json','covariance_records.json'):
            data=load_fixture(name);visit(data)
            self.assertEqual(data['license'],'CC-BY-4.0')
            self.assertTrue(all(row['role'].startswith('RECORDED_PHYSICAL') for row in data['records']))

    def test_code_and_embedded_demos_have_no_workstation_paths(self):
        excluded={'.git','__pycache__','build','dist'}
        for path in ROOT.rglob('*'):
            if not path.is_file() or any(part in excluded or part.endswith('.egg-info') for part in path.relative_to(ROOT).parts):
                continue
            if path.suffix not in ('.py','.md','.json','.html','.yml','.toml','.cff','.svg','.txt'):
                continue
            text=path.read_text(encoding='utf-8')
            # Do not scan the literal validation patterns in this source file.
            if path==Path(__file__).resolve():
                continue
            self.assertIsNone(re.search(r'(?i)\b[a-z]:[/\\]',text),path.as_posix())
            self.assertNotIn('X-Amz-',text,path.as_posix())
            self.assertIsNone(re.search(r'\b[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}\b',text),path.as_posix())

    def test_verification_runs_with_network_connections_blocked(self):
        with patch.object(socket.socket,'connect',side_effect=AssertionError('Network access forbidden')):
            self.assertEqual(verify_data()['status'],'PASS')


if __name__=='__main__':
    unittest.main()
