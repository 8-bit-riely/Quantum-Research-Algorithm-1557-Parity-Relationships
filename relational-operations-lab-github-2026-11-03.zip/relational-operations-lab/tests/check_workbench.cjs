'use strict';
// Offline JavaScript/DOM-output checks. No browser service or sample generation.
const fs = require('fs'), vm = require('vm'), assert = require('assert');
assert(process.argv[2], 'Usage: node tests/check_workbench.cjs PATH/triple.html');
const html = fs.readFileSync(process.argv[2], 'utf8');
const embedded = html.match(/<script id="retained-data" type="application\/json">([\s\S]*?)<\/script>/)[1];
const scripts = [...html.matchAll(/<script(?: [^>]*)?>([\s\S]*?)<\/script>/g)];
const elements = new Map();
function get(id) {
  if (!elements.has(id)) elements.set(id, {value: '', textContent: '', innerHTML: '', disabled: false, min: '', max: ''});
  return elements.get(id);
}
get('retained-data').textContent = embedded;
const sandbox = {window: {}, document: {getElementById: get}, console};
vm.createContext(sandbox); vm.runInContext(scripts.at(-1)[1], sandbox);
const api = sandbox.window.RelationWorkbench;
function publicData(value) {
  if (typeof value === 'string') {
    assert(!/[A-Za-z]:[\\/]|file:\/\/|https?:\/\/|X-Amz-|downloadUrl/i.test(value), 'Nonpublic data path or URL');
    assert(!/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i.test(value), 'Operational identifier in data');
  } else if (Array.isArray(value)) value.forEach(publicData);
  else if (value && typeof value === 'object') for (const [key, item] of Object.entries(value)) {
    assert(!/^(path|sessionId|jobId|modelId|projectId|accountId|checkpointSha256|downloadUrl|token|secret)$/i.test(key), 'Nonpublic data field');
    publicData(item);
  }
}
publicData(api.data); assert(!html.includes('__RELATION_DATA__'));
let viewsChecked = 0, emptyGroups = 0;
for (let index = 0; index < api.data.records.length; index++) for (const arity of [2, 3]) {
  const base = api.design(index, arity, 0);
  for (const d of [base.lower, 0, base.upper]) for (const a of ['all', '0', '1']) for (const c of ['all', '0', '1']) {
    get('dataset').value = String(index); get('arity').value = String(arity); get('shift').value = String(d);
    get('givenA').value = a; get('givenC').value = c;
    const result = api.refresh(); assert(result.valid && result.allProperMarginalsPreserved);
    assert(get('invariant').textContent.startsWith('PASS')); assert(get('categories').innerHTML.includes('<code>'));
    const query = api.conditional(result.changed, arity, a, c);
    if (query.support === 0) { emptyGroups++; assert.strictEqual(query.probability, null); }
    const spec = api.exportSpecification();
    assert.strictEqual(spec.mode, 'ANALYTIC_TABLE_SPECIFICATION'); assert.strictEqual(spec.samplesGenerated, 0);
    assert.strictEqual(spec.properMarginalsPreserved, true);
    assert(spec.provenance && Object.keys(spec.provenance).every(key => key.endsWith('Sha256')));
    assert(!('sourcePins' in spec)); publicData(spec); viewsChecked++;
  }
  assert.throws(() => api.design(index, arity, base.lower - 1));
  assert.throws(() => api.design(index, arity, base.upper + 1));
}
const original = api.data.records.findIndex(record => record.recordId === 'E32:S04');
for (const [d, ones] of [[-8, 0], [0, 8], [3, 11]]) {
  const view = api.design(original, 3, d), query = api.conditional(view.changed, 3, '1', '0');
  assert.strictEqual(query.support, 13); assert.strictEqual(query.ones, ones);
}
console.log(JSON.stringify({status: 'PASS', records: api.data.records.length, viewsChecked,
  emptyGroupsHandled: emptyGroups, originalConditionGroupUnits: 13,
  originalConditionalBOneCountsAcrossDesigns: [0, 8, 11], hashesOnlyExportProvenance: true,
  newMeasurements: 0, samplesGenerated: 0}));
