#!/usr/bin/env python3
"""Support-aware geometry of finite binary tables at fixed singles/pair margins.

Established baseline: coordinate-maximization linear programs expose feasible
support.  This research extension adds exact, independently checkable rational
certificates when the numerical LP solutions can be reconstructed exactly.
It does not claim a new LP, Fourier identity, or scientific theory.

Dependencies: Python >=3.11, NumPy, SciPy (scipy.optimize.linprog / HiGHS).
Command: python support_geometry.py --output geometry_results.json
Optional original release cross-check: add --source-dir /path/to/extracted/release
No provider, network, model, or physical-hardware access occurs. Optional
--source-dir reads public release data only; it executes no original source code.
"""
from __future__ import annotations

import argparse
import hashlib
from fractions import Fraction as F
from itertools import combinations
from math import gcd, lcm
from pathlib import Path
import json
import platform
import time

import numpy as np
import scipy
from scipy.optimize import linprog


EXAMPLES = [
    {
        "name": "original_four_bit",
        "bits": [5, 6, 10, 11],
        "counts": [450, 252, 7, 3, 28, 34, 0, 0, 4, 10, 1, 0, 8, 3, 0, 0],
        "expected_dimension": 2,
        "source": "E32:S04; published projection in docs/METHODS.md and verified covariance decode",
    },
    {
        "name": "alternate_four_bit",
        "bits": [2, 5, 6, 11],
        "counts": [419, 71, 6, 31, 3, 8, 5, 2, 38, 184, 22, 3, 2, 2, 3, 1],
        "expected_dimension": 5,
        "source": "E32:S04; decoded from published covariance_records.json and checked against its logicalCounts",
    },
    {
        "name": "three_bit_implicit_zero_counterexample",
        "bits": [0, 1, 2],
        "counts": [0, 1, 1, 1, 1, 1, 1, 0],
        "expected_dimension": 0,
        "source": "Analytical synthetic example, not physical measurement",
    },
]


def q(value: F) -> str:
    return str(value)


def parity_sign(word: int) -> int:
    return -1 if word.bit_count() & 1 else 1


def constraints(n: int):
    masks = [0] + [m for degree in (1, 2) for m in range(1, 1 << n) if m.bit_count() == degree]
    rows = [[F(parity_sign(word & mask)) for word in range(1 << n)] for mask in masks]
    return masks, rows


def dot(a, b):
    return sum((x * y for x, y in zip(a, b)), F(0))


def matvec(A, x):
    return [dot(row, x) for row in A]


def rref(matrix):
    work = [[F(v) for v in row] for row in matrix]
    if not work:
        return work, []
    width = len(work[0])
    if any(len(row) != width for row in work):
        raise ValueError("Rectangular matrix required")
    pivots = []
    pivot_row = 0
    for col in range(width):
        candidate = next((i for i in range(pivot_row, len(work)) if work[i][col]), None)
        if candidate is None:
            continue
        work[pivot_row], work[candidate] = work[candidate], work[pivot_row]
        scale = work[pivot_row][col]
        work[pivot_row] = [v / scale for v in work[pivot_row]]
        for i in range(len(work)):
            if i == pivot_row:
                continue
            scale = work[i][col]
            if scale:
                work[i] = [v - scale * w for v, w in zip(work[i], work[pivot_row])]
        pivots.append(col)
        pivot_row += 1
        if pivot_row == len(work):
            break
    return work, pivots


def primitive_integer(vector):
    denominator = 1
    for v in vector:
        denominator = lcm(denominator, v.denominator)
    integers = [int(v * denominator) for v in vector]
    divisor = 0
    for v in integers:
        divisor = gcd(divisor, abs(v))
    if divisor:
        integers = [v // divisor for v in integers]
    first = next((v for v in integers if v), 0)
    if first < 0:
        integers = [-v for v in integers]
    return integers


def exact_nullspace(A, support, width):
    restricted = [[row[i] for i in support] for row in A]
    reduced, pivots = rref(restricted)
    basis = []
    for free in (j for j in range(len(support)) if j not in pivots):
        local = [F(0)] * len(support)
        local[free] = F(1)
        for row, pivot in enumerate(pivots):
            local[pivot] = -reduced[row][free]
        full = [F(0)] * width
        for i, value in zip(support, local):
            full[i] = value
        full = primitive_integer(full)
        assert matvec(A, full) == [0] * len(A)
        basis.append(full)
    return len(pivots), basis


def exact_solve_columns(columns, target):
    """Return unique exact coefficients, or None if the target is not spanned."""
    if not columns:
        return [] if not any(target) else None
    k = len(columns)
    matrix = [[F(column[i]) for column in columns] + [F(target[i])] for i in range(len(target))]
    reduced, pivots = rref(matrix)
    if k in pivots:
        return None
    if len(pivots) != k:
        raise ValueError("Expected linearly independent columns")
    result = [F(0)] * k
    for row, pivot in enumerate(pivots):
        result[pivot] = reduced[row][-1]
    assert [sum((a * col[i] for a, col in zip(result, columns)), F(0)) for i in range(len(target))] == list(target)
    return result


def rationalize(values, max_denominator):
    return [F(float(v)).limit_denominator(max_denominator) for v in values]


def feasible_exact(A, b, vector):
    return all(v >= 0 for v in vector) and matvec(A, vector) == list(b)


def pair_marginal(vector, n, chosen):
    out = [F(0)] * (1 << len(chosen))
    for word, value in enumerate(vector):
        category = 0
        for position in chosen:
            category = (category << 1) | ((word >> (n - 1 - position)) & 1)
        out[category] += value
    return out


def all_pair_direction_checks(vector, n):
    return sum(vector) == 0 and all(
        pair_marginal(vector, n, chosen) == [0] * (1 << size)
        for size in range(1, min(n, 2) + 1)
        for chosen in combinations(range(n), size)
    )


def zero_marginal_only_dimension(A, p, n):
    """Replicate the limited zero-cell inference, to expose what it misses."""
    forced = set()
    for size in range(1, min(n, 2) + 1):
        for chosen in combinations(range(n), size):
            marginal = pair_marginal(p, n, chosen)
            for word in range(1 << n):
                category = 0
                for position in chosen:
                    category = (category << 1) | ((word >> (n - 1 - position)) & 1)
                if marginal[category] == 0:
                    forced.add(word)
    allowed = [i for i in range(1 << n) if i not in forced]
    rank = len(rref([[row[i] for i in allowed] for row in A])[1])
    return {"directly_forced_zero_categories": sorted(forced), "affine_dimension_upper_bound": len(allowed) - rank}


def analyze(bits, counts, tol=1e-9, max_denominator=10**9, include_certificates=True):
    start = time.perf_counter()
    n = len(bits)
    if not 1 <= n <= 6 or len(set(bits)) != n:
        raise ValueError("This finite research implementation accepts 1..6 distinct bit labels")
    if len(counts) != 1 << n or any(type(c) is not int or c < 0 for c in counts) or sum(counts) <= 0:
        raise ValueError("Complete nonnegative integer count table required")
    N = sum(counts)
    p = [F(c, N) for c in counts]
    masks, A = constraints(n)
    b = matvec(A, p)
    A_float = np.asarray(A, dtype=float)
    b_float = np.asarray(b, dtype=float)
    support, forced_zero, unresolved = [], [], []
    records, witnesses = [], []
    lp_seconds = 0.0
    for category in range(1 << n):
        objective = np.zeros(1 << n)
        objective[category] = -1.0
        lp_start = time.perf_counter()
        result = linprog(
            objective, A_eq=A_float, b_eq=b_float, bounds=(0, None), method="highs",
            options={"primal_feasibility_tolerance": tol, "dual_feasibility_tolerance": tol},
        )
        lp_seconds += time.perf_counter() - lp_start
        if not result.success:
            raise RuntimeError(f"LP for category {category} failed: {result.message}")
        maximum = -float(result.fun)
        numeric = "positive_above_tolerance" if maximum > tol else "at_or_below_tolerance"
        primal = rationalize(result.x, max_denominator)
        primal_ok = feasible_exact(A, b, primal)
        # For max p_i, a valid upper-bound certificate has A^T lambda >= e_i.
        dual = rationalize(-result.eqlin.marginals, max_denominator)
        dual_slack = [sum((A[j][i] * dual[j] for j in range(len(A))), F(0)) - int(i == category) for i in range(1 << n)]
        dual_ok = all(v >= 0 for v in dual_slack)
        upper = dot(b, dual) if dual_ok else None
        witness = primal if primal_ok and primal[category] > 0 else (p if p[category] > 0 else None)
        if witness is not None:
            classification = "positive_exact_witness"
            support.append(category)
            witnesses.append(witness)
        elif dual_ok and upper == 0:
            classification = "forced_zero_exact_dual"
            forced_zero.append(category)
        else:
            classification = "unresolved"
            unresolved.append(category)
        optimum_verified = primal_ok and dual_ok and primal[category] == upper
        record = {
            "category": category, "word": format(category, f"0{n}b"),
            "numeric_maximum": maximum, "numeric_classification": numeric,
            "exact_classification": classification,
            "exact_optimum_verified": optimum_verified,
            "exact_primal_lower_bound": q(primal[category]) if primal_ok else None,
            "exact_dual_upper_bound": q(upper) if dual_ok else None,
        }
        if include_certificates:
            record.update({
                "rationalized_primal": [q(v) for v in primal] if primal_ok else None,
                "support_witness": [q(v) for v in witness] if witness is not None else None,
                "upper_bound_dual": [q(v) for v in dual] if dual_ok else None,
                "upper_bound_dual_slack": [q(v) for v in dual_slack] if dual_ok else None,
            })
        records.append(record)
    rank, basis = exact_nullspace(A, support, len(p))
    certified = not unresolved
    interior = [sum((x[i] for x in witnesses), F(0)) / len(witnesses) for i in range(len(p))]
    interior_ok = feasible_exact(A, b, interior) and all(interior[i] > 0 for i in support) and all(interior[i] == 0 for i in forced_zero)
    independent_direction_checks = all(all_pair_direction_checks(v, n) for v in basis)
    assert interior_ok and independent_direction_checks
    # Positive feasible support plus exact exclusion of its complement certifies
    # that the affine slice has a relative interior in this coordinate face.
    exact_dimension = len(support) - rank if certified and interior_ok else None
    summary = {
        "bits": list(bits), "counts": list(counts), "total_count_units": N,
        "constraint_masks": masks, "constraint_targets": [q(v) for v in b],
        "numerical_tolerance": tol, "rational_reconstruction_max_denominator": max_denominator,
        "support_complete_exactly_certified": certified,
        "feasible_support": support, "forced_zero_categories": forced_zero, "unresolved_categories": unresolved,
        "rank_on_feasible_support": rank, "exact_feasible_dimension": exact_dimension,
        "exact_interior": [q(v) for v in interior], "exact_interior_verified": interior_ok,
        "primitive_integer_nullspace_basis": basis,
        "independent_pair_marginal_direction_checks": independent_direction_checks,
        "zero_marginal_only_result": zero_marginal_only_dimension(A, p, n),
        "all_coordinate_optima_exactly_verified": all(r["exact_optimum_verified"] for r in records),
        "coordinate_results": records,
        "timing_seconds": {"coordinate_lps": lp_seconds, "total": time.perf_counter() - start},
    }
    return summary


def named_direction(bits, selected, context):
    n = len(bits)
    mask = sum(1 << (n - 1 - bits.index(b)) for b in selected)
    out = []
    for word in range(1 << n):
        matched = all(((word >> (n - 1 - bits.index(b))) & 1) == v for b, v in context.items())
        out.append(parity_sign(word & mask) if matched else 0)
    return out


def original_direction_comparison(result):
    bits = result["bits"]
    U = named_direction(bits, [5, 6, 11], {10: 0})
    V = named_direction(bits, [5, 10, 11], {6: 0})
    basis = result["primitive_integer_nullspace_basis"]
    return {
        "U": U, "V": V,
        "U_coefficients_in_recovered_basis": [q(v) for v in exact_solve_columns(basis, U)],
        "V_coefficients_in_recovered_basis": [q(v) for v in exact_solve_columns(basis, V)],
        "recovered_basis_coefficients_in_U_V": [[q(v) for v in exact_solve_columns([U, V], column)] for column in basis],
        "same_span_exactly_verified": True,
        "meaning": "The automatically recovered feasible directions span the already published U/V family; this is reproduction, not a new physical direction.",
    }


def counterexample_facet_certificate():
    example = EXAMPLES[2]
    masks, A = constraints(3)
    p = [F(c, sum(example["counts"])) for c in example["counts"]]
    b = matvec(A, p)
    dual = [F(1, 4) if mask in (0, 3, 5, 6) else F(0) for mask in masks]
    values = [sum((A[j][i] * dual[j] for j in range(len(A))), F(0)) for i in range(8)]
    assert values == [1, 0, 0, 0, 0, 0, 0, 1]
    assert dot(b, dual) == 0
    rows = []
    for word in range(8):
        values_bits = [int(v) for v in format(word, "03b")]
        disagreements = sum(values_bits[a] != values_bits[b] for a, b in combinations(range(3), 2))
        rows.append({"word": format(word, "03b"), "pair_disagreements": disagreements, "facet_slack": 2 - disagreements})
    return {
        "inequality": "D01 + D02 + D12 <= 2 for each binary triple",
        "observed_pair_disagreement_probabilities": ["2/3", "2/3", "2/3"],
        "observed_expected_disagreements": "2",
        "deduction": "Expected nonnegative slack is zero. The slack is 2 exactly at 000 and 111, so both cell probabilities are forced to zero by the pair constraints.",
        "equivalent_pair_moment_certificate": "(1 + m01 + m02 + m12)/4 = P(000) + P(111) = 0",
        "constraint_masks": masks, "dual_coefficients": [q(v) for v in dual],
        "dual_truth_table": [q(v) for v in values], "truth_table": rows,
        "certificate_checked_exactly": True,
    }


def exhaustive_three_bit_support_audit(tol=1e-9, max_denominator=10**9):
    start = time.perf_counter()
    cases = []
    dimension_counts = {0: 0, 1: 0}
    missed_geometry = []
    # Every nonempty subset of the eight categories; uniform mass on its support.
    # This exhausts support patterns, not all rational probability assignments.
    for pattern in range(1, 1 << 8):
        counts = [(pattern >> i) & 1 for i in range(8)]
        p = [F(v, sum(counts)) for v in counts]
        even = [p[i] for i in range(8) if parity_sign(i) == 1]
        odd = [p[i] for i in range(8) if parity_sign(i) == -1]
        low, high = -min(even), min(odd)
        dimension = int(low < high)
        analytic_maxima = [p[i] + parity_sign(i) * (high if parity_sign(i) == 1 else low) for i in range(8)]
        support = [i for i, value in enumerate(analytic_maxima) if value > 0]
        computed = analyze([0, 1, 2], counts, tol, max_denominator, include_certificates=False)
        assert computed["support_complete_exactly_certified"]
        assert computed["exact_feasible_dimension"] == dimension
        assert computed["feasible_support"] == support
        assert computed["all_coordinate_optima_exactly_verified"]
        assert [F(r["exact_primal_lower_bound"]) for r in computed["coordinate_results"]] == analytic_maxima
        dimension_counts[dimension] += 1
        naive_dimension = computed["zero_marginal_only_result"]["affine_dimension_upper_bound"]
        if naive_dimension != dimension:
            missed_geometry.append({"pattern": pattern, "counts": counts, "exact_dimension": dimension, "zero_marginal_only_dimension": naive_dimension})
        cases.append({"pattern": pattern, "counts": counts, "exact_dimension": dimension, "feasible_support": support, "all_eight_optima_exactly_verified": True})
    return {
        "scope": "Exhaustive over 255 nonempty category-support patterns; one uniform table per pattern. Not an exhaustive enumeration of every rational table.",
        "independent_oracle": "For three binary variables the full fixed-pair family is p_i + t*(-1)^popcount(i), with exact t interval [-min(even), min(odd)].",
        "cases_checked": len(cases), "coordinate_maxima_checked": len(cases) * 8,
        "mismatches": 0, "dimension_counts": dimension_counts,
        "zero_marginal_only_overcounts": missed_geometry,
        "timing_seconds": time.perf_counter() - start,
        "cases": cases,
    }



def crosscheck_original_release(source_dir):
    """Read data only; never import or execute the original release."""
    data_dir = source_dir / "relational_operations" / "data"
    manifest = json.loads((data_dir / "MANIFEST.json").read_text(encoding="utf-8"))
    pins = {item["path"]: item["sha256"] for item in manifest["files"]}
    archive_path = data_dir / "covariance_records.json"
    raw = archive_path.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    if digest != pins[archive_path.name]:
        raise ValueError("Original public covariance file differs from its release manifest")
    data = json.loads(raw)
    records = [r for r in data["records"] if r["recordId"] == "E32:S04"]
    if len(records) != 1:
        raise ValueError("Expected exactly one E32:S04 record")
    record = records[0]
    verified = []
    for example in EXAMPLES[:2]:
        counts = [0] * (1 << len(example["bits"]))
        for word, count in record["logicalCounts"].items():
            value = int(word, 2)
            key = 0
            for bit in example["bits"]:
                key = (key << 1) | ((value >> bit) & 1)
            counts[key] += count
        if counts != example["counts"]:
            raise ValueError(f"Embedded projection differs from source: {example['name']}")
        verified.append({"name": example["name"], "bits": example["bits"], "counts_agree_exactly": True})
    return {
        "mode": "Original data read and hash-checked; no source-code execution",
        "record_id": "E32:S04",
        "covariance_file_sha256": digest,
        "verified_projections": verified,
        "caution": "Manifest/hash agreement establishes consistency with the provided release, not independent authentication of physical provenance.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=Path("geometry_results.json"))
    parser.add_argument("--skip-exhaustive", action="store_true")
    parser.add_argument("--source-dir", type=Path, help="Optional original release directory; cross-check embedded tables against its manifest-pinned public histogram")
    parser.add_argument("--tol", type=float, default=1e-9)
    args = parser.parse_args()
    if not 1e-10 <= args.tol <= 1e-4:
        parser.error("tol must be between 1e-10 and 1e-4 (HiGHS-supported range)")
    start = time.perf_counter()
    examples = []
    for example in EXAMPLES:
        result = analyze(example["bits"], example["counts"], args.tol)
        result.update({"name": example["name"], "source": example["source"], "expected_dimension": example["expected_dimension"]})
        assert result["exact_feasible_dimension"] == example["expected_dimension"]
        examples.append(result)
        print(f'{example["name"]}: dimension={result["exact_feasible_dimension"]}; support={len(result["feasible_support"])}; exact_support_certificate={result["support_complete_exactly_certified"]}; time={result["timing_seconds"]["total"]:.4f}s', flush=True)
    report = {
        "title": "Support-aware fixed-pair geometry research extension",
        "version": "0.1.0-research",
        "status": "Research reproduction and robustness extension; no novelty claim",
        "method": "One numerical LP per category, followed by exact rational primal/dual verification and exact nullspace computation.",
        "environments": {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__},
        "reproduce_command": "python support_geometry.py --output geometry_results.json",
        "dependencies": ["Python >=3.11", "numpy", "scipy"],
        "classification_policy": "Numerical tolerance is reported separately. A category is positively feasible only with an exact feasible witness, and forced zero only with an exact dual upper bound of zero. Uncertified categories remain unresolved and suppress the exact dimension claim.",
        "limitations": [
            "Coordinate LP support discovery is an established baseline, not a new optimization algorithm.",
            "LP solves are numerical; rational reconstruction may fail for difficult or high-denominator inputs. Such cases must remain unresolved.",
            "Runtime grows with 2^n cells and 2^n LP solves; this implementation deliberately caps n at 6 and has only audited small examples.",
            "All geometry conditions on the supplied exact empirical margins; a sample zero is not proof of a population zero.",
            "No new physical observations, human-behavior observations, model training, or paid service calls are performed.",
        ],
        "examples": examples,
        "original_direction_comparison": original_direction_comparison(examples[0]),
        "counterexample_facet_certificate": counterexample_facet_certificate(),
    }
    report["original_release_crosscheck"] = crosscheck_original_release(args.source_dir) if args.source_dir else {"mode": "Self-contained embedded examples; supply --source-dir to cross-check original release data"}
    if not args.skip_exhaustive:
        audit = exhaustive_three_bit_support_audit(args.tol)
        report["three_bit_exhaustive_support_audit"] = audit
        print(f'exhaustive support audit: {audit["cases_checked"]} cases; {audit["coordinate_maxima_checked"]} exact optimum checks; {len(audit["zero_marginal_only_overcounts"])} limited-geometry overcounts; time={audit["timing_seconds"]:.4f}s', flush=True)
    report["total_runtime_seconds"] = time.perf_counter() - start
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(f"Wrote {args.output.resolve()}", flush=True)


if __name__ == "__main__":
    main()
