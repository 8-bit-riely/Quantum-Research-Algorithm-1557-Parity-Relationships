# Support-aware fixed-pair geometry

This standalone research extension discovers every table category that can carry
positive probability while normalization, individual means, and all pair means
remain fixed. It leaves the original Relational Operations Lab release untouched.

The method uses an established linear-programming baseline. Its contribution in
this investigation is an implemented support audit with exact verifiable
certificates and an automatic reproduction of the release's coupled directions.
It makes no claim of a new theorem, quantum advantage, or behavioral prediction.

## Reproduce

From this directory, with Python, NumPy, and SciPy installed:

```bash
python support_geometry.py --output geometry_results.json
python verify_geometry_certificate.py geometry_results.json
```

To cross-check the two embedded physical-record projections against an extracted
original release, use the optional source argument:

```bash
python support_geometry.py --source-dir /path/to/relational-operations-lab-v0.1.0-experimental --output geometry_results.json
```

The source check reads the public data, validates the covariance file against its
release manifest, and projects the public histogram directly. It does not import
or execute original source code. Without `--source-dir`, the calculation uses the
explicit counts embedded in this script. Both paths are portable.

The recorded environment used Python 3.12.14, NumPy 2.3.5, and SciPy 1.17.0. The
independent certificate verifier needs only the Python standard library.

`--skip-exhaustive` omits the 255-pattern audit; `--tol` controls the numerical
LP tolerance. The Python `analyze(bits, counts)` function can be called with a
separate complete integer count table of up to six binary variables. That cap
keeps this extension finite; it is not a demonstrated large-scale solver.

## Findings

| Table | Feasible categories | Exact rank on support | Exact feasible dimension | Dimension inferred only from zero marginal cells |
|---|---:|---:|---:|---:|
| E32:S04, bits 5, 6, 10, 11 | 12 | 10 | 2 | 2 |
| E32:S04, bits 2, 5, 6, 11 | 16 | 11 | 5 | 5 |
| Synthetic three-bit counterexample | 6 | 6 | 0 | 1 |

All 40 coordinate maxima across these three tables have matching exact rational
primal and dual certificates in `geometry_results.json`. The feasible support,
positive interior, nullspace, and dimension are verified exactly. The independent
verifier checks those certificates without invoking a numerical optimizer.

The automatically obtained primitive integer basis for the first table is
**exactly the published V and U directions, in that order**. The script verifies
both spanning directions. This reproduces the earlier controls automatically;
it does not discover a new physical control.

### What the old support inference misses

The synthetic counts are:

```text
category: 000 001 010 011 100 101 110 111
counts:     0   1   1   1   1   1   1   0
```

Every pair marginal is `[1/6, 1/3, 1/3, 1/6]`, with no zero cells. Nevertheless,
000 and 111 are forced to remain zero by the combined constraints.

For three binary answers, the number of disagreeing pairs is either zero (all
answers agree) or two. Thus `D01 + D02 + D12 <= 2` for every row. These pair
marginals give an expected disagreement sum of exactly two. Every feasible row
must therefore attain two; the all-equal rows cannot occur.

Equivalently, the nonnegative function

```text
(1 + parity01 + parity02 + parity12) / 4
```

is the indicator of `{000, 111}` and has expected value zero. This is an exact
pair-information certificate that both cells are forced zero.

The full three-bit fixed-pair family is `p_i + t * paritySign(i)`. Its two zero
cells require `t >= 0` and `t <= 0`, respectively. Only `t = 0` is feasible.

### Exhaustive small-case check

The audit examined all **255 nonempty support patterns** on three binary
variables, assigning uniform probability within each pattern. An independent
analytic parity-interval formula supplied the expected support, dimension, and
each coordinate maximum.

- All 2,040 coordinate maxima matched that analytic formula exactly after
  rational certificate verification.
- 224 tables had zero feasible degrees of freedom; 31 had one.
- In four patterns, inference using only zero marginal cells reported one
  affine degree when the actual nonnegative feasible family was a singleton.
- The four problematic supports exclude an antipodal pair: `{000,111}`,
  `{001,110}`, `{010,101}`, or `{011,100}`.

This exhausts the selected support-pattern family. It is not an enumeration of
all rational distributions or a validation on human observations.

## Numerical calculation versus exact evidence

For each category i, solve `max p_i` subject to `A p = b` and `p >= 0`. A contains
normalization and the parity features of degree one or two. Fixing those features
is equivalent to fixing every individual and pair table.

HiGHS solves these LPs numerically, using a recorded default tolerance of 1e-9.
The script then reconstructs rational candidates with denominator at most 1e9
and checks them using exact fractions:

- A positive feasible primal witness proves the category can occur.
- A dual vector with `A^T lambda >= e_i` and `b^T lambda = 0` proves it cannot.
- A primal value equal to a dual bound certifies the exact coordinate optimum.

The arithmetic checks use equality over rational numbers, not a floating-point
closeness test. The LP tolerance and its numeric classification remain visible
in the report. If certificates fail, the category stays unresolved and the
script does not claim an exact complete-support dimension.

Averaging the positive-coordinate witnesses supplies a feasible point strictly
positive on the discovered support. Once the complement is excluded by dual
certificates, the dimension is `support_size - exact_rank(A_on_support)`. An exact
rational nullspace provides all allowed infinitesimal directions. Direct marginal
sums independently check that the recovered directions preserve the requested
statistics.

## Measured runtime and limitations

The saved run's internal total was approximately 3.23 seconds, including the
255-pattern audit. The three named examples took approximately 0.037, 0.035, and
0.012 seconds; the exhaustive audit took approximately 3.08 seconds. These are
single-run wall-clock measurements from this environment, excluding interpreter
startup and imports. They do not establish a speed advantage over another tool.

The method requires one LP per category and an explicit table, so growth is
exponential in the number of variables. Rational reconstruction can fail for
large-denominator or ill-conditioned instances. The method conditions on exact
supplied empirical margins: observed zeros do not prove population zeros.

No new physical measurements, human-behavior data, AI training, paid calls, or
modifications to the original release were performed.

## Audit all 64 released projections

The follow-up archive audit applies the same exact certificate method to both
named four-bit views of every retained record. See `archive_geometry_summary.md`
for the full findings and per-record map. Run:

```bash
python audit_archive_geometry.py --source-dir /path/to/extracted/original-release --output archive_geometry_results.json
python verify_geometry_certificate.py archive_geometry_results.json
```

All eleven cases without any initial pure-axis or simple-context move are exactly
unique at the supplied pair margins. Across the archive the complete family
dimensions are 11 zero-dimensional, 23 one-dimensional, 17 two-dimensional, and
13 five-dimensional. In eleven nontrivial views, currently movable simple context
directions span fewer than the full five dimensions. These are further analyses
of the same 32 records and 25,600 shots; no new physical trials were performed.
