#!/usr/bin/env python3
"""Audit exact fixed-pair geometry across two named views of all 32 retained records.

Usage:
  python audit_archive_geometry.py --source-dir /path/to/original-release \
      --output archive_geometry_results.json
  python verify_geometry_certificate.py archive_geometry_results.json

This script imports the standalone support_geometry extension, not the original
release. It reads manifest-pinned public data only. The 64 projections are two
views of the same 32 records / 25,600 shots, not 64 independent experiments.
"""
from __future__ import annotations

import argparse
from collections import Counter
from fractions import Fraction as F
import hashlib
from itertools import combinations
import json
from pathlib import Path
import time

from support_geometry import analyze, constraints, matvec, named_direction, rref
from verify_geometry_certificate import verify_example


EXPECTED_HASHES = {
    "covariance_records.json": "da205e10b740da138b8fd7e5579dcd4710c6836c90200165b3c747707a020891",
    "records.json": "433d71923560afd378c80d6d105ca21995a64e25dd9b4cb37eee4bb4a16e7038",
}
VIEWS = [
    ("original", [5, 6, 10, 11]),
    ("alternate", [2, 5, 6, 11]),
]


def require(ok, message):
    if not ok:
        raise ValueError(message)


def load_archive(source_dir):
    data_dir = source_dir / "relational_operations" / "data"
    manifest = json.loads((data_dir / "MANIFEST.json").read_text(encoding="utf-8"))
    pins = {entry["path"]: entry for entry in manifest["files"]}
    inputs = {}
    verified = []
    for name, expected in EXPECTED_HASHES.items():
        raw = (data_dir / name).read_bytes()
        actual = hashlib.sha256(raw).hexdigest()
        require(actual == expected == pins[name]["sha256"], f"Unexpected source hash: {name}")
        require(len(raw) == pins[name]["bytes"], f"Unexpected source length: {name}")
        inputs[name] = json.loads(raw)
        verified.append({"path": name, "sha256": actual, "bytes": len(raw), "expected_release_hash_agrees": True})
    archive = inputs["covariance_records.json"]
    require(len(archive["records"]) == 32, "Expected 32 retained records")
    expected_ids = [f"E32:S{i:02d}" for i in range(1, 33)]
    require([r["recordId"] for r in archive["records"]] == expected_ids, "Unexpected record identities or order")
    for record in archive["records"]:
        require(type(record["shots"]) is int and record["shots"] > 0, "Invalid shot count")
        require(sum(record["logicalCounts"].values()) == record["shots"], "Histogram total differs")
        require(all(len(word) == 12 and set(word) <= {"0", "1"} and type(c) is int and c >= 0 for word, c in record["logicalCounts"].items()), "Invalid logical histogram")
    require(sum(r["shots"] for r in archive["records"]) == 25600, "Unexpected retained shot total")
    return archive, verified


def project_counts(histogram, bits):
    counts = [0] * (1 << len(bits))
    for word, count in histogram.items():
        value = int(word, 2)
        category = 0
        for bit in bits:
            category = (category << 1) | ((value >> bit) & 1)
        counts[category] += count
    return counts


def interval(p, direction):
    require(any(direction) and sum(direction) == 0, "Nonzero normalized direction required")
    low = max(-v / d for v, d in zip(p, direction) if d > 0)
    high = min(-v / d for v, d in zip(p, direction) if d < 0)
    require(low <= 0 <= high, "Invalid interval at feasible original table")
    return low, high


def describe_direction(p, N, bits, selected, context):
    vector = named_direction(bits, selected, context)
    low, high = interval(p, vector)
    return {
        "parity_bits": list(selected), "context": {str(k): v for k, v in context.items()},
        "vector": vector, "probability_interval": [str(low), str(high)],
        "count_unit_interval": [str(N * low), str(N * high)],
        "movable": low < high,
    }


def direction_inventory(result):
    bits = result["bits"]
    counts = result["counts"]
    N = sum(counts)
    p = [F(c, N) for c in counts]
    pure = [describe_direction(p, N, bits, chosen, {}) for degree in (3, 4) for chosen in combinations(bits, degree)]
    context = [describe_direction(p, N, bits, [b for b in bits if b != held], {held: value}) for held in bits for value in (0, 1)]
    feasible_context = [d["vector"] for d in context if d["movable"]]
    context_rank = len(rref(feasible_context)[1]) if feasible_context else 0
    basis_intervals = [interval(p, v) for v in result["primitive_integer_nullspace_basis"]]
    return {
        "pure_axes": pure, "simple_context_directions": context,
        "pure_axes_movable": sum(d["movable"] for d in pure),
        "all_five_pure_axes_blocked": not any(d["movable"] for d in pure),
        "simple_context_directions_movable": sum(d["movable"] for d in context),
        "simple_context_feasible_span_rank": context_rank,
        "nullspace_basis_individually_movable": sum(lo < hi for lo, hi in basis_intervals),
        "nullspace_basis_probability_intervals": [[str(lo), str(hi)] for lo, hi in basis_intervals],
    }


def nonzero_movement_witness(result):
    if result["exact_feasible_dimension"] == 0:
        return None
    counts = result["counts"]
    N = sum(counts)
    p = [F(c, N) for c in counts]
    target = list(map(F, result["exact_interior"]))
    if target == p:
        direction = result["primitive_integer_nullspace_basis"][0]
        radius = min(target[i] / abs(F(v)) for i, v in enumerate(direction) if v) / 2
        target = [x + radius * v for x, v in zip(target, direction)]
    delta = [y - x for x, y in zip(p, target)]
    masks, A = constraints(len(result["bits"]))
    require(any(delta), "Expected a nonzero movement")
    require(all(x >= 0 for x in target) and sum(target) == 1, "Invalid movement target")
    require(matvec(A, delta) == [0] * len(masks), "Movement changes fixed margins")
    low, high = interval(p, delta)
    require(low <= 0 <= 1 <= high, "Whole line segment to target is not feasible")
    higher = [m for m in range(1, 1 << len(result["bits"])) if m.bit_count() >= 3]
    moment_changes = []
    for mask in higher:
        change = sum((x if (i & mask).bit_count() % 2 == 0 else -x for i, x in enumerate(delta)), F(0))
        moment_changes.append({"local_mask": mask, "moment_change": str(change)})
    return {
        "target_probabilities": [str(v) for v in target],
        "delta_probabilities": [str(v) for v in delta],
        "delta_count_units": [str(N * v) for v in delta],
        "path_parameter_interval": [str(low), str(high)],
        "path_0_to_1_feasible_exactly": True,
        "higher_order_moment_changes": moment_changes,
        "total_variation_from_original": str(sum((abs(v) for v in delta), F(0)) / 2),
        "interpretation": "A mathematical probability-table design at the recorded margins, not an observed physical manipulation.",
    }


def compact_row(result):
    directions = result["direction_inventory"]
    return {
        "record_id": result["record_id"], "view": result["view"], "bits": result["bits"],
        "dimension": result["exact_feasible_dimension"], "feasible_support_size": len(result["feasible_support"]),
        "recorded_support_size": sum(v > 0 for v in result["counts"]),
        "pure_movable": directions["pure_axes_movable"],
        "context_movable": directions["simple_context_directions_movable"],
        "context_span_rank": directions["simple_context_feasible_span_rank"],
        "basis_individually_movable": directions["nullspace_basis_individually_movable"],
        "zero_marginal_only_affine_dimension": result["zero_marginal_only_result"]["affine_dimension_upper_bound"],
        "all_coordinate_optima_exactly_verified": result["all_coordinate_optima_exactly_verified"],
    }


def summarize(rows):
    blocked = [r for r in rows if r["pure_movable"] == 0]
    no_simple = [r for r in blocked if r["context_movable"] == 0]
    hidden = [r for r in no_simple if r["dimension"] > 0]
    return {
        "projections": len(rows),
        "dimension_histogram": dict(sorted(Counter(r["dimension"] for r in rows).items())),
        "all_pure_axes_blocked": len(blocked),
        "all_pure_axes_blocked_but_simple_context_movable": sum(r["context_movable"] > 0 for r in blocked),
        "all_pure_axes_and_simple_context_directions_blocked": len(no_simple),
        "all_simple_directions_blocked_and_exactly_unique": sum(r["dimension"] == 0 for r in no_simple),
        "all_simple_directions_blocked_but_other_movement_exists": len(hidden),
        "nontrivial_fixed_pair_families": sum(r["dimension"] > 0 for r in rows),
        "exactly_unique_fixed_pair_tables": sum(r["dimension"] == 0 for r in rows),
        "context_feasible_span_smaller_than_full_dimension": sum(r["context_span_rank"] < r["dimension"] for r in rows),
        "zero_marginal_only_dimension_overcounts": sum(r["zero_marginal_only_affine_dimension"] > r["dimension"] for r in rows),
        "recorded_support_smaller_than_feasible_support": sum(r["recorded_support_size"] < r["feasible_support_size"] for r in rows),
        "simple_blocked_cases": no_simple,
        "unexpected_movement_cases": hidden,
        "context_span_deficit_cases": [r for r in rows if r["context_span_rank"] < r["dimension"]],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path("archive_geometry_results.json"))
    parser.add_argument("--tol", type=float, default=1e-9)
    args = parser.parse_args()
    require(1e-10 <= args.tol <= 1e-4, "Tolerance outside supported range")
    start = time.perf_counter()
    archive, pins = load_archive(args.source_dir)
    results = []
    for record in archive["records"]:
        for view, bits in VIEWS:
            counts = project_counts(record["logicalCounts"], bits)
            result = analyze(bits, counts, args.tol, include_certificates=True)
            require(result["support_complete_exactly_certified"], f"Unresolved support: {record['recordId']} {view}")
            require(result["all_coordinate_optima_exactly_verified"], f"Uncertified coordinate optimum: {record['recordId']} {view}")
            verify_example(result)
            result["record_id"] = record["recordId"]
            result["view"] = view
            result["source_provenance"] = record["provenance"]
            result["direction_inventory"] = direction_inventory(result)
            result["nonzero_movement_witness"] = nonzero_movement_witness(result)
            results.append(result)
    rows = [compact_row(r) for r in results]
    overall = summarize(rows)
    by_view = {view: summarize([r for r in rows if r["view"] == view]) for view, _ in VIEWS}
    # Independent reproduction of the prior simple-direction inventory.
    require(overall["all_pure_axes_blocked"] == 62, "Prior five-axis inventory disagrees")
    require(overall["all_pure_axes_blocked_but_simple_context_movable"] == 51, "Prior context inventory disagrees")
    require(overall["all_pure_axes_and_simple_context_directions_blocked"] == 11, "Expected eleven unresolved-by-simple-controls cases")
    report = {
        "title": "Exact support-aware geometry of all 64 retained four-bit projections",
        "schema": "archive-fixed-pair-geometry/1",
        "method": "Coordinate-max LP discovery followed by exact rational primal/dual, interior, rank and nullspace verification; independent certificate verifier invoked for every projection.",
        "provenance": {
            "unique_record_count": 32, "unique_record_shots": 25600, "projections_per_record": 2,
            "projection_count": 64, "new_physical_observations": 0, "verified_source_files": pins,
            "dependence_caution": "Each record contributes two overlapping projections. These are not 64 independent physical trials. Fixed empirical margins are not known population margins.",
        },
        "reproduce_command": "python audit_archive_geometry.py --source-dir /path/to/extracted/original-release --output archive_geometry_results.json",
        "verify_command": "python verify_geometry_certificate.py archive_geometry_results.json",
        "numerical_tolerance": args.tol,
        "exact_certificates": {
            "all_supports_complete": True, "coordinate_optima_verified": len(results) * 16,
            "all_independent_verifier_checks_passed": True,
            "note": "All listed support/dimension conclusions have exact rational certificates. The LP solver itself is numerical; a failure of rational certification would stop this audit.",
        },
        "summary": overall, "summary_by_view": by_view, "compact_projection_table": rows,
        "projections": results,
        "limitations": [
            "This reproduces and characterizes one finite released archive; it is not independent physical replication or proof of device control.",
            "A nonzero feasible dimension establishes alternative mathematical tables at fixed empirical margins, not causal effects or physical attainability.",
            "Simple-direction span rank describes linear span only; it does not establish an unrestricted simultaneous slider box.",
            "The LP/nullspace procedure is an established baseline. Its success here does not establish mathematical novelty or improved AI performance.",
        ],
        "runtime_seconds": time.perf_counter() - start,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    brief = lambda values: {key: value for key, value in values.items() if not isinstance(value, list)}
    print(json.dumps({
        "status": "PASS", "summary": brief(overall), "summary_by_view": {name: brief(values) for name, values in by_view.items()},
        "coordinate_optima_certified_exactly": len(results) * 16,
        "runtime_seconds": report["runtime_seconds"], "output": str(args.output.resolve()),
        "output_bytes": args.output.stat().st_size,
    }, indent=2))


if __name__ == "__main__":
    main()
