#!/usr/bin/env python3
"""Verify saved geometry certificates using only the Python standard library.

No NumPy, SciPy, LP solver, original source import, network, or service access.
Usage: python verify_geometry_certificate.py geometry_results.json
"""
from fractions import Fraction as F
from pathlib import Path
from itertools import combinations
import argparse
import json


def require(ok, message):
    if not ok:
        raise ValueError(message)


def rank(matrix):
    rows = [[F(v) for v in row] for row in matrix]
    if not rows:
        return 0
    r = 0
    for column in range(len(rows[0])):
        pivot = next((i for i in range(r, len(rows)) if rows[i][column] != 0), None)
        if pivot is None:
            continue
        rows[r], rows[pivot] = rows[pivot], rows[r]
        for i in range(r + 1, len(rows)):
            ratio = rows[i][column] / rows[r][column]
            rows[i] = [x - ratio * y for x, y in zip(rows[i], rows[r])]
        r += 1
        if r == len(rows):
            break
    return r


def moments(p, masks):
    return [sum((v if (i & mask).bit_count() % 2 == 0 else -v for i, v in enumerate(p)), F(0)) for mask in masks]


def verify_example(example):
    counts = example["counts"]
    n = len(example["bits"])
    width = 1 << n
    require(len(counts) == width, "Wrong table width")
    p = [F(c, sum(counts)) for c in counts]
    masks = [0] + [m for degree in (1, 2) for m in range(1, width) if m.bit_count() == degree]
    require(masks == example["constraint_masks"], "Wrong constraint masks")
    b = moments(p, masks)
    require(b == list(map(F, example["constraint_targets"])), "Wrong targets")
    A = [[F(1 if (i & m).bit_count() % 2 == 0 else -1) for i in range(width)] for m in masks]
    support = set(example["feasible_support"])
    forced = set(example["forced_zero_categories"])
    require(not support & forced and support | forced == set(range(width)), "Support classification incomplete")
    coordinate_rows = example["coordinate_results"]
    require(len(coordinate_rows) == width, "Missing coordinate certificates")
    for i, entry in enumerate(coordinate_rows):
        require(entry["category"] == i, "Category certificate mismatch")
        x = list(map(F, entry["rationalized_primal"]))
        lam = list(map(F, entry["upper_bound_dual"]))
        require(len(x) == width and len(lam) == len(masks), "Certificate dimensions wrong")
        require(all(v >= 0 for v in x) and moments(x, masks) == b, "Primal certificate infeasible")
        dual_values = [sum((A[j][k] * lam[j] for j in range(len(masks))), F(0)) for k in range(width)]
        require(all(v >= int(k == i) for k, v in enumerate(dual_values)), "Dual certificate invalid")
        upper = sum((v * w for v, w in zip(b, lam)), F(0))
        require(x[i] == upper, "Primal and dual objective differ")
        require(x[i] == F(entry["exact_primal_lower_bound"]) == F(entry["exact_dual_upper_bound"]), "Recorded optimum differs")
        if i in forced:
            require(upper == 0, "Forced-zero proof not zero")
        else:
            witness = list(map(F, entry["support_witness"]))
            require(witness[i] > 0 and all(v >= 0 for v in witness) and moments(witness, masks) == b, "Positive-support witness invalid")
    interior = list(map(F, example["exact_interior"]))
    require(moments(interior, masks) == b, "Interior violates equality constraints")
    require(all(interior[i] > 0 if i in support else interior[i] == 0 for i in range(width)), "Interior has wrong support")
    actual_rank = rank([[row[i] for i in sorted(support)] for row in A])
    dim = len(support) - actual_rank
    require(dim == example["exact_feasible_dimension"], "Dimension not certified")
    if "expected_dimension" in example:
        require(dim == example["expected_dimension"], "Dimension disagrees with expected fixture")
    basis = example["primitive_integer_nullspace_basis"]
    require(len(basis) == dim and rank(basis) == dim, "Basis count or independence wrong")
    for vector in basis:
        require(len(vector) == width and moments(vector, masks) == [0] * len(masks), "Basis changes marginals")
        require(all(vector[i] == 0 for i in forced), "Basis leaves forced support")
    return width


def verify_threebit_audit(audit):
    cases = audit["cases"]
    require([c["pattern"] for c in cases] == list(range(1, 256)), "Support-pattern enumeration incomplete")
    checked = 0
    for case in cases:
        counts = [(case["pattern"] >> i) & 1 for i in range(8)]
        require(counts == case["counts"], "Pattern/count mismatch")
        p = [F(c, sum(counts)) for c in counts]
        signs = [1 if i.bit_count() % 2 == 0 else -1 for i in range(8)]
        lo = -min(v for v, sign in zip(p, signs) if sign == 1)
        hi = min(v for v, sign in zip(p, signs) if sign == -1)
        support = [i for i in range(8) if p[i] + signs[i] * (hi if signs[i] == 1 else lo) > 0]
        require(int(lo < hi) == case["exact_dimension"], "Three-bit oracle dimension mismatch")
        require(support == case["feasible_support"], "Three-bit oracle support mismatch")
        checked += 1
    return checked


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("results", nargs="?", type=Path, default=Path("geometry_results.json"))
    args = parser.parse_args()
    report = json.loads(args.results.read_text(encoding="utf-8"))
    examples = report.get("examples", report.get("projections"))
    require(isinstance(examples, list) and len(examples) > 0, "No example or projection certificates")
    optima = sum(verify_example(e) for e in examples)
    audit = report.get("three_bit_exhaustive_support_audit")
    cases = verify_threebit_audit(audit) if audit else 0
    facet = report.get("counterexample_facet_certificate")
    if facet:
        require(list(map(F, facet["dual_truth_table"])) == [1, 0, 0, 0, 0, 0, 0, 1], "Facet indicator wrong")
    print(json.dumps({
        "status": "PASS", "exact_example_optimum_certificates_verified": optima,
        "example_support_and_dimension_certificates_verified": len(examples),
        "three_bit_support_patterns_rechecked_with_analytic_oracle": cases,
        "dependencies": "Python standard library only",
        "caveat": "For a three-bit exhaustive audit, saved per-pattern entries are summaries: this verifier rechecks their geometry with the analytic oracle; rerun support_geometry.py to reproduce all LP optimum checks. Named-example/archive projection certificates are verified in full.",
    }, indent=2))


if __name__ == "__main__":
    main()
