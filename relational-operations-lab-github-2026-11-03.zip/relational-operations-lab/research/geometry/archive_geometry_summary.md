# Archive-wide fixed-pair geometry audit

All eleven projections with no movable pure parity axis and no movable simple context direction are **unique at their exact recorded pair margins**. The support-aware LP audit found no additional hidden motion in those eleven cases.

The audit also found a separate limitation of the simple controls: in eleven other projections their currently feasible directions span fewer dimensions than the complete fixed-pair family.

## Main counts

| Result | Original view [5,6,10,11] | Alternative view [2,5,6,11] | Both views |
|---|---:|---:|---:|
| Projections audited | 32 | 32 | 64 |
| All five pure axes blocked | 32 | 30 | 62 |
| Pure axes blocked, some simple context move possible | 21 | 30 | 51 |
| All thirteen simple directions blocked | 11 | 0 | 11 |
| Exactly unique fixed-pair table | 11 | 0 | 11 |
| Nontrivial fixed-pair family | 21 | 32 | 53 |
| Current simple context span smaller than full dimension | 2 | 9 | 11 |

The thirteen simple directions here mean four pure triple axes, one pure quadruple axis, and eight triple-parity directions restricted to one binary context. The eight context directions are tested at the recorded starting table.

## Exact dimension distribution

| Feasible dimension | Original view | Alternative view | Both views |
|---|---:|---:|---:|
| 0 | 11 | 0 | 11 |
| 1 | 11 | 12 | 23 |
| 2 | 8 | 9 | 17 |
| 3 | 0 | 0 | 0 |
| 4 | 0 | 0 | 0 |
| 5 | 2 | 11 | 13 |

## The eleven resolved singleton cases

All are in the original [5,6,10,11] projection: E32:S01, E32:S03, E32:S05, E32:S06, E32:S08, E32:S12, E32:S14, E32:S16, E32:S22, E32:S26, E32:S27.

For each, every feasible category is identified, the complement is excluded by exact dual certificates, and the constraint rank equals the size of feasible support. Their zero dimension is therefore established by exact rational arithmetic, not inferred from sliders failing to move.

## Eleven cases where current simple contexts miss dimensions

| Record | View | Full feasible dimension | Span of currently movable simple contexts | Number of individually movable contexts |
|---|---|---:|---:|---:|
| E32:S10 | alternate | 5 | 4 | 4 |
| E32:S11 | alternate | 5 | 4 | 4 |
| E32:S13 | original | 5 | 2 | 2 |
| E32:S13 | alternate | 5 | 4 | 4 |
| E32:S15 | alternate | 5 | 3 | 3 |
| E32:S17 | alternate | 5 | 3 | 3 |
| E32:S18 | alternate | 5 | 4 | 4 |
| E32:S21 | alternate | 5 | 3 | 3 |
| E32:S25 | original | 5 | 2 | 2 |
| E32:S25 | alternate | 5 | 4 | 4 |
| E32:S29 | alternate | 5 | 4 | 4 |

The clearest examples are original-view E32:S13 and E32:S25: all five pure axes are blocked, and only two simple context directions are initially movable, but the complete fixed-pair family has dimension five. The report supplies a certified path from the recorded table into a strictly positive feasible interior and an exact five-vector nullspace basis.

This does not mean the simple controls can never reach those dimensions after several steps. Their feasible intervals can change after a move. The measured shortfall concerns the linear span of directions individually movable at the original table, not global reachability under repeated recomputation.

All 53 nontrivial families in this archive had at least one movable simple context direction. The LP audit did not find a wholly missed nontrivial family; it identified the complete geometry and, in eleven cases, additional dimensions beyond the initial context span.

## Full record map

| Record | Original dimension | Original current context span | Alternative dimension | Alternative current context span |
|---|---:|---:|---:|---:|
| E32:S01 | 0 | 0 | 1 | 1 |
| E32:S02 | 1 | 1 | 1 | 1 |
| E32:S03 | 0 | 0 | 1 | 1 |
| E32:S04 | 2 | 2 | 5 | 5 |
| E32:S05 | 0 | 0 | 1 | 1 |
| E32:S06 | 0 | 0 | 2 | 2 |
| E32:S07 | 1 | 1 | 1 | 1 |
| E32:S08 | 0 | 0 | 1 | 1 |
| E32:S09 | 1 | 1 | 1 | 1 |
| E32:S10 | 1 | 1 | 5 | 4 |
| E32:S11 | 1 | 1 | 5 | 4 |
| E32:S12 | 0 | 0 | 1 | 1 |
| E32:S13 | 5 | 2 | 5 | 4 |
| E32:S14 | 0 | 0 | 2 | 2 |
| E32:S15 | 2 | 2 | 5 | 3 |
| E32:S16 | 0 | 0 | 2 | 2 |
| E32:S17 | 2 | 2 | 5 | 3 |
| E32:S18 | 2 | 2 | 5 | 4 |
| E32:S19 | 1 | 1 | 2 | 2 |
| E32:S20 | 2 | 2 | 2 | 2 |
| E32:S21 | 1 | 1 | 5 | 3 |
| E32:S22 | 0 | 0 | 1 | 1 |
| E32:S23 | 2 | 2 | 2 | 2 |
| E32:S24 | 1 | 1 | 1 | 1 |
| E32:S25 | 5 | 2 | 5 | 4 |
| E32:S26 | 0 | 0 | 2 | 2 |
| E32:S27 | 0 | 0 | 1 | 1 |
| E32:S28 | 2 | 2 | 2 | 2 |
| E32:S29 | 1 | 1 | 5 | 4 |
| E32:S30 | 1 | 1 | 2 | 2 |
| E32:S31 | 1 | 1 | 1 | 1 |
| E32:S32 | 2 | 2 | 5 | 5 |

## Verification and scope

- The two input data files are checked against both their original release hashes and manifest hashes.
- All 1,024 coordinate maxima (64 projections × 16 categories) have matching exact rational primal and dual certificates.
- Every feasible-support classification, positive interior, exact rank, and nullspace basis passed the independent standard-library-only verifier.
- The original limited zero-marginal geometry dimension happened to agree on all 64 archive projections. The earlier synthetic counterexample remains a valid general limitation; it did not corrupt these archive dimensions.
- Thirty-five projections contain recorded empty cells that can carry positive mass in other valid tables with the same pair margins. That is a mathematical feasibility result, not evidence that the device has produced those designed tables.
- These are two overlapping views per retained record: **32 records and 25,600 unique shots, with no new observations**.

## Reproduce

```bash
python audit_archive_geometry.py --source-dir /path/to/extracted/original-release --output archive_geometry_results.json
python verify_geometry_certificate.py archive_geometry_results.json
```

The first command imports the standalone research extension and reads original public data. It does not import or modify original package code. The second needs only the Python standard library.

The recorded internal audit runtime was 2.792 seconds, excluding interpreter/import startup. The results JSON is 2,544,236 bytes and includes full certificates for every projection. Timings are environment-specific and do not establish a speed advantage.

Files: `audit_archive_geometry.py`, `archive_geometry_results.json`, `archive_geometry_verification.json`, and this summary, alongside the shared `support_geometry.py` and `verify_geometry_certificate.py`.

The conclusions condition on exact empirical margins. They do not establish population zeros, physical controllability, new physical effects, human-behavior prediction, or AI improvement.
