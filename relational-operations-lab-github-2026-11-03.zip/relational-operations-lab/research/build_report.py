"""Build the research PDF and exact-data figures from saved experiment results."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from xml.sax.saxutils import escape

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image, KeepTogether


ROOT = Path(__file__).resolve().parent
DATE = '3 November 2026'
INK = '#16313b'; TEAL = '#007f82'; GOLD = '#be7f27'; MUTED = '#526570'


def load(path):
    return json.loads((ROOT / path).read_text())


def figure_files(out, compact, stats):
    assets = out / 'figures'; assets.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 11,
                         'axes.spines.top': False, 'axes.spines.right': False,
                         'axes.labelcolor': INK, 'text.color': INK,
                         'xtick.color': MUTED, 'ytick.color': MUTED,
                         'figure.facecolor': 'white'})
    fig, ax = plt.subplots(figsize=(7.3, 2.5), constrained_layout=True)
    labels = ['Means + full covariance', 'Means + symmetric triangle', 'Selected sufficient entries']
    values = [compact['fullScalarInputsPerRecord'], compact['symmetricScalarInputsPerRecord'],
              compact['selectedScalarInputsPerRecord']]
    ax.barh(labels, values, color=['#b9c7cc', '#76969f', TEAL], height=.57)
    ax.invert_yaxis(); ax.set_xlim(0, 6900)
    for i, value in enumerate(values): ax.text(value + 100, i, f'{value:,}', va='center', weight='bold')
    ax.set_xlabel('Scalar inputs per 12-variable record')
    ax.grid(axis='x', alpha=.15); ax.set_axisbelow(True)
    fig.savefig(assets / 'retained_entries.png', dpi=180)
    fig.savefig(assets / 'retained_entries.svg'); plt.close(fig)

    fit = stats['three_bit_analysis']['maxent_fit']
    t = np.linspace(-8, 3, 300)
    probability = (8 + t) / 13
    fig, ax = plt.subplots(figsize=(7.3, 3.05), constrained_layout=True)
    ax.plot(t, probability * 100, color=TEAL, lw=2.5)
    ax.axhline(50, color='#87999f', ls='--', lw=1)
    ax.scatter([-8, fit['max_entropy_count_step'], 0, 3],
               [0, 100 * (8 + fit['max_entropy_count_step']) / 13, 800/13, 1100/13],
               c=[MUTED, GOLD, TEAL, MUTED], s=55, zorder=4)
    ax.annotate('Pairwise maximum entropy\n35.76%', (fit['max_entropy_count_step'],35.7563),
                xytext=(-6.6, 54), fontsize=10, color=GOLD,
                arrowprops={'arrowstyle':'-', 'color':GOLD})
    ax.annotate('Recorded table\n61.54%', (0,800/13), xytext=(-.8, 20), fontsize=10,
                arrowprops={'arrowstyle':'-', 'color':TEAL})
    ax.set_xlabel('Parity movement in original count units')
    ax.set_ylabel('Conditional probability (%)')
    ax.set_ylim(-5, 100); ax.set_xlim(-8.4, 3.4)
    ax.grid(alpha=.15)
    fig.savefig(assets / 'conditional_family.png', dpi=180)
    fig.savefig(assets / 'conditional_family.svg'); plt.close(fig)

    fig, axes = plt.subplots(1,2,figsize=(7.3,2.8),constrained_layout=True)
    a = np.linspace(0, 1, 300)
    axes[0].plot(a[1:], np.full_like(a[1:],5), color=TEAL, lw=2)
    axes[0].scatter([0],[2],color=GOLD,s=50,zorder=4)
    axes[0].scatter([0],[5],facecolors='white',edgecolors=TEAL,s=50,zorder=4)
    axes[0].set_ylim(1,6); axes[0].set_xlabel('Pseudocount per category')
    axes[0].set_ylabel('Feasible dimension')
    axes[0].set_title('Dimension changes immediately',fontsize=10)
    axes[1].plot(a,16*a/(800+16*a),color=TEAL,lw=2)
    axes[1].set_xlabel('Pseudocount per category')
    axes[1].set_ylabel('Maximum absolute moment change')
    axes[1].set_title('New movement stays small',fontsize=10)
    for ax in axes: ax.grid(alpha=.15)
    fig.savefig(assets / 'support_sensitivity.png',dpi=180)
    fig.savefig(assets / 'support_sensitivity.svg'); plt.close(fig)
    return assets


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, default=ROOT/'deliverables')
    args=parser.parse_args(); out=args.output_dir; out.mkdir(parents=True,exist_ok=True)
    compact=load('compact/results/results.json')
    stats=load('statistics/statistical_findings.json')
    geometry=load('geometry/geometry_results.json')
    archive_path=ROOT/'geometry/archive_geometry_results.json'
    archive=json.loads(archive_path.read_text()) if archive_path.exists() else None
    assets=figure_files(out,compact,stats)

    font_dir=Path('/usr/share/fonts/truetype/dejavu')
    if font_dir.exists():
        for name,file in [('Body','DejaVuSans.ttf'),('Bold','DejaVuSans-Bold.ttf'),('Mono','DejaVuSansMono.ttf')]:
            pdfmetrics.registerFont(TTFont(name,str(font_dir/file)))
    else:
        for name,base in [('Body','Helvetica'),('Bold','Helvetica-Bold'),('Mono','Courier')]:
            pdfmetrics.registerFont(pdfmetrics.Font(name,base,'WinAnsiEncoding'))
    pdfmetrics.registerFontFamily('Body',normal='Body',bold='Bold',italic='Body',boldItalic='Bold')
    pdfmetrics.registerFontFamily('Mono',normal='Mono',bold='Mono',italic='Mono',boldItalic='Mono')
    styles=getSampleStyleSheet()
    styles.add(ParagraphStyle(name='ResearchBody',fontName='Body',fontSize=10.3,leading=14.6,textColor=colors.HexColor(INK),spaceAfter=9))
    styles.add(ParagraphStyle(name='SmallNote',fontName='Body',fontSize=8.8,leading=12.2,textColor=colors.HexColor(MUTED),spaceAfter=7))
    styles.add(ParagraphStyle(name='ResearchH1',fontName='Bold',fontSize=22,leading=27,textColor=colors.HexColor(INK),spaceAfter=14))
    styles.add(ParagraphStyle(name='ResearchH2',fontName='Bold',fontSize=12.4,leading=17,textColor=colors.HexColor(TEAL),spaceBefore=7,spaceAfter=8))
    styles.add(ParagraphStyle(name='ResearchCode',fontName='Mono',fontSize=8.5,leading=12,textColor=colors.HexColor(INK),spaceAfter=9,backColor=colors.HexColor('#edf3f4'),borderPadding=8))
    styles.add(ParagraphStyle(name='TableCell',fontName='Body',fontSize=9,leading=12,textColor=colors.HexColor(INK)))
    styles.add(ParagraphStyle(name='TableHead',fontName='Bold',fontSize=9,leading=12,textColor=colors.white))
    story=[]
    def p(text,style='ResearchBody'): story.append(Paragraph(text,styles[style]))
    def h(text): p(text,'ResearchH2')
    def title(number,text):
        p(f'RESEARCH NOTE  /  {number:02d}', 'SmallNote'); p(text,'ResearchH1')
    def table(headers,rows,widths):
        cells=[[Paragraph(str(x),styles['TableHead']) for x in headers]]
        cells += [[Paragraph(str(x),styles['TableCell']) for x in row] for row in rows]
        t=Table(cells,colWidths=widths,repeatRows=1,hAlign='LEFT')
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor(INK)),
                              ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#f0f5f5'),colors.white]),
                              ('VALIGN',(0,0),(-1,-1),'TOP'),('LEFTPADDING',(0,0),(-1,-1),8),
                              ('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),7),
                              ('BOTTOMPADDING',(0,0),(-1,-1),7),
                              ('LINEBELOW',(0,-1),(-1,-1),.5,colors.HexColor('#cbd6da'))]))
        story.append(t);story.append(Spacer(1,10))
    def page(): story.append(PageBreak())
    def pic(name,width=510,height=None):
        from PIL import Image as PILImage
        path=assets/name
        w,hgt=PILImage.open(path).size
        story.append(Image(str(path),width=width,height=height or width*hgt/w));story.append(Spacer(1,6))

    title(1,'Relational Operations Lab<br/>Further research')
    p(f'{DATE} | Source snapshot: v0.1.0-experimental','SmallNote')
    p('<b>Outcome:</b> the foundations closely match established Boolean moment and fixed-margin geometry methods. Further local work produced three useful extensions: a smaller reconstruction input, recovery from explicitly rounded exports, and automatic support geometry with exact certificates.')
    table(['New work','Observed result'],[
        ['Selective covariance recovery','793 scalar inputs recover the same 793 nonconstant moments; 64 four-bit reconstructions remain exact.'],
        ['Rounded-export recovery','All 32 records recover exactly from six-decimal mean/covariance values under an explicit rounding contract.'],
        ['Automatic geometry','Known coupled directions recovered; 53 of 64 archive projections admit movement, with exact certificates.'],
        ['Statistical calibration','The selected conditional is 61.54%; a pairwise maximum-entropy reference gives 35.76%, using the same pair marginals.']
    ],[160,356])
    h('What this supports')
    p('These are reproducible software and retained-data results. They support a more capable statistical instrument. The new routines use established algebra, linear programming and interval arithmetic; this note does not establish a new theorem or a scientific breakthrough.')
    h('Evidence boundaries')
    p('The work used the supplied aggregates and synthetic validation cases. There were no new physical measurements, provider calls, human observations, or deployed-AI evaluations. Two projections of one record are two views of the same observations. The original release remains unchanged.')
    p('The companion bundle contains executable scripts, machine-readable results, exact certificates, source hashes and the unmodified original input ZIP. Later unpublished research is outside this snapshot.', 'SmallNote')
    page()

    title(2,'Closest established methods')
    p('This was a targeted prior-work comparison, not an exhaustive priority or patent search. The sources identify close mathematical counterparts and appropriate baselines; they do not settle the originality of every implementation or workflow detail.')
    table(['Part of the lab','Closest prior work','Practical implication'],[
        ['Higher-order relationships hidden by pair marginals','Schneidman et al. (2003), connected information [1]','The phenomenon is established. Application and algorithmic advances need separate evidence.'],
        ['Parity products and inverse reconstruction','O\'Donnell, Boolean Fourier analysis [2]','The parity basis and symmetric-difference product rule are standard.'],
        ['Covariance of parity features','Bach (2024), Boolean moment matrices, section 4.2.7 [3]','The decoder reads moment-matrix entries after undoing the archive covariance convention.'],
        ['Changes preserving margins','Diaconis and Sturmfels (1998); 4ti2 [4,5]','Kernel moves and integer-fiber connectivity already have general methods.'],
        ['Support implied by all margins','Wang, Rauh and Massam (2019) [6]','Zero pair cells are only one way support restrictions arise; complete facial/support analysis is a stronger baseline.']
    ],[135,180,201])
    h('Precise match for the covariance decoder')
    p('For parity features, chi_A chi_B = chi_(A symmetric-difference B). Thus the feature moment matrix has entry G[A,B] = m_(A symmetric-difference B). Bach explicitly uses this structure. The lab reconstructs G from the saved feature means and covariance-of-means values:')
    p('G[A,B] = (N - 1) CovMean[A,B] + m_A m_B','ResearchCode')
    p('Its useful specialization is the archive contract, exact empirical-lattice checks, reconstruction, and inspectable exports. No additional independent measurement is created by this conversion.')
    h('A useful distinction for geometry')
    p('The marginal polytope describes possible summary vectors. The compatible-table set describes full distributions sharing one summary vector: F_b = {p >= 0 : A p = b}. A marginal face determines allowed support; the dimension of F_b is a different quantity. A nullspace basis also does not by itself guarantee connectivity of every nonnegative integer table. [4-6]')
    page()

    title(3,'Recover the same moments from fewer entries')
    p('The archive stores 78 feature means and a 78 by 78 covariance matrix for each 12-variable record. Only one covariance entry is needed for each missing third- or fourth-order coefficient once the means are known.')
    p('Missing coefficients = C(12,3) + C(12,4) = 220 + 495 = 715\nTotal selected scalar inputs = 78 + 715 = 793','ResearchCode')
    pic('retained_entries.png')
    p(f'This removes <b>{compact["inputReductionFromFullMatrixPercent"]:.2f}%</b> of scalar inputs relative to the full stored matrix, or <b>{compact["inputReductionFromSymmetricMatrixPercent"]:.2f}%</b> relative to storing one symmetric triangle. All 32 records and 64 named four-bit reconstructions still agree exactly with the original histograms.')
    h('Scope of the minimum')
    p('For unrestricted distributions near the uniform table, these 715 higher-order coordinates can vary independently while the lower-order means stay fixed. Each selected scalar covariance reveals only one such coordinate. Therefore 715 entries are necessary and sufficient within this selection scheme. This is not an information-theoretic minimum byte count and does not apply unchanged when support or extra structure supplies constraints.')
    h('Measured storage and runtime')
    p('Compact JSON numeric payloads for all 32 records were 4,441,951 bytes for the full means/covariance, 537,816 for selected entries, and 112,531 for exact signed moment numerators. These comparisons exclude common provenance and the shared mask plan. Gzip level 9 sizes were 966,934, 129,086 and 38,999 bytes, respectively.')
    p(f'The already-loaded selective decoder took a median {compact["benchmark"]["selectiveDecoderMedianSeconds"]:.4f} seconds for 32 records, versus {compact["benchmark"]["fullDecoderMedianSeconds"]:.4f} seconds for the original full decoder over five repeats. The selective path omits redundant consistency checks. This is a narrower decoding task, not an equal-audit or AI speedup claim.','SmallNote')
    page()

    title(4,'Exact recovery from rounded exports')
    p('The original decoder deliberately demands extremely small rounding residuals. A second decoder instead treats each rounded decimal as a known interval and returns a moment only when one exact empirical value is possible.')
    p('For N binary parity observations:\nm = k / N,  k in {-N, -N+2, ..., N}.','ResearchCode')
    p('The admissible values are spaced by 2/N. After the feature means have been recovered exactly, a covariance error bound delta gives a moment error bound (N-1) delta. A sufficient uniqueness condition is:')
    p('delta < 1 / [N (N - 1)]','ResearchCode')
    p('For N = 800, this threshold is approximately 0.00000156446. Nearest rounding to six decimal places has error at most 0.0000005, satisfying the bound. The means must satisfy their own lattice-identification check first.')
    table(['Decimal places','Original strict decoder','Interval decoder, selected entries'],[
        ['5','0 / 32 records accepted','0 / 32 fully recovered; ambiguous values withheld'],
        ['6','0 / 32 records accepted','32 / 32 exactly recovered'],
        ['8','0 / 32 records accepted','32 / 32 exactly recovered'],
        ['13','32 / 32 records accepted','Not needed for the six-decimal result']
    ],[95,170,251])
    h('Redundancy still has value')
    p('At five decimals, one covariance per target left 22,880 higher-order moments ambiguous across the archive. Intersecting all available distinct recovery paths reduced that to 13,997. No incorrect moment was returned. None of the 32 records became fully resolved at that precision.')
    p('This does not prove that five-decimal data are fundamentally insufficient: the interval routine does not exploit every joint probability-feasibility constraint. It demonstrates a useful tradeoff between compact storage, redundancy and numerical recoverability.')
    p('<b>Contract:</b> known shot count, common measurement rows, the stated covariance convention, and a known nearest-decimal rounding bound. This is recovery from representation rounding, not correction of arbitrary instrument noise or estimation of an unknown population distribution.','SmallNote')
    page()

    title(5,'Find all feasible support before counting freedom')
    p('The original geometry routine detects support zeros directly implied by zero-valued single or pair cells. The research extension solves a coordinate maximum for every complete-table cell:')
    p('maximize p_x\nsubject to A p = b, p >= 0','ResearchCode')
    p('A positive feasible witness establishes that a cell can occur. An exact dual upper bound of zero establishes that it is forbidden in every compatible table. After finding the support S, exact rank arithmetic gives dim(F_b) = |S| - rank(A_S), with a strictly positive relative-interior witness completing the certificate.')
    table(['Example','Allowed cells','Constraint rank','Exact dimension'],[
        ['Original four-bit projection','12','10','2'],
        ['Alternative four-bit projection','16','11','5'],
        ['Three-bit counterexample','6','6','0'],
    ],[225,90,100,101])
    h('The coupled controls were recovered automatically')
    p('The nullspace calculation returned exactly the two published directions V and U, with their relationship to the named controls verified using rational arithmetic. This reproduces their structure from the constraints instead of requiring them as input.')
    h('The missed support restriction has a simple proof')
    p('For the table with counts [0,1,1,1,1,1,1,0], every pair cell is positive. Yet any binary triple has at most two disagreeing pairs. The supplied pair marginals attain expected disagreement two, forcing the all-equal states 000 and 111 to remain empty. The compatible table is unique.')
    h('Verification and limits')
    p('All 255 nonempty three-bit support patterns were tested with uniform mass on each support. All 2,040 LP coordinate maxima agreed with the independent parity-interval oracle and passed exact primal/dual checks. The original partial inference overcounted dimension in four support patterns; this is not an empirical error rate.')
    p('HiGHS proposes numerical solutions; exact rational feasibility and dual inequalities decide certification. Unresolved cases suppress a complete dimension claim. The finite research implementation is limited to six variables and has no scalability claim. A standard-library-only verifier checks the saved named-case certificates.','SmallNote')
    page()

    title(6,'A strong local difference can have a modest global effect')
    p('A maximum-entropy classical reference was fitted to the original three-bit table while preserving all empirical singles and pairs. Its entropy-maximizing parity movement is -3.3516779017 in count units.')
    pic('conditional_family.png')
    table(['Quantity','Empirical table','Pairwise maximum entropy'],[
        ['P(bit 6 = 1 | bit 5 = 1, bit 11 = 0)','61.5385%','35.7563%'],
        ['Correct threshold predictions, same 800 observations','730 / 800','727 / 800'],
        ['Conditional log loss on those observations','0.410074 bits','0.417301 bits'],
    ],[260,125,131])
    p('The selected conditional differs by 25.7821 percentage points, while joint total variation is 1.67584% and KL divergence is 0.00722658 bits per observation. Both references use the same pair marginals. The large local difference is concentrated in a condition observed only 13 times.')
    h('Two distinct intervals')
    p('The 0% to 84.62% interval is an exact feasible-design range with the empirical margins fixed. A two-sided 95% Clopper-Pearson interval for 8 successes in 13 qualifying observations is 31.58% to 86.14%, under stable IID sampling and a fixed query. These intervals answer different questions.')
    p('The original example was selected exploratorily. The binomial interval does not correct that selection or multiple comparisons. The maximum-entropy comparison and scores use the same data for fitting and evaluation. They establish no held-out prediction advantage.','SmallNote')
    page()

    title(7,'What the complete archive geometry reveals')
    p('The archive survey checked the five individual higher-order parity directions and eight context-restricted triple directions in each of two four-bit projections of the same 32 records.')
    table(['Projection','All five pure axes blocked','A context-restricted movement still exists'],[
        ['[5,6,10,11]','32 / 32 views','21 of those 32'],
        ['[2,5,6,11]','30 / 32 views','30 of those 30'],
        ['Combined views','62 / 64 views','51 of those 62'],
    ],[150,165,201])
    p('The complete support audit found 53 nontrivial families and 11 uniquely determined tables. All 11 cases with no initial pure or simple context movement are truly unique at their exact empirical pair margins. The 64 views come from the same 32 records.')
    table(['Exact family dimension','Original view','Alternative view','Total'],[
        ['0: a unique table','11','0','11'],
        ['1','11','12','23'],
        ['2','8','9','17'],
        ['5','2','11','13'],
    ],[195,110,115,96])
    h('Existing context controls can expose only part of the freedom')
    p('In 11 nontrivial projections, the span of simple context directions movable at the recorded table is smaller than the full family. For the original views of E32:S13 and E32:S25, that initial span has dimension two while the family has dimension five. The output supplies a certified feasible path toward an interior point and a full nullspace basis.')
    p('This does not prove that repeated context moves, with bounds recomputed after each move, cannot reach the other dimensions. A basis at an interior point need not be individually movable at the observed boundary.','SmallNote')
    p('All 1,024 coordinate maxima have matching exact primal and dual certificates. The old partial support routine happened to count dimensions correctly for all 64 archived views; its synthetic counterexample remains a general limitation.','SmallNote')
    page()

    title(8,'Empty cells and small perturbations')
    p('In 35 of the 64 projections, some recorded empty categories can receive positive probability in another table with the same exact pair margins. Other empty categories are forced by those margins. The certified support calculation distinguishes these cases; neither is a new physical observation.')
    h('Sensitivity to interpreting empty cells')
    p('For the original projection, adding a pseudocount alpha to every joint category gives p_alpha(x) = (count_x + alpha)/(800 + 16 alpha). This is an assumption-based design that changes the margins; it is not another observation or a move within the original fixed-margin family.')
    pic('support_sensitivity.png')
    p('At alpha = 0 the feasible dimension is two. Any positive alpha gives full support and dimension five, but the newly available pure-axis movements remain small. At alpha = 0.5, the largest moment movement along one pure axis is 1/101 and total variation is 1/202. A jump in dimension is not a jump in effect size.')
    p('Observed empty categories constrain the exact empirical specification. They do not establish impossible events in the underlying physical population. The coupled geometry remains valuable, but its physical interpretation requires this distinction.','SmallNote')
    page()

    title(9,'The strongest next contribution to test')
    p('The clearest development direction is a query-driven measurement contract: given a prediction or conditional question, determine which statistics identify its answer, which additional entries would resolve uncertainty, and when only sharp bounds are justified.')
    table(['Component','What is now demonstrated','What still needs evidence'],[
        ['Compact reconstruction','A selected covariance set recovers the same archived degree-1 to degree-4 moments.','Benefit across other export formats, precision contracts and workloads.'],
        ['Rounded recovery','Certified unique lattice values from six-decimal exports for all 32 records.','Broader shot counts and precision regimes; ambiguous-case feasibility methods.'],
        ['Automatic coupled controls','Known controls recovered; missed implicit support zeros certified.','Scalable discovery and useful controls for larger tables.'],
        ['Prediction or learning','A selected conditional differs from a pairwise fitted reference.','Prospective predictions against interaction-capable baselines on new data.'],
        ['Human application','No human observations in the supplied snapshot.','Defined behavioral inputs/outcomes, predictions before outcomes, and appropriate comparative evaluation.'],
    ],[115,195,206])
    h('A fair comparison')
    p('For statistical reconstruction, compare against direct Walsh/moment methods and ordinary polyhedral tools. For integer-table connectivity, compare against Markov/Graver/circuit methods such as 4ti2; continuous nullspace spanning is a different guarantee. [2,4,5]')
    p('For JIM, bind the method to a scored decision and compare against a full joint-table learner and an interaction-capable model with the same observations. A result against pair summaries alone measures the value of missing information; it does not isolate a superior learning algorithm.')
    h('Assessment after this additional work')
    p('The case for a useful research instrument is stronger: there are now concrete efficiency and robustness extensions, exact geometry certificates, and archive-wide examples of coupled freedom. The foundations are established and no new physical or human result has been added. A scientific-breakthrough claim still requires a consequential advance beyond strong existing methods.')
    page()

    title(10,'Reproduction and provenance')
    p('All numerical outputs were computed locally from the unmodified supplied snapshot, except explicitly labeled synthetic support-pattern tests and smoothing/rounding designs. Python 3.12.14, NumPy 2.3.5 and SciPy 1.17.0 were used for the recorded runs. Timing depends on the execution environment.')
    h('Companion bundle')
    table(['Path','Contents'],[
        ['inputs/','The original uploaded release ZIP, unchanged.'],
        ['research/compact/','Selective decoder, rounding decoder, read plan, exact moment archive and results.'],
        ['research/geometry/','Support solver, independent certificate verifier, exact certificates, exhaustive and archive audits.'],
        ['research/statistics/','Maximum-entropy fit, uncertainty and support-sensitivity analysis with JSON outputs.'],
        ['report/','This report and generated scientific figures.'],
        ['README.txt, CHECKSUMS.sha256','Commands, dependencies, scope and checksums for the research bundle.'],
    ],[170,346])
    h('Core commands after extracting the original release')
    p('Replace SOURCE_DIR with its extracted directory. Run these from the research-bundle root. The scripts do not need a quantum account or network connection. The geometry verifier requires only the Python standard library.','SmallNote')
    p('python research/compact/compact_covariance.py \\<br/>  --source-dir SOURCE_DIR --output replay/compact<br/><br/>python research/geometry/support_geometry.py \\<br/>  --source-dir SOURCE_DIR --output replay/geometry.json<br/><br/>python research/geometry/audit_archive_geometry.py \\<br/>  --source-dir SOURCE_DIR --output replay/archive.json<br/><br/>python research/geometry/verify_geometry_certificate.py \\<br/>  research/geometry/archive_geometry_results.json<br/><br/>python research/statistics/analyze_statistics.py \\<br/>  --source-dir SOURCE_DIR --output replay/statistics','ResearchCode')
    p('Source hashes and record identities accompany the saved results. CHECKSUMS.sha256 covers every companion file. README.txt includes extraction, dependencies and full reproduction commands.','SmallNote')
    page()

    title(11,'References and interpretation notes')
    references=[
        ('1','Schneidman, E., Still, S., Berry, M. J. II, and Bialek, W. (2003). Network Information and Connected Correlations. Physical Review Letters 91, 238701.','https://doi.org/10.1103/PhysRevLett.91.238701'),
        ('2','O\'Donnell, R. Analysis of Boolean Functions. Cambridge University Press (2014); author-hosted 2021 arXiv edition. Sections 1.3-1.5.','https://www.cs.cmu.edu/~odonnell/papers/Analysis-of-Boolean-Functions-by-Ryan-ODonnell.pdf'),
        ('3','Bach, F. (2024). Sum-of-Squares Relaxations for Information Theory and Variational Inference. Foundations of Computational Mathematics. Section 4.2.7.','https://www.di.ens.fr/~fbach/bach_sos_varinf.pdf'),
        ('4','Diaconis, P. and Sturmfels, B. (1998). Algebraic Algorithms for Sampling from Conditional Distributions. Annals of Statistics 26(1), 363-397.','https://doi.org/10.1214/aos/1030563990'),
        ('5','4ti2 project. Official Markov-basis command documentation. Consulted for existing executable capabilities, not a benchmark run.','https://4ti2.github.io/markov.html'),
        ('6','Wang, N., Rauh, J. and Massam, H. (2019). Approximating Faces of Marginal Polytopes in Discrete Hierarchical Models. Annals of Statistics 47(3), 1203-1233.','https://arxiv.org/abs/1603.04843'),
        ('7','polymake project. Official polytope documentation. Consulted for affine-hull and polyhedral optimization capabilities; not benchmarked here.','https://polymake.org/release_docs/3.3/polytope.html'),
    ]
    for num,text,url in references:
        p(f'<b>[{num}]</b> {escape(text)} <a href="{escape(url)}" color="{TEAL}">Source link</a>.','SmallNote')
    h('Claims tied to evidence')
    p('Exact reconstruction refers to empirical probabilities derived from the supplied aggregates. It does not recover unmeasured phases or create new shots. Analytical movement is a probability-table specification; physical or behavioral intervention effects require their own evidence.')
    p('The repeated-record comparisons are exploratory descriptions. Their statistical intervals assume stable sampling and fixed events, while the historical selection remains uncorrected. The frozen source documents a prior selected association and its nonreplicating follow-up; this report does not replace that history.')
    p('The supplied original code/documentation retain their MIT license; released data retain CC BY 4.0 attribution to Relational Operations Lab contributors, snapshot v0.1.0-experimental. Derived data in this companion identify that source. Research companion code is supplied under MIT in the bundle.')
    p('Prepared from source inspection, targeted primary literature, independent calculations and executable local research. No claim of exhaustive prior-art coverage, external peer review, practical quantum advantage or general human-behavior prediction is made.','SmallNote')

    def footer(canvas,doc):
        canvas.setStrokeColor(colors.HexColor('#cbd6da'));canvas.line(48,44,564,44)
        canvas.setFont('Body',8);canvas.setFillColor(colors.HexColor(MUTED))
        canvas.drawString(48,30,'RELATIONAL OPERATIONS LAB  |  FURTHER RESEARCH  |  3 NOV 2026')
        canvas.drawRightString(564,30,str(doc.page))
    target=out/'Relational_Operations_Further_Research_2026-11-03.pdf'
    doc=SimpleDocTemplate(str(target),pagesize=(612,792),leftMargin=48,rightMargin=48,
                          topMargin=44,bottomMargin=58,title='Relational Operations Lab - Further Research',
                          author='Research prepared for Relational Operations Lab')
    doc.build(story,onFirstPage=footer,onLaterPages=footer)
    (out/'sources.json').write_text(json.dumps([{'id':n,'citation':t,'url':u} for n,t,u in references],indent=2)+'\n')
    print(target)


if __name__=='__main__': main()
