#!/usr/bin/env python3
"""Independent statistical sensitivity analysis of the released ROL snapshot.

Usage:
  python analyze_statistics.py --source-dir PATH_TO_EXTRACTED_RELEASE --output OUTPUT_DIR

Dependencies: Python 3.10+, scipy. No source files are modified. The generated
results describe the selected released observations, not new experiments.
"""
from __future__ import annotations

import argparse
from fractions import Fraction
import hashlib
from itertools import combinations, product
import json
import math
from pathlib import Path
import platform

import scipy
from scipy.optimize import brentq
from scipy.stats import beta


def fjson(value: Fraction):
    return {"exact": str(value), "decimal": float(value)}


def sign(word: int, mask: int):
    return -1 if (word & mask).bit_count() % 2 else 1


def parity_masks(n: int, min_order: int, max_order: int):
    return [m for m in range(1, 1 << n) if min_order <= m.bit_count() <= max_order]


def labels(bits, mask):
    return [bit for i, bit in enumerate(bits) if mask & (1 << (len(bits) - 1 - i))]


def histogram_projection(logical_counts, bits):
    out = [0] * (1 << len(bits))
    for word, count in logical_counts.items():
        physical = int(word, 2)
        local = 0
        for bit in bits:
            local = (local << 1) | ((physical >> bit) & 1)
        out[local] += count
    return out


def marginal(probabilities, positions, n):
    out = [Fraction(0)] * (1 << len(positions))
    for word, probability in enumerate(probabilities):
        index = 0
        for position in positions:
            index = (index << 1) | ((word >> (n - 1 - position)) & 1)
        out[index] += probability
    return tuple(out)


def exact_rank(matrix):
    matrix = [[Fraction(x) for x in row] for row in matrix]
    rank = 0
    for column in range(len(matrix[0]) if matrix else 0):
        pivot = next((i for i in range(rank, len(matrix)) if matrix[i][column]), None)
        if pivot is None:
            continue
        matrix[rank], matrix[pivot] = matrix[pivot], matrix[rank]
        lead = matrix[rank][column]
        matrix[rank] = [x / lead for x in matrix[rank]]
        for i in range(rank + 1, len(matrix)):
            factor = matrix[i][column]
            if factor:
                matrix[i] = [a - factor * b for a, b in zip(matrix[i], matrix[rank])]
        rank += 1
        if rank == len(matrix):
            break
    return rank


def direction_interval(probabilities, vector):
    assert sum(vector) == 0 and any(vector)
    lower = max(-p / v for p, v in zip(probabilities, vector) if v > 0)
    upper = min(-p / v for p, v in zip(probabilities, vector) if v < 0)
    assert lower <= 0 <= upper
    return lower, upper


def context_directions(n):
    # For n=4 these are a triple parity restricted to the remaining bit.
    # Algebraically each changes a triple and the full-order coordinate together.
    assert n == 4
    for mask in parity_masks(n, 3, 3):
        context_mask = ((1 << n) - 1) ^ mask
        for value in (0, 1):
            vector = tuple(
                Fraction(sign(word, mask)) if bool(word & context_mask) == bool(value) else Fraction(0)
                for word in range(1 << n)
            )
            yield mask, context_mask, value, vector


def certify_fixed_pair_dimension(probabilities):
    """Certify the dimension when a constructive relative-interior point exists.

    This uses zero pair marginals, exact rank, and explicit feasible directions,
    not an LP geometry solver. If the construction fails, return an upper bound
    rather than incorrectly claiming a complete dimension calculation.
    """
    n = 4
    forced_zero = set()
    for size in (1, 2):
        for positions in combinations(range(n), size):
            values = marginal(probabilities, positions, n)
            for word in range(1 << n):
                category = 0
                for position in positions:
                    category = (category << 1) | ((word >> (n - 1 - position)) & 1)
                if values[category] == 0:
                    forced_zero.add(word)
    allowed = [w for w in range(1 << n) if w not in forced_zero]
    masks = [0, *parity_masks(n, 1, 2)]
    rank = exact_rank([[sign(w, mask) for w in allowed] for mask in masks])
    candidate_tables = [list(probabilities)]
    for _, _, _, vector in context_directions(n):
        lower, upper = direction_interval(probabilities, vector)
        for step in (lower / 2, upper / 2):
            if step:
                candidate = [p + step * v for p, v in zip(probabilities, vector)]
                assert min(candidate) >= 0 and sum(candidate) == 1
                for positions in combinations(range(n), 2):
                    assert marginal(candidate, positions, n) == marginal(probabilities, positions, n)
                candidate_tables.append(candidate)
    interior = [sum(row[w] for row in candidate_tables) / len(candidate_tables) for w in range(16)]
    certified = all(interior[w] > 0 for w in allowed) and all(interior[w] == 0 for w in forced_zero)
    return {
        "forced_zero_categories": [format(w, "04b") for w in sorted(forced_zero)],
        "allowed_category_count": len(allowed),
        "exact_constraint_rank_on_allowed_categories": rank,
        "affine_dimension_upper_bound": len(allowed) - rank,
        "dimension_certified_by_relative_interior_witness": certified,
        "affine_dimension": len(allowed) - rank if certified else None,
        "relative_interior_witness": [str(p) for p in interior] if certified else None,
    }


def pure_axis_results(probabilities, bits):
    output = []
    for mask in parity_masks(4, 3, 4):
        vector = [Fraction(sign(w, mask)) for w in range(16)]
        lower, upper = direction_interval(probabilities, vector)
        strength = max(abs(lower), abs(upper))
        output.append({
            "local_mask": mask,
            "selected_bits": labels(bits, mask),
            "probability_step_interval": [fjson(lower), fjson(upper)],
            "parity_moment_change_interval": [fjson(16 * lower), fjson(16 * upper)],
            "maximum_absolute_parity_moment_change": fjson(16 * strength),
            "maximum_total_variation_from_start": fjson(8 * strength),
            "blocked_in_both_directions": lower == upper == 0,
        })
    return output


def three_bit_maxent(record):
    counts = record["tripleCounts"]
    n_shots = record["shots"]
    bits = [*record["pairBits"], record["contextBit"]]
    assert len(counts) == 8 and sum(counts) == n_shots
    signs = [sign(i, 7) for i in range(8)]
    lower = -min(c for i, c in enumerate(counts) if signs[i] == 1)
    upper = min(c for i, c in enumerate(counts) if signs[i] == -1)
    assert lower < upper and min(counts) > 0

    def negative_entropy_derivative(step):
        return sum(s * math.log(c + s * step) for c, s in zip(counts, signs))

    optimum = brentq(
        negative_entropy_derivative,
        math.nextafter(float(lower), float(upper)),
        math.nextafter(float(upper), float(lower)),
        xtol=1e-13,
    )
    p = [c / n_shots for c in counts]
    q = [(c + s * optimum) / n_shots for c, s in zip(counts, signs)]
    entropy = lambda values: -sum(x * math.log2(x) for x in values if x > 0)
    kl_bits = sum(a * math.log2(a / b) for a, b in zip(p, q) if a > 0)
    assert abs(kl_bits - (entropy(q) - entropy(p))) < 1e-12
    largest_pair_error = max(
        abs(a - b)
        for positions in combinations(range(3), 2)
        for a, b in zip(marginal(p, positions, 3), marginal(q, positions, 3))
    )
    assert largest_pair_error < 1e-12
    rows = []
    empirical_correct = maxent_correct = 0
    empirical_logloss_bits = maxent_logloss_bits = 0.0
    empirical_brier = maxent_brier = 0.0
    for a, context in product((0, 1), repeat=2):
        index0 = (a << 2) | context
        index1 = index0 | 2
        support = counts[index0] + counts[index1]
        if not support:
            continue
        observed = Fraction(counts[index1], support)
        fitted = q[index1] / (q[index0] + q[index1])
        empirical_prediction = int(observed > Fraction(1, 2))
        maxent_prediction = int(fitted > 0.5)
        empirical_correct += counts[index1 if empirical_prediction else index0]
        maxent_correct += counts[index1 if maxent_prediction else index0]
        for outcome, count in ((0, counts[index0]), (1, counts[index1])):
            observed_outcome_probability = float(observed) if outcome else 1 - float(observed)
            fitted_outcome_probability = fitted if outcome else 1 - fitted
            if count:
                empirical_logloss_bits -= count / n_shots * math.log2(observed_outcome_probability)
                maxent_logloss_bits -= count / n_shots * math.log2(fitted_outcome_probability)
            empirical_brier += count / n_shots * (outcome - float(observed)) ** 2
            maxent_brier += count / n_shots * (outcome - fitted) ** 2
        rows.append({
            "condition": {str(bits[0]): a, str(bits[2]): context},
            "query_bit": bits[1],
            "support_count": support,
            "support_fraction": fjson(Fraction(support, n_shots)),
            "success_count": counts[index1],
            "empirical_conditional": fjson(observed),
            "maxent_conditional": fitted,
            "empirical_minus_maxent_conditional": float(observed) - fitted,
            "empirical_threshold_prediction": empirical_prediction,
            "maxent_threshold_prediction": maxent_prediction,
        })
    selected = next(r for r in rows if r["condition"] == {str(bits[0]): 1, str(bits[2]): 0})
    successes, trials = selected["success_count"], selected["support_count"]
    alpha = 0.05
    ci = [
        0.0 if successes == 0 else float(beta.ppf(alpha / 2, successes, trials - successes + 1)),
        1.0 if successes == trials else float(beta.ppf(1 - alpha / 2, successes + 1, trials - successes)),
    ]
    return {
        "record_id": record["recordId"], "bit_order": bits,
        "outcome_order": [format(i, "03b") for i in range(8)], "counts": counts,
        "shots": n_shots,
        "selected_conditional_uncertainty": {
            "successes": successes, "qualifying_observations": trials,
            "estimate": fjson(Fraction(successes, trials)),
            "interval_method": "Two-sided 95% Clopper-Pearson exact binomial confidence interval",
            "interval": ci,
            "assumptions": [
                "Independent identically distributed shots from a stable joint distribution.",
                "Fixed condition and query for the nominal coverage interpretation.",
                "The source example was selected exploratorily; this interval does not correct that selection or multiple testing.",
                "The fitted maximum-entropy model uses the same observations; inclusion in this interval is descriptive, not an independent model test.",
            ],
        },
        "maxent_fit": {
            "constraints": "All empirical one-variable and two-variable marginal distributions held fixed.",
            "free_coordinate": "p_i(t) = (count_i + (-1)^popcount(i) * t) / N; t is in count units.",
            "feasible_count_step_interval": [lower, upper],
            "max_entropy_count_step": optimum,
            "maximum_derivative_absolute_residual": abs(negative_entropy_derivative(optimum)),
            "maximum_pair_marginal_absolute_error": largest_pair_error,
            "empirical_probabilities": p, "maxent_probabilities": q,
            "empirical_full_parity_moment": fjson(Fraction(sum(s * c for s, c in zip(signs, counts)), n_shots)),
            "maxent_full_parity_moment": sum(s * x for s, x in zip(signs, q)),
            "empirical_entropy_bits": entropy(p), "maxent_entropy_bits": entropy(q),
            "kl_empirical_to_maxent_bits_per_observation": kl_bits,
            "entropy_gap_bits_per_observation": entropy(q) - entropy(p),
            "joint_total_variation_distance": 0.5 * sum(abs(a - b) for a, b in zip(p, q)),
            "conditional_comparisons": rows,
            "in_sample_prediction_comparison": {
                "scope": "Descriptive scores on the same selected observations used to fit both models. No held-out validation or causal interpretation.",
                "empirical_frequency_accuracy": fjson(Fraction(empirical_correct, n_shots)),
                "maxent_accuracy": fjson(Fraction(maxent_correct, n_shots)),
                "empirical_frequency_correct_count": empirical_correct,
                "maxent_correct_count": maxent_correct,
                "accuracy_improvement": fjson(Fraction(empirical_correct - maxent_correct, n_shots)),
                "empirical_frequency_logloss_bits": empirical_logloss_bits,
                "maxent_logloss_bits": maxent_logloss_bits,
                "empirical_frequency_brier": empirical_brier,
                "maxent_brier": maxent_brier,
            },
        },
    }


def selected_smoothing(record, bits):
    counts = histogram_projection(record["logicalCounts"], bits)
    shots = record["shots"]
    output = []
    for alpha in (Fraction(0), Fraction(1, 2), Fraction(1)):
        normalizer = shots + 16 * alpha
        probabilities = [(c + alpha) / normalizer for c in counts]
        geometry = certify_fixed_pair_dimension(probabilities)
        assert geometry["dimension_certified_by_relative_interior_witness"]
        axes = pure_axis_results(probabilities, bits)
        output.append({
            "pseudocount_per_joint_category": fjson(alpha),
            "probability_normalizer": fjson(normalizer),
            "uniform_mixture_weight": fjson(16 * alpha / normalizer),
            "probabilities": [str(x) for x in probabilities],
            "geometry": geometry,
            "pure_coordinate_axes": axes,
            "number_of_fully_blocked_pure_axes": sum(x["blocked_in_both_directions"] for x in axes),
            "maximum_single_axis_absolute_parity_moment_change": max(x["maximum_absolute_parity_moment_change"]["decimal"] for x in axes),
            "maximum_single_axis_total_variation": max(x["maximum_total_variation_from_start"]["decimal"] for x in axes),
        })
    zero_pair = None
    if bits == [5, 6, 10, 11]:
        pair_ones = counts[6] + counts[7] + counts[14] + counts[15]
        assert pair_ones == 0
        zero_pair = {
            "event": {"6": 1, "10": 1}, "observed_count": 0, "shots": shots,
            "one_sided_95_percent_exact_binomial_upper_bound": 1 - 0.05 ** (1 / shots),
            "assumptions": "IID stable shots and a fixed preselected event. Does not adjust for exploratory selection.",
            "sensitivity_probabilities": [
                {"alpha": str(a), "probability": fjson(4 * a / (shots + 16 * a))}
                for a in (Fraction(0), Fraction(1, 2), Fraction(1))
            ],
        }
    return {
        "record_id": record["recordId"], "bits": bits, "counts": counts,
        "outcome_order": [format(i, "04b") for i in range(16)],
        "scope": "Symmetric joint-category pseudocount sensitivity. Alpha>0 creates an assumption-based smoothed design and changes the empirical pair marginals; it is not an additional observation or an unconstrained movement inside the original fixed-pair face.",
        "axis_interval_caution": "Each interval applies to one coordinate moved alone from the stated table. The collection is not a feasible rectangular box for simultaneous moves.",
        "cases": output, "selected_zero_pair": zero_pair,
    }


def archive_axis_survey(records, bits):
    rows = []
    for record in records:
        counts = histogram_projection(record["logicalCounts"], bits)
        probabilities = [Fraction(c, record["shots"]) for c in counts]
        axes = pure_axis_results(probabilities, bits)
        witnesses = []
        for mask, context_mask, value, vector in context_directions(4):
            lower, upper = direction_interval(probabilities, vector)
            if lower == upper:
                continue
            # Explicitly verify that this context direction preserves pair marginals.
            for positions in combinations(range(4), 2):
                assert marginal(vector, positions, 4) == (0, 0, 0, 0)
            witnesses.append({
                "parity_bits": labels(bits, mask), "context_bit": labels(bits, context_mask)[0],
                "context_value": value,
                "probability_step_interval": [fjson(lower), fjson(upper)],
            })
        rows.append({
            "record_id": record["recordId"], "shots": record["shots"],
            "zero_joint_categories": counts.count(0),
            "blocked_pure_axis_count": sum(a["blocked_in_both_directions"] for a in axes),
            "movable_context_direction_count": len(witnesses),
            "movable_context_directions": witnesses,
        })
    return {
        "bits": bits,
        "record_count": len(rows),
        "all_five_pure_axes_blocked_count": sum(r["blocked_pure_axis_count"] == 5 for r in rows),
        "at_least_one_pure_axis_blocked_count": sum(r["blocked_pure_axis_count"] > 0 for r in rows),
        "all_pure_axes_blocked_but_context_direction_available_count": sum(
            r["blocked_pure_axis_count"] == 5 and r["movable_context_direction_count"] > 0 for r in rows
        ),
        "scope": "Empirical support geometry of selected historical records. Two projections share the same 32 records. Failure to find one of these eight context directions does not prove that no other coupled direction exists.",
        "records": rows,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dir", type=Path, required=True, help="Extracted original release root")
    parser.add_argument("--output", type=Path, required=True, help="Output directory for statistical_findings.json")
    args = parser.parse_args()
    source = args.source_dir.resolve()
    inputs = {name: source / "relational_operations" / "data" / name for name in ("records.json", "covariance_records.json")}
    simple = json.loads(inputs["records.json"].read_text())
    covariance = json.loads(inputs["covariance_records.json"].read_text())
    record = next(r for r in simple["records"] if r["recordId"] == "E32:S04")
    full_record = next(r for r in covariance["records"] if r["recordId"] == "E32:S04")
    selected_bits = ([5, 6, 10, 11], [2, 5, 6, 11])
    result = {
        "schema": "relational-operations-independent-statistical-research/1",
        "runtime": {"python": platform.python_version(), "scipy": scipy.__version__},
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "source_snapshot": simple["snapshotTag"],
        "source_data_sha256": {name: hashlib.sha256(path.read_bytes()).hexdigest() for name, path in inputs.items()},
        "new_measurements": 0,
        "overall_interpretation": [
            "The conditional interval is descriptive under its stated IID and fixed-event assumptions; exploratory selection remains uncorrected.",
            "Maximum entropy is a classical fitted reference, not ground truth. Its discrepancy from the empirical table is in-sample and may include sampling noise.",
            "Pseudocount cases are assumption-based sensitivity designs and are never labeled recorded observations.",
            "This analysis contains no human data, new physical runs, causal-effect estimates, or evidence of improved deployed AI performance.",
        ],
        "three_bit_analysis": three_bit_maxent(record),
        "selected_four_bit_sensitivity": [selected_smoothing(full_record, list(bits)) for bits in selected_bits],
        "historical_support_survey": [archive_axis_survey(covariance["records"], list(bits)) for bits in selected_bits],
    }
    args.output.mkdir(parents=True, exist_ok=True)
    destination = args.output / "statistical_findings.json"
    destination.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(destination)
    print(json.dumps({
        "conditional_95_percent_interval": result["three_bit_analysis"]["selected_conditional_uncertainty"]["interval"],
        "maxent_conditional": next(r["maxent_conditional"] for r in result["three_bit_analysis"]["maxent_fit"]["conditional_comparisons"] if r["condition"] == {"5": 1, "11": 0}),
        "entropy_gap_bits": result["three_bit_analysis"]["maxent_fit"]["entropy_gap_bits_per_observation"],
        "support_surveys": [{k: v for k, v in s.items() if k not in ("records", "scope")} for s in result["historical_support_survey"]],
    }, indent=2))


if __name__ == "__main__":
    main()
