"""Focused independent checks of the compact decoder's input contract.

Run with the unmodified release extracted locally:
  python verify_input_contract.py --source-dir PATH_TO_RELEASE

Uses one retained record and the Python standard library. The original package
is not imported. Expected moments are computed directly from its histogram.
"""
from __future__ import annotations

import argparse
from copy import deepcopy
from fractions import Fraction
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import sys


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def expect_rejection(operation):
    try:
        operation()
    except ValueError as error:
        return {'exception': 'ValueError', 'message': str(error)}
    raise AssertionError('Invalid input was accepted')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir', required=True, type=Path)
    parser.add_argument('--record-id', default='E32:S04')
    parser.add_argument('--output', type=Path,
                        default=Path(__file__).resolve().parent / 'results/input_contract_verification.json')
    args = parser.parse_args()
    sys.dont_write_bytecode = True
    companion_path = Path(__file__).resolve().with_name('compact_covariance.py')
    companion_hash = hashlib.sha256(companion_path.read_bytes()).hexdigest()
    spec = importlib.util.spec_from_file_location('compact_contract_subject', companion_path)
    decoder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(decoder)

    data_path = args.source_dir / 'relational_operations/data/covariance_records.json'
    raw = data_path.read_bytes()
    source_hash = hashlib.sha256(raw).hexdigest()
    manifest = json.loads(data_path.with_name('MANIFEST.json').read_text())
    expected_hash = next(item['sha256'] for item in manifest['files']
                         if item['path'] == data_path.name)
    require(source_hash == expected_hash, 'Original data do not match their manifest')
    data = json.loads(raw)
    require(data['sameShotCrossCovariance'] is True, 'Same-shot convention is required')
    record = next(item for item in data['records'] if item['recordId'] == args.record_id)
    features = data['physicalMasks']
    plan = decoder.make_plan(max(features).bit_length(), features)
    selected = decoder.selective_input(record, plan)

    # Independent oracle: count negative parities in the retained histogram.
    shots = record['shots']
    histogram = [(int(word, 2), count) for word, count in record['logicalCounts'].items()]
    require(sum(count for _, count in histogram) == shots, 'Histogram shot count differs')
    variables = max(features).bit_length()
    truth = {}
    for mask in range(1 << variables):
        if mask.bit_count() <= 4:
            negative = sum(count for word, count in histogram
                           if (word & mask).bit_count() % 2)
            truth[mask] = Fraction(shots - 2 * negative, shots)

    cases = []

    def run_case(name, operation):
        try:
            detail = operation()
            cases.append({'name': name, 'status': 'PASS', **detail})
        except Exception as error:
            cases.append({'name': name, 'status': 'FAIL',
                          'exception': type(error).__name__, 'message': str(error)})

    def check_selective():
        recovered = decoder.decode_selective(selected, features, plan)
        require(recovered == truth, 'Selected recovery differs from histogram oracle')
        return {'coefficientsIncludingNormalization': len(recovered), 'exactHistogramMatch': True}

    def check_rounded(all_paths):
        result = decoder.decode_rounded(record, features, plan, 6, all_paths)
        require(result['status'] == 'EXACT', 'Valid six-decimal record was not recovered')
        require(result['moments'] == truth, 'Rounded recovery differs from histogram oracle')
        require(result['ambiguousMoments'] == result['zeroCandidateMoments'] == 0,
                'Exact result contains unresolved moments')
        return {'decimalPlaces': 6, 'coefficientsIncludingNormalization': len(truth),
                'exactHistogramMatch': True}

    run_case('valid_selected_record', check_selective)
    run_case('valid_six_decimal_selected_routes', lambda: check_rounded(False))
    run_case('valid_six_decimal_all_higher_order_routes', lambda: check_rounded(True))

    short_means = deepcopy(selected)
    short_means['means'].pop()
    run_case('missing_mean_selected', lambda: expect_rejection(
        lambda: decoder.decode_selective(short_means, features, plan)))
    short_full_means = deepcopy(record)
    short_full_means['means'].pop()
    for all_paths in (False, True):
        run_case(f'missing_mean_rounded_all_paths_{all_paths}', lambda: expect_rejection(
            lambda: decoder.decode_rounded(short_full_means, features, plan, 6, all_paths)))

    short_values = deepcopy(selected)
    short_values['covarianceValues'].pop()
    run_case('truncated_selected_covariance', lambda: expect_rejection(
        lambda: decoder.decode_selective(short_values, features, plan)))

    short_plan = plan[:-1]
    # Match the payload length to the truncated plan: coverage, not just length,
    # must be rejected to prevent an incomplete result being labeled exact.
    short_plan_input = decoder.selective_input(record, short_plan)
    run_case('truncated_plan_selected', lambda: expect_rejection(
        lambda: decoder.decode_selective(short_plan_input, features, short_plan)))
    for all_paths in (False, True):
        run_case(f'truncated_plan_rounded_all_paths_{all_paths}', lambda: expect_rejection(
            lambda: decoder.decode_rounded(record, features, short_plan, 6, all_paths)))

    for name, precision in [('negative', -1), ('fractional', 6.5), ('integer_float', 6.0),
                            ('string', '6'), ('boolean', True), ('none', None)]:
        run_case(f'invalid_decimal_precision_{name}', lambda: expect_rejection(
            lambda: decoder.decode_rounded(record, features, plan, precision)))

    data_unchanged = hashlib.sha256(data_path.read_bytes()).hexdigest() == source_hash
    companion_unchanged = hashlib.sha256(companion_path.read_bytes()).hexdigest() == companion_hash
    failed = sum(case['status'] != 'PASS' for case in cases)
    report = {
        'schema': 'compact-covariance-input-contract-verification/1',
        'status': 'PASS' if failed == 0 and data_unchanged and companion_unchanged else 'FAIL',
        'pythonVersion': platform.python_version(),
        'verifierSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'companionSHA256': companion_hash, 'sourceDataSHA256': source_hash,
        'recordId': record['recordId'], 'shots': shots,
        'featureMeans': len(features), 'selectedCovarianceEntries': len(plan),
        'oracleCoefficientsIncludingNormalization': len(truth),
        'casesPassed': len(cases) - failed, 'casesFailed': failed, 'cases': cases,
        'sourceDataUnchangedDuringCheck': data_unchanged,
        'companionUnchangedDuringCheck': companion_unchanged,
        'originalPackageImported': False,
        'scope': 'Focused invalid-input regressions and exact recovery of one retained record. '
                 'No full performance experiment, new observations, or original-release edits.',
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({key: value for key, value in report.items() if key != 'cases'}, indent=2))
    if report['status'] != 'PASS':
        raise SystemExit(1)


if __name__ == '__main__':
    main()
