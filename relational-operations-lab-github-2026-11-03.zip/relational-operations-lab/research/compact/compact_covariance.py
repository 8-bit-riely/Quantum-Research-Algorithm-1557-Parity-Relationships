"""Research companion: selective covariance recovery and certified rounding.

Uses the standard Boolean moment identity, not a newly claimed theorem.
Input is the unmodified Relational Operations Lab v0.1.0 experimental source.
All comparisons use the same retained records; no new physical observations.

Run:
  python compact_covariance.py --source-dir PATH_TO_EXTRACTED_RELEASE --output out

Standard-library implementation. The original package is imported only for the
full-archive comparison decoder. Selected-entry recovery is for a previously
validated archive and does not reproduce all redundant-path integrity checks.
"""
from __future__ import annotations

import argparse
from fractions import Fraction
import gzip
import hashlib
from itertools import combinations
import json
from math import ceil, floor, comb
from pathlib import Path
import platform
from statistics import median
import sys
from time import perf_counter


def masks_through(n, order):
    return sorted((m for m in range(1, 1 << n) if m.bit_count() <= order),
                  key=lambda m: (m.bit_count(), m))


def make_plan(n, feature_masks):
    """One available covariance entry for every missing target moment."""
    targets = masks_through(n, 4)
    existing = set(feature_masks)
    routes = {}
    for i, a in enumerate(feature_masks):
        for j in range(i + 1, len(feature_masks)):
            mask = a ^ feature_masks[j]
            if mask not in existing and mask:
                routes.setdefault(mask, (i, j))
    missing = [m for m in targets if m not in existing]
    if any(m not in routes for m in missing):
        raise ValueError('Feature list does not cover every target through order four')
    return [(m, *routes[m]) for m in missing]


def lattice(value, shots, tolerance=1e-7):
    scaled = value * shots
    numerator = round(scaled)
    if abs(scaled - numerator) > tolerance or abs(numerator) > shots or (shots - numerator) % 2:
        raise ValueError('Not a compatible exact empirical moment')
    return Fraction(numerator, shots)


def selective_input(record, plan):
    return {'shots': record['shots'], 'means': record['means'],
            'covarianceValues': [record['meanCovariance'][i][j] for _, i, j in plan]}


def validate_input_contract(record, feature_masks, plan, full_covariance=False):
    """Reject incomplete input/coverage before claiming a complete recovery."""
    if not feature_masks or any(type(m) is not int or m <= 0 for m in feature_masks):
        raise ValueError('Nonempty positive integer feature masks required')
    n = max(feature_masks).bit_length()
    features = set(feature_masks)
    if (len(features) != len(feature_masks) or len(features) != n + comb(n, 2)
            or any(m.bit_count() not in (1, 2) for m in features)):
        raise ValueError('Complete unique single/pair feature masks required')
    if type(record['shots']) is not int or record['shots'] < 2:
        raise ValueError('Known integer shot count of at least two required')
    if len(record['means']) != len(feature_masks):
        raise ValueError('Feature-mean dimensions differ')
    targets = set()
    for mask, i, j in plan:
        if (type(mask) is not int or type(i) is not int or type(j) is not int
                or not (0 <= i < len(feature_masks) and 0 <= j < len(feature_masks))
                or mask != feature_masks[i] ^ feature_masks[j]
                or mask.bit_count() not in (3, 4) or mask in targets):
            raise ValueError('Invalid or repeated covariance target route')
        targets.add(mask)
    expected = sum(comb(n, k) for k in (3, 4) if k <= n)
    if len(targets) != expected:
        raise ValueError('Covariance plan does not cover all intended target moments')
    if full_covariance:
        matrix = record['meanCovariance']
        if len(matrix) != len(feature_masks) or any(len(row) != len(feature_masks) for row in matrix):
            raise ValueError('Covariance matrix dimensions differ')
    elif len(record['covarianceValues']) != len(plan):
        raise ValueError('Selected covariance-value count differs from plan')


def decode_selective(record, feature_masks, plan):
    validate_input_contract(record, feature_masks, plan)
    n = record['shots']
    means = record['means']
    result = {0: Fraction(1)}
    result.update((m, lattice(v, n)) for m, v in zip(feature_masks, means))
    for (mask, i, j), value in zip(plan, record['covarianceValues']):
        result[mask] = lattice((n - 1) * value + means[i] * means[j], n)
    return result


def direct_moments(record, target_masks):
    hist = {int(w, 2): c for w, c in record['logicalCounts'].items()}
    n = record['shots']
    return {m: Fraction(sum(c * (-1 if (w & m).bit_count() % 2 else 1)
                            for w, c in hist.items()), n)
            for m in [0, *target_masks]}


def inverse_subset(bits, moments):
    probabilities = []
    n = len(bits)
    for x in range(1 << n):
        value = Fraction(0)
        for local_mask in range(1 << n):
            physical = sum(1 << bits[n - 1 - j] for j in range(n)
                           if local_mask & (1 << j))
            value += (-1 if (x & local_mask).bit_count() % 2 else 1) * moments[physical]
        probabilities.append(value / (1 << n))
    return probabilities


def histogram_subset(record, bits):
    counts = [0] * (1 << len(bits))
    for word, count in record['logicalCounts'].items():
        value = int(word, 2)
        category = 0
        for bit in bits:
            category = (category << 1) | ((value >> bit) & 1)
        counts[category] += count
    return counts


def allowed_numerators(lo, hi, n):
    """Closed interval intersected with {-N,-N+2,...,N}."""
    first = max(-n, ceil(lo * n))
    last = min(n, floor(hi * n))
    first += (n - first) % 2
    last -= (n - last) % 2
    count = max(0, (last - first) // 2 + 1)
    return first, last, count


def decode_rounded(record, feature_masks, plan, decimal_places, use_all_paths=False):
    """Certified recovery under an explicit nearest-decimal rounding contract.

    Underlying statistics are empirical parity means and CovMean values for N
    common shots. Each supplied decimal represents an interval of radius half
    a decimal unit. A moment is returned only when that interval contains one
    numerator on the exact parity lattice. No point estimate is invented for
    an ambiguous interval. This is representation recovery, not a population CI.
    """
    validate_input_contract(record, feature_masks, plan, full_covariance=True)
    if type(decimal_places) is not int or decimal_places < 0:
        raise ValueError('Nonnegative integer decimal-place contract required')
    n = record['shots']
    half_unit = Fraction(1, 2 * 10 ** decimal_places)
    result = {0: Fraction(1)}
    for mask, mean in zip(feature_masks, record['means']):
        center = Fraction(format(mean, f'.{decimal_places}f'))
        first, last, count = allowed_numerators(center - half_unit, center + half_unit, n)
        if count != 1:
            return {'status': 'AMBIGUOUS_MEAN', 'ambiguousMoments': 1,
                    'zeroCandidateMoments': int(count == 0), 'moments': result}
        result[mask] = Fraction(first, n)
    intervals = {}
    if use_all_paths:
        paths = [(a ^ b, i, j) for i, a in enumerate(feature_masks)
                 for j, b in enumerate(feature_masks) if i < j and (a ^ b) not in result]
    else:
        paths = plan
    for mask, i, j in paths:
        center = Fraction(format(record['meanCovariance'][i][j], f'.{decimal_places}f'))
        product = result[feature_masks[i]] * result[feature_masks[j]]
        lo = (n - 1) * (center - half_unit) + product
        hi = (n - 1) * (center + half_unit) + product
        if mask in intervals:
            lo = max(lo, intervals[mask][0]); hi = min(hi, intervals[mask][1])
        intervals[mask] = (lo, hi)
    ambiguous = 0; zero = 0; largest = 0
    for mask, (lo, hi) in intervals.items():
        first, last, count = allowed_numerators(lo, hi, n)
        largest = max(largest, count)
        if count == 1:
            result[mask] = Fraction(first, n)
        elif count == 0:
            zero += 1
        else:
            ambiguous += 1
    return {'status': 'EXACT' if not ambiguous and not zero else 'UNRESOLVED',
            'ambiguousMoments': ambiguous, 'zeroCandidateMoments': zero,
            'maximumCandidatesInOneMoment': largest, 'moments': result}


def packed(value):
    return json.dumps(value, separators=(',', ':'), allow_nan=False).encode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--benchmark-repeats', type=int, default=5)
    args = parser.parse_args()
    root = args.source_dir.resolve()
    sys.path.insert(0, str(root))
    from relational_operations.extensions import recover_archived_moments
    data_path = root / 'relational_operations/data/covariance_records.json'
    raw = data_path.read_bytes()
    data = json.loads(raw)
    manifest = json.loads(data_path.with_name('MANIFEST.json').read_text())
    expected_hash = next(x['sha256'] for x in manifest['files'] if x['path'] == data_path.name)
    assert hashlib.sha256(raw).hexdigest() == expected_hash
    assert data['sameShotCrossCovariance'] is True
    feature_masks = data['physicalMasks']
    target_masks = masks_through(12, 4)
    plan = make_plan(12, feature_masks)
    records = data['records']
    small = [selective_input(record, plan) for record in records]
    exact_records = []
    validations = []; projections = 0; max_covariance_error = 0.0
    reference = []
    for record, selected in zip(records, small):
        recovered = decode_selective(selected, feature_masks, plan)
        baseline, _ = recover_archived_moments(feature_masks, record['means'],
                                              record['meanCovariance'], record['shots'])
        direct = direct_moments(record, target_masks)
        assert recovered == baseline == direct
        reference.append(direct)
        for bits in ([5, 6, 10, 11], [2, 5, 6, 11]):
            reconstructed = [p * record['shots'] for p in inverse_subset(bits, recovered)]
            assert reconstructed == histogram_subset(record, bits)
            projections += 1
        for i, a in enumerate(feature_masks):
            for j, b in enumerate(feature_masks):
                rebuilt = (recovered[a ^ b] - recovered[a] * recovered[b]) / (record['shots'] - 1)
                max_covariance_error = max(max_covariance_error,
                                          abs(float(rebuilt) - record['meanCovariance'][i][j]))
        exact_records.append({'recordId': record['recordId'], 'shots': record['shots'],
                              'provenance': record['provenance'],
                              'signedNumerators': [int(recovered[m] * record['shots']) for m in target_masks]})
        validations.append({'recordId': record['recordId'], 'allMomentsAgree': True})

    precision_results = []
    for decimals in (5, 6, 8):
        for all_paths in (False, True):
            exact_count = 0; ambiguous_count = 0; zero_count = 0; wrong_count = 0; max_candidates = 0
            for record, truth in zip(records, reference):
                result = decode_rounded(record, feature_masks, plan, decimals, all_paths)
                wrong_count += sum(v != truth[m] for m, v in result['moments'].items())
                if len(result['moments']) == len(truth) and result['status'] == 'EXACT':
                    exact_count += 1
                ambiguous_count += result['ambiguousMoments']
                zero_count += result['zeroCandidateMoments']
                max_candidates = max(max_candidates, result.get('maximumCandidatesInOneMoment', 0))
            assert wrong_count == 0
            precision_results.append({'decimalPlaces': decimals,
                                      'paths': 'all_unique_feature_pairs' if all_paths else 'one_per_missing_moment',
                                      'recordsFullyRecovered': exact_count, 'totalRecords': len(records),
                                      'ambiguousMomentsAcrossRecords': ambiguous_count,
                                      'zeroCandidateMoments': zero_count,
                                      'maximumCandidatesInOneMoment': max_candidates,
                                      'incorrectReturnedMoments': wrong_count})

    strict_rounding = []
    for decimals in (5, 6, 8, 12, 13, 14):
        successes = 0
        for record, truth in zip(records, reference):
            means = [round(v, decimals) for v in record['means']]
            covariance = [[round(v, decimals) for v in row] for row in record['meanCovariance']]
            try:
                recovered, _ = recover_archived_moments(feature_masks, means, covariance, record['shots'])
            except ValueError:
                continue
            assert recovered == truth
            successes += 1
        strict_rounding.append({'decimalPlaces': decimals, 'recordsAccepted': successes,
                                'totalRecords': len(records)})

    baseline_times = []; selected_times = []
    for _ in range(args.benchmark_repeats):
        start = perf_counter()
        for record in records:
            recover_archived_moments(feature_masks, record['means'], record['meanCovariance'], record['shots'])
        baseline_times.append(perf_counter() - start)
        start = perf_counter()
        for record in small:
            decode_selective(record, feature_masks, plan)
        selected_times.append(perf_counter() - start)

    full_payload = [{'shots': r['shots'], 'means': r['means'], 'meanCovariance': r['meanCovariance']}
                    for r in records]
    exact_payload = [{'shots': r['shots'], 'signedNumerators': r['signedNumerators']} for r in exact_records]
    encodings = {'full_mean_covariance': full_payload, 'selected_mean_covariance': small,
                 'exact_signed_moments': exact_payload}
    sizes = {name: {'compactJSONBytes': len(packed(value)),
                    'gzipLevel9Bytes': len(gzip.compress(packed(value), compresslevel=9, mtime=0))}
             for name, value in encodings.items()}
    report = {
        'schema': 'relational-research-selective-covariance/1',
        'sourceSHA256': expected_hash, 'pythonVersion': platform.python_version(),
        'records': len(records), 'shots': sum(r['shots'] for r in records),
        'featureMeansPerRecord': len(feature_masks), 'fullCovarianceEntriesPerRecord': len(feature_masks) ** 2,
        'selectedCovarianceEntriesPerRecord': len(plan), 'nonconstantMomentsPerRecord': len(target_masks),
        'fullScalarInputsPerRecord': len(feature_masks) + len(feature_masks) ** 2,
        'symmetricScalarInputsPerRecord': len(feature_masks) + len(feature_masks) * (len(feature_masks) + 1) // 2,
        'selectedScalarInputsPerRecord': len(feature_masks) + len(plan),
        'exactFourBitReconstructions': projections,
        'maxRebuiltCovarianceFloatDifference': max_covariance_error,
        'inputReductionFromFullMatrixPercent': 100 * (1 - (len(feature_masks) + len(plan)) / (len(feature_masks) + len(feature_masks) ** 2)),
        'inputReductionFromSymmetricMatrixPercent': 100 * (1 - (len(feature_masks) + len(plan)) / (len(feature_masks) + len(feature_masks) * (len(feature_masks) + 1) // 2)),
        'numericPayloadSizesExcludingCommonProvenanceAndSharedMaskPlan': sizes,
        'roundingAwareRecovery': precision_results,
        'originalStrictDecoderOnRoundedInputs': strict_rounding,
        'benchmark': {'repeats': args.benchmark_repeats, 'recordsPerRepeat': len(records),
                      'fullDecoderMedianSeconds': median(baseline_times),
                      'selectiveDecoderMedianSeconds': median(selected_times),
                      'ratioOfMedianTimes': median(baseline_times) / median(selected_times),
                      'fullTimes': baseline_times, 'selectedTimes': selected_times,
                      'scope': 'Already loaded validated records; selected decoder omits redundant consistency checks. No claim of equivalent audit coverage or downstream AI speedup.'},
        'interpretation': 'Known moment algebra implemented as a compact recovery instrument. Floating input encodings are not bitwise preserved; underlying empirical moments and named distributions are exact.',
        'roundingContract': 'Nearest-decimal rounding with known absolute half-unit bound; same-shot empirical parity statistics and known N. This is not recovery from arbitrary measurement noise.',
        'newMeasurements': 0, 'humanObservations': 0, 'providerCalls': 0,
        'recordValidation': validations,
    }
    args.output.mkdir(parents=True, exist_ok=True)
    (args.output / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
    (args.output / 'covariance_read_plan.json').write_text(json.dumps({
        'featureMasks': feature_masks,
        'selectedEntries': [{'targetMask': m, 'row': i, 'column': j,
                             'featureMasks': [feature_masks[i], feature_masks[j]]} for m, i, j in plan]}, indent=2) + '\n')
    (args.output / 'exact_moment_archive.json').write_text(json.dumps({
        'schema': 'exact-empirical-parity-moments/1', 'sourceSHA256': expected_hash,
        'variables': 12, 'maximumOrder': 4, 'maskOrder': target_masks,
        'meaning': 'Each signed numerator divided by shots is an empirical parity moment; derived from retained statistics, not new observations.',
        'records': exact_records}, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k not in ('recordValidation',)}, indent=2))


if __name__ == '__main__':
    main()
