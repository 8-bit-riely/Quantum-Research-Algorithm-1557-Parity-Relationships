# Algorithm research snapshot — 2026-11-03

This GitHub-ready source snapshot combines the original Relational Operations
Lab core with executable research extensions. The original distribution
metadata remains **`0.1.0a1`** and its source snapshot label remains
`v0.1.0-experimental`. This document describes the assembled snapshot; it does
not create a release tag or claim publication.

## Additions

- **Selective covariance recovery:** a shared read plan uses 78 feature means
  and 715 covariance entries to recover all 793 nonconstant moments through
  order four. All 32 records and 64 named four-bit reconstructions agree exactly
  with the source histograms.
- **Rounding-aware recovery:** rational rounding intervals and the empirical
  parity lattice recover every record at six decimal places under an explicit
  nearest-decimal contract. Ambiguous values are reported rather than guessed.
- **Complete support geometry:** coordinate-maximization LPs, exact rational
  primal/dual certificates, feasible interior points and nullspace bases identify
  the full family at fixed individual and pair statistics.
- **Archive-wide validation:** all 1,024 coordinate maxima across 64 overlapping
  projections are certified. The archive contains 53 nontrivial families and
  11 singletons. A separate synthetic audit checks all 255 nonempty three-bit
  support patterns, with one uniform table per pattern.
- **Statistical companion:** conditional uncertainty, a pairwise maximum-entropy
  comparison and explicitly labelled pseudocount sensitivity calculations.
- **Reproduction materials:** `tools/verify_research.py`, research dependencies,
  saved results, exact certificates, mathematical notes and the research PDF.

## Integration

The research algorithms live under `research/`, alongside the original
`relational_operations` core. The original CLI and offline editor are retained;
this work adds algorithm extensions rather than a new editor interface. The
original README is preserved at `docs/ORIGINAL_README.md`.

From the repository root with Python 3.12:

```bash
python -m pip install -e '.[research]'
python tools/verify_research.py
```

Use `--certificates-only` for the standard-library certificate/input checks.
See [README.md](README.md) for standalone algorithm commands and upload steps.

## Interpretation

This work reanalyses retained observations. It adds no human dataset, new
physical run, physical control demonstration or improved AI performance result.
The 64 projections reuse 32 records and 25,600 shots. Mathematical feasible
families condition on exact empirical margins; recorded zeros do not establish
population impossibilities.

The selective decoder omits redundant audit checks. The rounding guarantee
requires its specified input contract. Statistical comparisons remain
exploratory and in-sample. The mathematical foundations and related methods
are established; no universal novelty claim is made. See
[PROOFS.txt](docs/PROOFS.txt) and [Scientific scope](SCIENTIFIC_SCOPE.md).
