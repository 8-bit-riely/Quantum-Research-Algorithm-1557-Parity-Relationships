# Contributing

Reproducibility reports, clearer explanations and small, well-scoped code changes
are welcome. Include the snapshot version and a command or example that shows
the behavior you are reporting.

Run the Python checks before proposing a change:

```bash
python -m unittest discover -s tests -v
python -m relational_operations verify-data
python -m relational_operations build --output site
```

With Node.js 18 or newer, check the two browser instruments:

```bash
node tests/check_workbench.cjs site/triple.html
node tests/check_extensions.cjs site/index.html
```

Keep recorded measurements, derived quantities and analytical designs distinct.
Preserve record-level boundaries and describe the covariance convention when
adding statistics. Numerical identities, physical interpretations and useful
applications are separate claims and should have their own evidence.

Changes should not require a quantum account or start a paid service. Link
third-party research rather than adding paper PDFs under this project's license.
Do not include credentials, operational account identifiers or private paths.

Code contributions are under MIT. New data contributions must identify their
source, reuse rights and intended license; existing bundled data is CC BY 4.0.
