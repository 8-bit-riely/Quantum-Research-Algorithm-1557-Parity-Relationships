# Three more independent instruments

The relationship editor now has a covariance decoder, an observability audit,
and coupled context controls. These are exact operations on retained statistics
and probability specifications, usable independently of JIM or AI.

## 1. Recover information already stored in cross-covariances

A parity feature is+1 for even parity and-1 for odd parity on a selected set.
The product of two such features is the feature on their symmetric difference:
shared bits cancel. With means known, full same-shot cross-covariance therefore
contains additional joint moments.

For the retained empirical covariance-of-means convention:

`m(A XOR B) = (N-1) CovMean(A,B) + m(A)*m(B)`.

This reconstructs the empirical second moment of the features. It is not a
correction for device bias or a source of independent observations. The known
shot count, same-shot feature definition and covariance convention are essential.

For four bits, the ten individual/pair means plus their full10x10 cross-covariance
recover all15 nonconstant parity coefficients. An inverse transform then recovers
all16 recorded probabilities. The decoder verifies its result against the raw
histograms; it does not infer phases or reconstruct a quantum density matrix.

For twelve bits, the analogous coverage grows from78 to793 coordinates: all
orders through four. The full distribution has4095 nonconstant coordinates.
The remaining3302 higher-order coordinates are not supplied by that summary.

The data export checks32 retained records /25,600 physical shots, reconstructs
793 coefficients per record, and exactly recovers two four-bit projections per
record. No additional QPU shots are needed for this extraction.

## 2. Audit what a measurement format can distinguish

The coverage instrument reports coefficient sets, rather than assuming that
more fields necessarily mean more information. For four bits:

|Retained format|Recoverable nonconstant coordinates|
|---|---:|
|Individual means|4 of15|
|Individual and pair means|10 of15|
|Those means and full same-shot cross-covariance|15 of15|
|Complete measured histogram|15 of15|

The covariance step uses exactly one feature-product/XOR operation; iterating
it as a transitive closure would incorrectly invent unrecorded information.
Pair tables alone and pair-feature means WITH their full cross-covariance are
different observation contracts. Only the former has the five-coordinate blind
space in this four-bit example.

This can guide statistics export, measurement software and instrument design.
No learner or neural network is required to use the audit.

## 3. Move linked relationships when isolated controls cannot move

The original EMERALD32 S04 logical bits[5,6,10,11] have16 counts:

`[450,252,7,3,28,34,0,0,4,10,1,0,8,3,0,0]`.

Each of the four pure triple-coordinate moves and the pure quadruple-coordinate
move has interval[0,0] in this exact table. Those isolated sliders are blocked
by empty cells. Yet two linked controls remain available:

`U = paritySign(5,6,11) * indicator(bit10=0)`

`V = paritySign(5,10,11) * indicator(bit6=0)`

`countSpecifications' = recordedCounts + u*U + v*V`

The complete valid family at the recorded pair tables is the rectangle:

`-8 <= u <= 3` and `-1 <= v <= 0`.

All four individual rates and all six pair tables remain fixed. Three higher-order
coefficients move together:

- Moment5,6,11 changes by u/100.
- Moment5,10,11 changes by v/100.
- Moment5,6,10,11 changes by(u+v)/100.

For example, U is half the sum of the triple and quadruple parity directions.
Their effects cancel on the blocked context, allowing the combined operation.
This is a tangible reason to examine joint movements rather than conclude from
five blocked individual controls that no relationship can change.

The fixed pair6/10 table is[716,11,73,0]. Its final zero forces four full-table
categories to remain zero. Twelve categories are allowed, with ten independent
normalization/pair constraints: the resulting affine face has two dimensions.
U and V span those dimensions. Four cell inequalities give the necessary bounds;
validity of all rectangle corners gives sufficiency by convexity.

These are geometric constraints on a probability specification at exact recorded
marginals. They do not establish population zeros, physical controls or quantum
couplers. The alternative fixed projection[2,5,6,11] has all16 categories positive
and five individually movable higher-order directions. These two views were
chosen for the roles of source10 and shared source2, not by an outcome search.

## Use and interpretation

Open index.html in the generated site. Change the report profile to see when the designed
movement becomes visible. Switch between the two context projections. The
default view has two coupled sliders; the alternative view exposes five single
coordinate directions. Designs can be exported with their source pins and a
pair-preservation certificate.

The interface distinguishes recorded counts from analytical designs. Its source
files use Fraction arithmetic for proofs, and integer count units for browser
controls. Its covariance decoder reads the verified floating archive and checks
compatibility with the exact empirical parity lattice before reconstruction.

Applications include recovering useful information from existing archives,
checking whether a proposed summary is sufficient, and constructing references
for measurement or aggregation software. Physical-origin research remains a
complementary track; the mathematical operation specifies behaviors to investigate.

The mathematics uses the established parity/Fourier basis described by
[O'Donnell](https://www.cs.cmu.edu/~odonnell/papers/Analysis-of-Boolean-Functions-by-Ryan-ODonnell.pdf).
For higher-order dependence, see
[Schneidman et al.](https://www.princeton.edu/~wbialek/our_papers/schneidman%2Bal_03b.pdf).
Our contribution here is a working, source-bound instrument and record-specific
consequences, not a new-theorem claim.

All work is retained-data decoding, exact algebra, source construction and data/
serialization checks. There are no quantum dynamics, generated samples, learner
experiments, optimizer or parameter searches, provider calls or paid operations.
