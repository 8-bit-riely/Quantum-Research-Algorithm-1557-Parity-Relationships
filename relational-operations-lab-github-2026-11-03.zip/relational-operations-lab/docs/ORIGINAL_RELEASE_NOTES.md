> Historical documentation from v0.1.0-experimental. Relative links were adjusted for this location. See the [current README](../README.md) for this algorithm research package.

# Relational Operations Lab — v0.1.0-experimental

An experimental, reproducible research snapshot as of **3 November 2026**.

This first public snapshot provides exact probability-table editing, conditional
queries, observation-format audits, covariance-based moment recovery, and coupled
four-answer controls. It includes portable source, reusable aggregate measurement
tables, offline interactive examples and verification commands.

The browser demo starts at `docs/demo/index.html`. The simpler two/three-answer
editor is `docs/demo/triple.html`. No quantum account or GPU is needed.

The dataset includes 12 table examples and 32 covariance records. Their catalogs
overlap; they are not additive independent samples. Full released inputs support
reproducing the covariance checks and 64 four-answer histogram reconstructions.

Recorded data and mathematical designs are labeled separately. The motivating
selected association, its later nonreplication and the established mathematical
foundations are documented in `SCIENTIFIC_SCOPE.md`.

This is a selected research snapshot rather than a live mirror of ongoing
development. Later work may appear in separate releases. Please cite this version
when reporting results.

**Licenses:** MIT for code/documentation; CC BY 4.0 for released data tables.

When publishing on GitHub, mark this version as a **pre-release** and use the tag
`v0.1.0-experimental`. Record the actual publication date separately from the
snapshot date. This file is prepared release text; it does not imply publication.
