> Historical documentation from v0.1.0-experimental. Relative links were adjusted for this location. See the [current README](../README.md) for this algorithm research package.

# Relational Operations Lab

**Experimental research snapshot · v0.1.0-experimental · 2026-11-03**

![Recorded evidence, exact instruments and analytical designs](../docs/images/overview.svg)

Tools for inspecting, querying and editing relationships in binary probability
tables. Start with recorded measurements, calculate what their relationships
contain, and build exact reference tables that isolate a chosen effect.

This release is a dated, reproducible snapshot. It documents the code, data and
checks included here. Development continues separately; the repository is not a
live mirror of the research workstation. Later public updates will have their own version
and evidence record.

## What you can do

- **Edit a relationship while preserving simpler observations.** Change a
  higher-order probability coordinate while keeping specified individual or
  pair distributions fixed.
- **Query a table in either direction.** Calculate conditional probabilities
  from inputs toward an output, or from an output toward possible inputs.
- **Audit an observation format.** Identify which relationship coordinates its
  retained fields expose.
- **Recover information already saved in covariance.** Use compatible feature
  means and full same-shot cross-covariance to recover third- and fourth-order
  empirical moments.
- **Explore coupled controls.** Construct linked adjustments that remain valid
  where isolated coordinate moves are blocked by the table's support.

The tools run locally with Python 3.10 or newer and its standard library.
The interactive pages work offline in a browser. No quantum account, QPU, GPU,
learning model or cloud service is needed to use this snapshot.

## A concrete example

The included three-answer example has these recorded counts:

```text
Answers:  000  001  010  011  100  101  110  111
Counts:   457  255   28   34    5   10    8    3
```

Two valid analytical designs can preserve every individual rate and every pair
table while changing a three-answer conditional response:

| Given answer A = 1 and answer C = 0 | Lower design | Recorded table | Upper design |
|---|---:|---:|---:|
| Probability that B = 1 | 0% | 61.54% | 84.62% |
| Condition support, in original probability units | 13/800 | 13/800 | 13/800 |

The centre column is recorded evidence. The endpoints are mathematical table
specifications, clearly labelled as designs. The distinction is kept in the
interactive tools, exported JSON and documentation.

This makes the component useful for constructing references, checking what an
aggregation format retains, and exploring conditional relationships. Its uses
are independent of AI.

## Start here

1. Open [`docs/demo/index.html`](../docs/demo/index.html).
2. Move the relationship controls.
3. Switch between the report profiles. Compare pair means alone with pair means
   plus their full same-shot cross-covariance.
4. Inspect or export the resulting probability specification.

Run the exact table tools from the repository root:

```bash
python -m relational_operations condition --record E32:S04 --given 5=1 --given 11=0 --query 6
python -m relational_operations compare
python -m relational_operations audit --variables 4 --with-covariance
python -m relational_operations decode --record E32:S04 --subset 5 6 10 11
```

To build another local site, choose a new output directory:

```bash
python -m relational_operations build --output site
```

Run the Python checks:

```bash
python -m unittest discover -s tests -v
```

For a small Python API example, create the table directly:

```python
from fractions import Fraction
from relational_operations.core import JointTable

table = JointTable.from_counts(
    [5, 6, 11],
    [457, 255, 28, 34, 5, 10, 8, 3],
)

answer = table.conditional_lookup({5: 1, 11: 0}, [6])
assert answer["answerProbabilities"][1] == Fraction(8, 13)

designed = table.move_relationship(Fraction(3, 800))
assert designed.proper_marginals() == table.proper_marginals()
assert designed.conditional_lookup({5: 1, 11: 0}, [6])["answerProbabilities"][1] == Fraction(11, 13)
```

The simpler two/three-answer editor is [`docs/demo/triple.html`](../docs/demo/triple.html).
Reusable tables live in `relational_operations/data/records.json`; the covariance
examples live in `relational_operations/data/covariance_records.json`.

Node.js 18 or newer is only needed for the optional
JavaScript/DOM-output checks; it is not a Python runtime dependency.

## What this snapshot contains

The public package contains the exact table-operation code, reusable aggregate
data, interactive examples, provenance hashes and reproducibility checks.
Operational account details and workstation paths are excluded.

The covariance-decoding examples were checked against 32 retained physical
records containing 25,600 shots. Two four-answer distributions per record were
recovered exactly. These are multiple views of the same observations, not
additional independent measurements.

The underlying parity/Fourier mathematics is established. This project's work
is the implemented instrument, its application to the recorded tables, and the
specific consequences documented in this snapshot. Read
[Scientific scope](../SCIENTIFIC_SCOPE.md) for the evidence context, covariance
convention and interpretation of the original selected association.

## Reuse and attribution

Code and documentation are available under the **MIT License**. The released
data tables are available under **CC BY 4.0**. Credit **Relational Operations Lab
contributors**, identify the snapshot version, and retain the relevant data
provenance when reusing the material. See the licence and citation files for
the exact terms.

Questions, reproducibility reports and well-scoped contributions are welcome.
Please state the snapshot version and distinguish recorded values from any
new table designs or measurements.
