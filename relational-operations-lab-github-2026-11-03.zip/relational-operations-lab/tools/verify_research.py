#!/usr/bin/env python3
"""Verify retained research and replay its algorithmic results locally.

Install the research extra, then run `python tools/verify_research.py`.
--certificates-only needs just the standard library and skips numerical replays.
Outputs go to a temporary directory; saved results and original inputs remain
unchanged. CI runs the original Python/Node tests separately. Timings, compressed
byte counts and solver-specific witnesses are not regression targets.
"""
from __future__ import annotations

import argparse
from fractions import Fraction
import importlib.util
import json
import math
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def compare(expected, actual, path="result", approximate=False):
    """Exact structures/integers; optional tolerance applies only to floats."""
    if isinstance(expected, dict):
        require(isinstance(actual, dict) and expected.keys() == actual.keys(), f"{path}: keys differ")
        for key in expected:
            compare(expected[key], actual[key], f"{path}.{key}", approximate)
    elif isinstance(expected, list):
        require(isinstance(actual, list) and len(expected) == len(actual), f"{path}: list lengths differ")
        for index, (left, right) in enumerate(zip(expected, actual)):
            compare(left, right, f"{path}[{index}]", approximate)
    elif isinstance(expected, float) and approximate:
        require(isinstance(actual, (int, float)) and not isinstance(actual, bool)
                and math.isfinite(actual)
                and math.isclose(expected, actual, rel_tol=1e-9, abs_tol=1e-11),
                f"{path}: numerical values differ ({expected!r} vs {actual!r})")
    else:
        require(type(expected) is type(actual) and expected == actual,
                f"{path}: values differ ({expected!r} vs {actual!r})")


def fields(value, names):
    return {name: value[name] for name in names}


def geometry_signature(report):
    """Invariant optima/support; independent verification checks all witnesses."""
    examples = report.get("examples", report.get("projections"))
    require(isinstance(examples, list) and examples, "No geometry cases supplied")
    cases = []
    for example in examples:
        item = fields(example, (
            "bits", "counts", "constraint_masks", "constraint_targets",
            "support_complete_exactly_certified", "feasible_support", "forced_zero_categories",
            "unresolved_categories", "rank_on_feasible_support", "exact_feasible_dimension",
            "exact_interior_verified", "independent_pair_marginal_direction_checks",
            "all_coordinate_optima_exactly_verified", "zero_marginal_only_result",
        ))
        for key in ("name", "record_id", "view", "direction_inventory"):
            if key in example:
                item[key] = example[key]
        item["coordinate_maxima"] = [str(Fraction(row["exact_primal_lower_bound"]))
                                      for row in example["coordinate_results"]]
        cases.append(item)
    signature = {"cases": cases}
    for key in ("summary", "summary_by_view", "compact_projection_table", "exact_certificates",
                "original_direction_comparison", "counterexample_facet_certificate"):
        if key in report:
            signature[key] = report[key]
    if "three_bit_exhaustive_support_audit" in report:
        signature["exhaustive_audit"] = {
            key: value for key, value in report["three_bit_exhaustive_support_audit"].items()
            if key != "timing_seconds"
        }
    return signature


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--certificates-only", action="store_true",
                        help="Verify data, input checks and saved certificates without NumPy/SciPy")
    args = parser.parse_args()
    require(not sys.flags.optimize, "Run without -O/PYTHONOPTIMIZE: research assertions must remain enabled")
    root = args.repo_root.resolve()
    research = root / "research"
    require((root / "relational_operations/data/MANIFEST.json").is_file(), "Repository data not found")
    require(research.is_dir(), "Repository research directory not found")
    if not args.certificates_only:
        require(all(importlib.util.find_spec(name) is not None for name in ("numpy", "scipy")),
                'Replay dependencies missing. Install with: python -m pip install -e ".[research]"')
    environment = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTHONHASHSEED="0",
                       OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1")

    def run(label, *arguments):
        print(f"Checking {label}...", flush=True)
        result = subprocess.run([sys.executable, "-B", *map(str, arguments)], cwd=root,
                                env=environment, text=True, encoding="utf-8", errors="replace",
                                capture_output=True, timeout=300)
        if result.returncode:
            print(result.stdout, file=sys.stderr)
            print(result.stderr, file=sys.stderr)
            raise ValueError(f"{label} failed with exit code {result.returncode}")
        if result.stderr.strip():
            print(result.stderr, file=sys.stderr)
        print(f"PASS: {label}", flush=True)
        return result.stdout

    def verify_geometry(label, path, case_count, optimum_count, pattern_count):
        checked = json.loads(run(label, research / "geometry/verify_geometry_certificate.py", path))
        expected = {
            "status": "PASS", "example_support_and_dimension_certificates_verified": case_count,
            "exact_example_optimum_certificates_verified": optimum_count,
            "three_bit_support_patterns_rechecked_with_analytic_oracle": pattern_count,
        }
        compare(expected, fields(checked, expected), label)

    with TemporaryDirectory(prefix="relational-research-verification-") as temporary:
        output = Path(temporary)
        run("original data and manifest validation", "-m", "relational_operations", "verify-data")
        input_result = output / "input_contract_verification.json"
        run("compact decoder input contract", research / "compact/verify_input_contract.py",
            "--source-dir", root, "--output", input_result)
        contract = read_json(input_result)
        require(contract["status"] == "PASS" and contract["casesFailed"] == 0
                and contract["casesPassed"] >= 16, "Compact input checks incomplete")
        require(contract["sourceDataUnchangedDuringCheck"] and contract["companionUnchangedDuringCheck"],
                "Compact input check changed a source file")
        saved_geometry = research / "geometry/geometry_results.json"
        saved_archive = research / "geometry/archive_geometry_results.json"
        verify_geometry("saved named geometry and analytic support patterns", saved_geometry, 3, 40, 255)
        verify_geometry("saved archive geometry certificates", saved_archive, 64, 1024, 0)
        if args.certificates_only:
            print("PASS: data, 16+ input checks, 1,064 exact optimum certificates and 255 analytic support patterns.")
            return

        compact_output = output / "compact"
        run("compact and rounding recovery replay", research / "compact/compact_covariance.py",
            "--source-dir", root, "--output", compact_output, "--benchmark-repeats", "1")
        compact_fields = (
            "schema", "sourceSHA256", "records", "shots", "featureMeansPerRecord",
            "fullCovarianceEntriesPerRecord", "selectedCovarianceEntriesPerRecord",
            "nonconstantMomentsPerRecord", "fullScalarInputsPerRecord", "symmetricScalarInputsPerRecord",
            "selectedScalarInputsPerRecord", "exactFourBitReconstructions", "roundingAwareRecovery",
            "originalStrictDecoderOnRoundedInputs", "newMeasurements", "humanObservations",
            "providerCalls", "recordValidation",
        )
        compare(fields(read_json(research / "compact/results/results.json"), compact_fields),
                fields(read_json(compact_output / "results.json"), compact_fields), "compact replay")
        for filename in ("exact_moment_archive.json", "covariance_read_plan.json"):
            compare(read_json(research / "compact/results" / filename),
                    read_json(compact_output / filename), filename)
        print("PASS: all 32 exact moment records, read-plan entries and rounding outcomes agree.")

        geometry_output = output / "geometry.json"
        run("named geometry and 255-pattern LP replay", research / "geometry/support_geometry.py",
            "--source-dir", root, "--output", geometry_output)
        verify_geometry("replayed named geometry certificates", geometry_output, 3, 40, 255)
        compare(geometry_signature(read_json(saved_geometry)), geometry_signature(read_json(geometry_output)),
                "named/exhaustive geometry replay")
        archive_output = output / "archive_geometry.json"
        run("all 64 archive projections replay", research / "geometry/audit_archive_geometry.py",
            "--source-dir", root, "--output", archive_output)
        verify_geometry("replayed archive geometry certificates", archive_output, 64, 1024, 0)
        compare(geometry_signature(read_json(saved_archive)), geometry_signature(read_json(archive_output)),
                "archive geometry replay")
        print("PASS: exact supports, dimensions and coordinate maxima agree; alternate valid witnesses are allowed.")

        statistics_output = output / "statistics"
        run("statistical reference and sensitivity replay", research / "statistics/analyze_statistics.py",
            "--source-dir", root, "--output", statistics_output)
        expected = read_json(research / "statistics/statistical_findings.json")
        actual = read_json(statistics_output / "statistical_findings.json")
        for document in (expected, actual):
            document.pop("runtime", None)
            document.pop("script_sha256", None)
        compare(expected, actual, "statistics replay", approximate=True)
        print("PASS: exact statistical fields agree; floats agree within 1e-9 relative / 1e-11 absolute tolerance.")
    print("PASS: retained research verified and replayed. Timings and compression byte counts are not regression targets.")


if __name__ == "__main__":
    try:
        main()
    except (ValueError, OSError, subprocess.TimeoutExpired) as error:
        raise SystemExit(f"FAIL: {error}") from error
