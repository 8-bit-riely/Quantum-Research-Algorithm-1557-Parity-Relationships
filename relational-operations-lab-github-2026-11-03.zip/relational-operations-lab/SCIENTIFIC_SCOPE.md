# Scientific scope of this snapshot

**Version:** 0.1.0-experimental  
**Snapshot date:** 2026-11-03

This release makes a small set of mathematical instruments and reusable data
available for inspection. It is intended to support independent reproduction,
practical experimentation with table representations, and further research into
the physical observations that motivated the work.

## Three kinds of result

The repository distinguishes three levels throughout its data and interfaces:

| Kind | Meaning |
|---|---|
| Recorded evidence | Aggregate values derived from retained physical measurement records. |
| Mathematical consequence | An identity, reconstruction or constraint calculated from a supplied table under a stated convention. |
| Analytical design | A valid probability specification constructed by changing a relationship coordinate. |

An analytical design is not an additional physical observation. A conditional
query selects rows or probability mass from a table; it does not establish that
setting one physical variable causes another to change.

## What the software establishes

The exact-arithmetic core implements finite binary probability tables,
marginalization, parity-coordinate adjustment, conditional queries, coverage
audits and covariance-based moment recovery. Normalization, nonnegativity and
the declared preserved distributions are checked explicitly.

For `k` answers, the basic full-order operation is:

```text
p'(x) = p(x) + epsilon * (-1)^popcount(x)
```

It adds the same amount to even-parity categories and subtracts it from
odd-parity categories. Its exact valid interval is:

```text
-min(even-category probabilities) <= epsilon <= min(odd-category probabilities)
```

Summing over any omitted bit cancels the adjustment. Every proper-subset
marginal remains fixed. The full parity moment changes by `2^k * epsilon`.
Successive valid movements compose by addition and reverse by negating the
movement.

This is an affine table-design operation whose valid interval depends on the
starting table. A physical implementation would be a separate research result.

## Covariance recovery convention

For a parity feature, `chi_A(x)` is `+1` or `-1` according to the parity on the
selected bit set `A`. Products obey:

```text
chi_A(x) * chi_B(x) = chi_(A XOR B)(x)
```

Here `XOR` means symmetric difference of bit sets: shared bits cancel. With
known feature means and the retained empirical covariance-of-means convention:

```text
m_(A XOR B) = (N - 1) * CovMean(chi_A, chi_B) + m_A * m_B
```

The factor `N - 1` follows from this archive's sample-covariance convention.
It must not be replaced by another normalization without adapting the decoder.
The features and covariance entries must come from the same measurement rows.
Separate error bars, unrelated measurement batches, or an arbitrary covariance
matrix are not interchangeable with that contract.

For four bits, all individual and pair means expose 10 nonconstant parity
coordinates. Their full same-shot cross-covariance supplies the missing third-
and fourth-order moments, making all 15 coordinates available. An inverse parity
transform then recovers the 16-category measured distribution.

For twelve bits, the corresponding counts are 78 from individual/pair means and
793 when their full same-shot covariance is retained. That covers orders through
four, not all 4,095 nonconstant coordinates. The decoder takes one product/XOR
step; repeated closure would incorrectly create unavailable information.

Recovering these moments reveals information already encoded in the archive.
It does not create additional independent shots, remove instrument bias, or
reconstruct unmeasured quantum phases.

## The selected example and its context

One motivating case was an EMERALD measurement record with 800 shots. Its
selected pair had counts `[712, 62, 15, 11]` in `00, 01, 10, 11` order. At the
same observed individual rates, the independent reference would have 2.3725
joint-one events; the record contained 11.

This was a selected exploratory case. In a later exact-source EMERALD follow-up,
five reference jobs contained two joint-one events across 6,000 shots, versus
2.7275 expected at their individual observed margins. The prespecified positive
association endpoint did not reproduce the original selected association
(`p = 0.7713752`). Different observed rates and finite rare-event support matter
to the interpretation.

The software operations remain useful for the recorded table and for other
valid supplied tables. The physical origin and reproducible control of that
selected association remain research questions. The repository does not present
it as an established new physical mechanism.

## Coupled movements and empirical support

The selected four-answer example has a complete two-dimensional family that
preserves every individual and pair distribution. Its two context-restricted
directions combine higher-order coordinates whose isolated movements are
blocked at that starting table.

The geometry is exact for the specified empirical marginals. An observed empty
cell constrains this particular table specification; it is not proof that the
underlying population probability is zero or that a quantum device cannot
produce that category. Separately calculated coordinate ranges also do not
define an unrestricted box for simultaneous movements in general.

Bit labels and relationship masks describe the observed logical variables.
They should not be read as verified physical qubit placement, connectivity or
coupler information.

## Evidence and reproduction

The public release provides reusable aggregate tables and retained-statistics
examples, stable public record identities, provenance hashes, and verification
entrypoints. The private custody archive retains the original operational
records. Public hashes identify source material; they do not make unavailable
source bytes independently auditable by themselves. The public checks verify
the included data and software operations.

The original covariance-decoding pass covered 32 retained records and 25,600
shots, recovering two four-answer projections per record exactly. Record-level
boundaries are preserved. Multiple projections, moments, covariance entries and
designed tables must not be counted as independent physical replications.

This snapshot's mathematical and data-contract checks are separate from any
future physical acquisition or learning experiment. Running the included tools
does not submit a circuit, access a provider, change a model or incur a quantum
service charge.

## Established foundations and the contribution here

Parity functions form the Boolean Fourier basis, including a representation of
binary probability densities. Higher-order dependence that is invisible to
lower-order marginals is an established information-theory topic.

- Ryan O'Donnell, *Analysis of Boolean Functions*, sections 1.3–1.5:
  https://www.cs.cmu.edu/~odonnell/papers/Analysis-of-Boolean-Functions-by-Ryan-ODonnell.pdf
- Elad Schneidman, Susanne Still, Michael J. Berry II and William Bialek,
  *Network Information and Connected Correlations*, Physical Review Letters
  91, 238701 (2003): https://doi.org/10.1103/PhysRevLett.91.238701

The contribution released here is a working instrument, reproducible
record-specific calculations, and reusable table specifications. It does not
claim a new Fourier theorem, quantum advantage, or a general improvement to AI.
Applications may include measurement software, statistics export, probabilistic
computation or learning systems; no AI application is required for the work to
be useful.

## Snapshot policy

This version documents the state of the included artifacts at its stated date.
It is not a live workstation mirror. Later private or public work may develop
separately; its capabilities should be assessed from its own released artifacts.
The age of this snapshot does not establish any unpublished capability.

Future releases should retain their own version, data inventory, provenance and
verification results so that published claims remain tied to a reproducible
state.
