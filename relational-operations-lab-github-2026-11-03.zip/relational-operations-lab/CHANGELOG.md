# Changelog

## Algorithm research companion — 2026-11-03

GitHub-ready source package prepared from the original experimental release.
The core distribution version remains `0.1.0a1`; no new release tag is implied.

- Added standalone research algorithms for complete feasible support with exact
  certificates, selective covariance recovery, and explicit decimal rounding.
- Included the 64-projection archive audit, statistical comparisons, saved
  certificates, mathematical arguments, and supporting report.
- Added optional research/report dependencies and a reproducible verification
  runner with GitHub Actions checks.
- Preserved the original core algorithms and data. Historical documentation and
  checksums are retained under `docs/`; current checksums cover this package.

## v0.1.0-experimental — release candidate

Research snapshot as of **2026-11-03**. The Python package version is `0.1.0a1`.
The snapshot date records the included work; publication may happen later.

Included capabilities:

- Exact binary joint tables, marginals, conditional queries and bounded parity
  adjustments using rational arithmetic.
- Observation-format coverage audits and same-shot covariance decoding.
- Coupled four-answer probability controls preserving all individual/pair tables.
- Offline browser instruments and JSON exports separating recorded evidence
  from analytical designs.
- Twelve recorded table examples and 32 complete covariance records, with
  reusable logical histograms and hashes-only provenance.
- Portable Python checks, JavaScript checks and a GitHub CI definition.

This selected public snapshot is not a live mirror of ongoing development.
Future public changes should receive a new version and their own checksums.

Code/documentation: MIT. Released tables: CC BY 4.0.
