# Relational Operations Lab

**GitHub-ready algorithm research snapshot · 2026-11-03**

Algorithms for recovering higher-order information from binary measurements and
finding the complete family of probability tables compatible with fixed
individual and pair statistics.

This repository combines the original exact table-operation core with research
extensions for compact decoding, rounded-input recovery and automatic support
geometry. The original offline relationship editor remains available as an
optional companion. The executable algorithms are the main deliverable; the
[research report](report/Relational_Operations_Further_Research_2026-11-03.pdf)
explains their results and limits.

The original Python distribution version remains **0.1.0a1**, corresponding to
the source snapshot labelled `v0.1.0-experimental`. This dated research snapshot
does not assign a new release version or Git tag.

## What the algorithms do

| Component | Capability | Checked result |
|---|---|---|
| Selective covariance decoder | Recover moments through order four using chosen entries of a same-shot covariance matrix. | **78 means + 715 covariance entries = 793 scalar inputs**, versus 6,162 in the full stored format; exact agreement on all 32 records. |
| Rounding-aware decoder | Intersect known rounding intervals with the exact empirical parity lattice. | **Six decimal places recover all 32 records** under the stated rounding contract. Ambiguous targets remain unresolved. |
| Complete support geometry | Find every category that can carry mass at fixed single/pair statistics; certify the dimension and a full direction basis. | **1,024 coordinate maxima across 64 projections** have exact rational primal/dual certificates. |
| Statistical analysis | Compare the original conditional with a pairwise maximum-entropy reference and examine sampling uncertainty and support sensitivity. | Reproducible descriptive calculations with explicit selection and sampling assumptions. |

See the [compact results](research/compact/results/results.json),
[archive geometry results](research/geometry/archive_geometry_results.json),
[statistical results](research/statistics/statistical_findings.json) and
[mathematical notes](docs/PROOFS.txt).

## Quick start

Use **Python 3.12** for the research environment. From the repository root:

```bash
python -m pip install -e '.[research]'
python tools/verify_research.py
```

The research extra installs NumPy and SciPy. The verification command checks
original data hashes, compact-input checks and saved exact certificates, then
replays decoding, support geometry and statistics against the saved findings.
It includes the 255-pattern three-bit audit and all 64 archive projections.
PDF rendering is not part of these checks.

For the certificate/input checks using only the Python standard library:

```bash
python tools/verify_research.py --certificates-only
```

The original core supports Python 3.10 or later; the numerical research
dependencies require a newer environment. Once dependencies are installed, the
analysis runs locally without a quantum account or cloud service.

## Run individual algorithms

The original data are already in `relational_operations/data/`. Run these
commands from the repository root; outputs go into a separate directory:

```bash
python research/compact/compact_covariance.py --source-dir . --output outputs/compact

python research/geometry/support_geometry.py --source-dir . --output outputs/geometry.json
python research/geometry/audit_archive_geometry.py --source-dir . --output outputs/archive_geometry.json
python research/geometry/verify_geometry_certificate.py outputs/archive_geometry.json

python research/statistics/analyze_statistics.py --source-dir . --output outputs/statistics
```

The geometry solver uses numerical LP solutions as candidates and verifies
rational certificates exactly. Uncertified cases remain unresolved. Its explicit
table implementation is limited to six binary variables; see the
[geometry guide](research/geometry/README.md) for API details and limitations.

The original core remains usable independently:

```bash
python -m relational_operations condition --record E32:S04 --given 5=1 --given 11=0 --query 6
python -m relational_operations decode --record E32:S04 --subset 5 6 10 11
python -m unittest discover -s tests -v
```

Installation also provides the original `relational-lab` command. The research
extensions run through their scripts; they are not new subcommands of that CLI.

## Why complete geometry matters

A higher-order control can be blocked at a table with empty categories even
when a combination of controls can move. Across the two named views of each
record, **62 of 64 projections block all five pure parity axes**. Of those, 51
allow a simple context-restricted move. Complete certificates establish that
the remaining 11 are unique at their supplied pair margins.

In 11 other projections, the initially feasible simple context directions span
fewer dimensions than the complete family. The full audit supplies support,
interior points and direction bases rather than inferring freedom from the
initial controls alone. The final dimensions are 0, 1, 2 and 5 in respectively
11, 23, 17 and 13 projections. See the
[archive summary](research/geometry/archive_geometry_summary.md).

## Evidence and scope

These calculations reuse **32 records and 25,600 shots**. Two projections per
record are overlapping views, not independent experiments. No new physical
measurements, human observations, AI training or deployed performance results
are added by this snapshot.

The original 61.54% conditional is **8/13**, with the condition observed in only
13 of 800 shots. Its reported uncertainty assumes stable IID sampling and a
fixed event; historical selection remains uncorrected. Maximum-entropy
comparisons are in-sample. Pseudocount tables are explicit sensitivity designs
that change the empirical margins.

Exact feasible tables do not by themselves establish physical controllability
or population effects. The compact decoder omits redundant integrity checks,
so its timing comparison does not establish an equal-audit speedup. Six-decimal
recovery concerns a known rounding contract, not arbitrary measurement noise.

The mathematical foundations are established. These extensions supply
implemented algorithms, archive results and independently checkable
certificates. Read [PROOFS.txt](docs/PROOFS.txt),
[Scientific scope](SCIENTIFIC_SCOPE.md) and the
[reference list](report/sources.json) for the arguments and prior foundations.

## Optional offline editor

Open `docs/demo/index.html` locally in a browser. The smaller two/three-answer
editor is `docs/demo/triple.html`. These pages visualize the original table
operations and analytical designs. The
[original README](docs/ORIGINAL_README.md) is preserved for historical context.

## Put this package on GitHub

1. Extract the downloaded package on your computer.
2. Create or choose your GitHub repository.
3. Upload the extracted folder's **contents**, placing `README.md`,
   `pyproject.toml`, `relational_operations/`, `research/` and `.github/` at the
   repository root.
4. Ensure your upload includes the `.github/` folder and its workflow files;
   some file pickers hide folders beginning with a dot.
5. Commit the uploaded files and inspect the repository's Actions results.

The checks and scripts can also be run locally before uploading. Publication
and any release tag are your repository choices.

## License and attribution

Code and documentation use the [MIT License](LICENSE). Released source data use
[CC BY 4.0](LICENSES/CC-BY-4.0.txt). Credit **Relational Operations Lab
contributors**, identify the source snapshot, and retain data provenance when
reusing the material. See [snapshot notes](RELEASE_NOTES.md) for the additions.
