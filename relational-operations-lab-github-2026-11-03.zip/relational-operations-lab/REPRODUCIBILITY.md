# Reproduce this snapshot

## Algorithm research extensions

Use Python 3.12 for the research snapshot. From the repository root:

```bash
python -m pip install ".[research]"
python tools/verify_research.py
```

The verification runner checks saved exact certificates, input validation, and
semantic replay results. It excludes machine-dependent timings and rendering
bytes from numerical comparisons. For the standard-library certificate checks:

```bash
python tools/verify_research.py --certificates-only
```

The scripts run directly from this checkout, with the original data under
`relational_operations/data/`. Pass `--source-dir .` when running an individual
research script. The new commands do not replace the original `relational-lab`
CLI. See [README](README.md) for individual commands and [mathematical
arguments](docs/PROOFS.txt) for the scope of the results.

## Original core and offline examples

Core runtime: Python 3.10+ and its standard library. Node.js 18+ is optional for the
browser-script checks. No quantum SDK, account, GPU or network connection is
needed by the tools or recorded-data checks.

From a clean checkout or an extracted release archive:

```bash
python -m unittest discover -s tests -v
python -m relational_operations verify-data
python -m relational_operations build --output site
node tests/check_workbench.cjs site/triple.html
node tests/check_extensions.cjs site/index.html
```

Choose a new output directory for each build. Open `site/index.html` for the
four-answer instrument, or `site/triple.html` for the two/three-answer editor.
The prebuilt copies in `docs/demo/` work directly from disk.

Expected checks for this snapshot:

- 13 Python test cases, including exact invariant loops, all bundled covariance
  reconstructions, invalid-request rejection and offline verification.
- 12 table records and 32 covariance records with four shared records: 40 unique
  historical records /34,400 shots across both catalogs.
- 793 recovered nonconstant coefficients per covariance record, checked against
  its published histogram, and 64 exact four-answer reconstructions.
- 648 two/three-answer UI views and 176 four-answer UI views.

The browser checks execute JavaScript and verify DOM-output logic in Node. They
are not a visual browser-rendering certification. The CI workflow uses Ubuntu
and Python 3.12 for this research package; local preparation does not imply a
completed GitHub CI run.

`relational_operations/data/MANIFEST.json` pins the reusable inputs.
`docs/demo/SITE_MANIFEST.json` pins the prebuilt site files.
`CHECKSUMS.sha256` pins the distributed snapshot files except itself.

The recorded logical histograms and full means/covariance inputs are included.
Original service payload hashes remain as provenance commitments; original
operational payloads and account metadata are not part of this release.
